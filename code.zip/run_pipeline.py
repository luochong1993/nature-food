"""Command-line entry point for the global cropland mismatch project."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml


PROJECT_ROOT = Path(__file__).resolve().parent
SCRIPT_DIR = PROJECT_ROOT / "03_scripts"
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from download_data import download_from_config  # noqa: E402
from pipeline_core import (  # noqa: E402
    make_grid,
    process_future_population,
    process_inputs,
    setup_logger,
)


def load_config(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def resolve_root(config_path: Path, cfg: dict) -> Path:
    configured = Path(str(cfg.get("project", {}).get("root", "")))
    if configured.is_absolute():
        return configured
    return (config_path.parent / configured).resolve()


def manifest_status(root: Path) -> list[dict]:
    import csv

    path = root / "data_manifest.csv"
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def run_status(cfg: dict, root: Path) -> None:
    print(f"Project: {root}")
    grid = make_grid(cfg)
    print(f"Grid: {grid.width} x {grid.height} at {grid.resolution} degree ({grid.crs})")
    for row in manifest_status(root):
        target = root / row.get("target_path", "")
        exists = target.exists()
        size = target.stat().st_size if exists else 0
        print(f"{row.get('dataset_id','')}: {row.get('status','')} | {size} bytes | {target}")
    metadata = root / "02_data_processed" / "metrics_metadata.json"
    if metadata.exists():
        print(f"Metrics: {metadata}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command",
        nargs="?",
        default="all",
        choices=["all", "download", "process", "analyze", "status"],
    )
    parser.add_argument("--config", default="config.yaml", help="YAML configuration path")
    parser.add_argument("--force", action="store_true", help="redownload/rewrite existing outputs")
    parser.add_argument(
        "--include-future",
        action="store_true",
        help="download all configured FuturePop scenario archives (about 4 GB each)",
    )
    parser.add_argument(
        "--skip-production",
        action="store_true",
        help="skip the optional SPAM production bundle and leave/resume its .part file",
    )
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path
    cfg = load_config(config_path)
    root = resolve_root(config_path, cfg)
    root.mkdir(parents=True, exist_ok=True)
    log_name = f"pipeline_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    logger = setup_logger(root / "06_logs" / log_name)
    logger.info("command=%s root=%s", args.command, root)

    try:
        if args.command == "status":
            run_status(cfg, root)
            return 0

        if args.command in {"all", "download"}:
            logger.info("starting data acquisition")
            summary = download_from_config(
                cfg,
                root,
                root / "data_manifest.csv",
                logger,
                force=args.force,
                include_future=args.include_future,
                skip_production=args.skip_production,
            )
            logger.info("download summary: %s", json.dumps(summary, ensure_ascii=False))
            if args.command == "download":
                return 0

        if args.command in {"all", "process", "analyze"}:
            logger.info("starting spatial processing")
            process_inputs(cfg, root, logger)
            process_future_population(cfg, root, logger)
            logger.info("processing complete")
            return 0
    except Exception:
        logger.exception("pipeline failed")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
