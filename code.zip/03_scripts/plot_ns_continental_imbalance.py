"""Python quantitative-grid figure: regional divergence and continental imbalance.

Contract: hero shares panel; pressure-change panel; all-scenario imbalance panel.
183 x 160 mm, Arial 7 pt, editable PDF/SVG and 600 dpi TIFF. All calculations
use the same 201 country codes. Six continents displayed; other territories
remain in denominators and distance calculations. Scenarios are not replicates.
"""
from pathlib import Path
import io,json,shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
import tifffile

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'07_manuscript/packages/nature_sustainability/manuscript_five_figures_20261020'
OUT=BASE.parent/'regional_imbalance_20261020'
FIG=OUT/'figures'
NAME='Fig5_continental_pressure_and_imbalance'
REGIONS=['Africa','Asia','Europe','North America','South America','Oceania']
BLUE='#3d7093';RED='#b85443';GOLD='#c6832e';PURPLE='#8562a8'
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.titlesize':7,'axes.labelsize':7,'xtick.labelsize':6,'ytick.labelsize':6,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,'pdf.fonttype':42,'svg.fonttype':'none','legend.frameon':False})

def axis(f,rect,label,title):
    a=f.add_axes(rect);a.set_title(title,loc='left',pad=10)
    a.text(-.09,1.055,label,transform=a.transAxes,weight='bold',fontsize=8)
    return a

def plot():
    FIG.mkdir(exist_ok=True)
    caps=json.loads((BASE/'figure_legends.json').read_text(encoding='utf-8'))
    for p in (BASE/'figures').iterdir():
        if p.name.startswith('Fig5_'):continue
        shutil.copy2(p,FIG/p.name)
    old='Fig5_historical_and_future_loading'
    for ext in ['pdf','svg','png','tiff']:
        shutil.copy2(BASE/'figures'/(old+'.'+ext),FIG/('Supplementary_Fig8_historical_and_future_loading.'+ext))
    caps['Supplementary_Fig8_historical_and_future_loading']=caps.pop(old).replace('Fig. 5 |','Supplementary Fig. 8 |',1)
    d=pd.read_csv(OUT/'source_data/continental_pressure_all_ssps.csv')
    t=pd.read_csv(OUT/'source_data/continental_population_resource_total_variation.csv')
    s=d[d.scenario=='SSP2'].set_index('region').loc[REGIONS]
    f=plt.figure(figsize=(183/25.4,160/25.4))
    a=axis(f,[.17,.61,.77,.29],'a','Continental population shares and represented capacity')
    for j,(column,label,col,mark) in enumerate([
        ('population_share_2020_percent','Population 2020',BLUE,'o'),
        ('population_share_2050_percent','Population 2050 SSP2',RED,'D'),
        ('capacity_share_percent','Fixed capacity',GOLD,'^')]):
        a.scatter(s[column],np.arange(6)+(j-1)*.19,label=label,color=col,marker=mark,s=20)
    a.set_yticks(range(6),REGIONS);a.set_ylim(5.55,-.55);a.set_xlim(-1,65)
    a.set_xlabel('Share within the matched 201-code domain (%)')
    a.grid(axis='x',color='#ededed',lw=.5)
    a.legend(loc='upper center',bbox_to_anchor=(.50,1.27),ncol=3,fontsize=6)
    b=axis(f,[.17,.15,.32,.30],'b','Regional relative-pressure change')
    for i,region in enumerate(REGIONS):
        values=d[d.region==region].set_index('scenario').delta_pressure_log2
        b.plot([values.min(),values.max()],[i,i],color='#999999',lw=2,zorder=1)
        for j,scenario in enumerate(['SSP1','SSP2','SSP3','SSP4','SSP5']):
            b.scatter(values[scenario],i,color=RED if scenario=='SSP2' else '#8b8b8b',s=25 if scenario=='SSP2' else 9,marker='D' if scenario=='SSP2' else 'o',zorder=3 if scenario=='SSP2' else 2)
    b.axvline(0,lw=.6,color='#444');b.set_xlim(-.52,.72);b.set_ylim(5.55,-.55)
    b.set_yticks(range(6),REGIONS);b.set_xlabel('2050 minus 2020 pressure (log2)')
    from matplotlib.lines import Line2D
    b.legend(handles=[Line2D([],[],c=RED,marker='D',ls='none',ms=4,label='SSP2'),Line2D([],[],c='#999',marker='o',ms=3,lw=1,label='SSP1–SSP5 range')],loc='upper center',bbox_to_anchor=(.48,-.25),fontsize=6)
    c=axis(f,[.65,.15,.30,.30],'c','Between-region imbalance')
    for j,(resource,col,label) in enumerate([('area',BLUE,'Area'),('quality',PURPLE,'Quality-equivalent'),('capacity',GOLD,'Capacity')]):
        v=t[t.resource==resource].set_index('scenario')
        vals=[v.tv_2020.iloc[0]]+[v.loc[f'SSP{k}','tv_2050'] for k in range(1,6)]
        c.scatter(np.arange(6)+(j-1)*.10,vals,c=col,s=18,label=label,marker=['o','s','^'][j])
        c.axhline(vals[0],lw=.5,ls=':',color=col,alpha=.65)
    c.set_xticks(range(6),['2020','SSP1','SSP2','SSP3','SSP4','SSP5'],rotation=45,ha='right')
    c.set_ylim(.23,.38);c.set_yticks([.25,.30,.35]);c.set_ylabel('Total-variation distance')
    c.set_xlabel('Baseline and alternative 2050 endpoints')
    c.legend(loc='upper left',bbox_to_anchor=(-.01,1.02),fontsize=5.7)
    for ext in ['pdf','svg','png']:f.savefig(FIG/(NAME+'.'+ext),dpi=300)
    bfr=io.BytesIO();f.savefig(bfr,format='png',dpi=600);bfr.seek(0)
    tifffile.imwrite(FIG/(NAME+'.tiff'),np.array(Image.open(bfr).convert('RGB')),compression='zlib',resolution=(600,600),metadata=None)
    plt.close(f)
    caps[NAME]='Fig. 5 | Continental imbalances widen despite opposing regional pressure trajectories. a, Population shares in 2020 and SSP2 2050 compared with fixed four-crop attainable-capacity shares. b, Changes in relative population–resource pressure under fixed resource shares. Diamonds indicate SSP2; grey points and ranges show the five scenario endpoints, not confidence intervals. The change is common to all three resource definitions because their fixed shares cancel. c, Total-variation distance between continental population and resource shares for physical area, quality-equivalent area and capacity. Dotted lines mark the corresponding 2020 baselines. All panels use the identical 201 national codes at both dates, summing stocks before calculating shares. Six continents are shown in a and b; three other island-territory codes remain in all denominators and in c. Seven regional categories are used in the distance calculation. Resources and within-country population allocation weights remain fixed; these are demographic counterfactuals, not forecasts of agricultural capacity. No inferential tests are applied. Source Data are provided.'
    (OUT/'figure_legends.json').write_text(json.dumps(caps,indent=2),encoding='utf-8')
    (OUT/'figure_contract.md').write_text(__doc__+'\n',encoding='utf-8')
    print('Exported five main figures and eight supplementary figures',flush=True)

if __name__=='__main__':plot()
