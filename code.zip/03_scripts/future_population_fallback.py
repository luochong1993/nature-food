"""Download and spatialise the small country-level SSP fallback dataset.

This is deliberately separate from the preferred WorldPop FuturePop raster
path.  When the 3.8-GB FuturePop archives are unreachable, the IIASA
zen2025V01 country stocks can still provide a traceable scenario extension.
Country totals are spatially allocated using the latest available unadjusted
WorldPop pattern within the same Natural Earth admin-0 mask. Outputs are
labelled as modelled fallback surfaces, not observations or native FuturePop
1-km rasters.
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
import yaml

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from download_data import download_one, setup_logger, update_manifest  # noqa: E402
from pipeline_core import make_grid, read_grid_raster, write_raster  # noqa: E402


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def load_wpp_numeric_map(path: Path) -> dict[int, str]:
    from openpyxl import load_workbook

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        sheet = workbook["Estimates"]
        header_row = None
        header = None
        for row_number, row in enumerate(sheet.iter_rows(min_row=1, max_row=100, values_only=True), 1):
            labels = {str(value).strip() for value in row if value is not None}
            if {"Location code", "ISO3 Alpha-code"}.issubset(labels):
                header_row, header = row_number, list(row)
                break
        if header_row is None or header is None:
            raise ValueError("WPP location-code header not found")
        columns = {str(value).strip(): index for index, value in enumerate(header) if value is not None}
        out = {}
        for row in sheet.iter_rows(min_row=header_row + 1, values_only=True):
            try:
                code = int(row[columns["Location code"]])
                iso3 = str(row[columns["ISO3 Alpha-code"]] or "").strip().upper()
            except (TypeError, ValueError, IndexError):
                continue
            if iso3 and iso3 not in {"NAN", "NONE"}:
                out.setdefault(code, iso3)
        return out
    finally:
        workbook.close()


def read_country_totals(csv_path: Path, year: int, numeric_to_iso3: dict[int, str]) -> dict[str, float]:
    totals: dict[str, float] = {}
    for frame in pd.read_csv(csv_path, usecols=["region", "region_level", "Time", "agest", "pop"], chunksize=250_000):
        frame = frame[frame["region_level"].astype(str).str.lower().eq("country")]
        frame = frame[pd.to_numeric(frame["Time"], errors="coerce").eq(year)]
        # The source uses agest == -5 for a newborn accounting placeholder;
        # excluding it is required before summing stock population.
        frame = frame[pd.to_numeric(frame["agest"], errors="coerce").ne(-5)]
        frame["numeric_code"] = frame["region"].astype(str).str.extract(r"(\d+)$")[0]
        frame["numeric_code"] = pd.to_numeric(frame["numeric_code"], errors="coerce")
        frame["iso3"] = frame["numeric_code"].map(numeric_to_iso3)
        frame["pop"] = pd.to_numeric(frame["pop"], errors="coerce")
        frame = frame[frame["iso3"].notna() & frame["pop"].notna()]
        for iso3, value in frame.groupby("iso3")["pop"].sum().items():
            totals[str(iso3)] = totals.get(str(iso3), 0.0) + float(value) * 1000.0
    return totals


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=None)
    parser.add_argument("--download", action="store_true", help="download missing IIASA CSV files")
    args = parser.parse_args()
    root = Path(args.root) if args.root else Path(__file__).resolve().parents[1]
    cfg = yaml.safe_load((root / "config.yaml").read_text(encoding="utf-8"))
    log_path = root / "06_logs" / f"future_fallback_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    logger = setup_logger(log_path)
    fallback = cfg.get("sources", {}).get("future_population_country_fallback", {})
    scenarios = cfg.get("analysis", {}).get("future_scenarios", list(fallback.get("scenarios", {})))
    years = cfg.get("analysis", {}).get("future_years", [fallback.get("target_year", 2050)])
    raw_dir = root / "01_data_raw" / "future_population_fallback"
    raw_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = root / "data_manifest.csv"
    if args.download:
        for scenario in scenarios:
            scenario = str(scenario).upper()
            url = fallback.get("scenarios", {}).get(scenario)
            if not url:
                continue
            target = raw_dir / f"SSP{scenario[-1]}_zen2025V01.csv"
            try:
                result = download_one([url], target, logger, force=False)
                result["target_path"] = str(target.relative_to(root)).replace("\\", "/")
                update_manifest(
                    manifest_path,
                    f"future_population_country_{scenario}",
                    result,
                    note="IIASA zen2025V01 country-level SSP stock fallback; excludes agest=-5 and uses the unadjusted baseline-year WorldPop pattern only for modelled spatial allocation. No population-total correction is applied.",
                )
                logger.info("fallback %s: %s", scenario, result.get("status"))
            except Exception as exc:  # noqa: BLE001
                update_manifest(
                    manifest_path,
                    f"future_population_country_{scenario}",
                    {"status": "failed", "downloaded_at": datetime.now(timezone.utc).isoformat()},
                    note=str(exc),
                )
                logger.warning("fallback download failed for %s: %s", scenario, exc)

    grid = make_grid(cfg)
    country_raster_path = root / "02_data_processed" / "grid_country_id.tif"
    lookup_path = root / "04_results" / "country" / "country_lookup.csv"
    baseline_year = int(cfg.get("project", {}).get("year", 2015))
    base_path = root / "02_data_processed" / f"grid_population_{baseline_year}.tif"
    wpp_path = root / "01_data_raw" / "population" / "WPP2024_GEN_F01_DEMOGRAPHIC_INDICATORS_COMPACT.xlsx"
    if not (country_raster_path.exists() and lookup_path.exists() and base_path.exists() and wpp_path.exists()):
        raise FileNotFoundError("run the main spatial process before spatialising the country-level fallback")
    with rasterio.open(country_raster_path) as src:
        country_id = src.read(1).astype("int16", copy=False)
    lookup = pd.read_csv(lookup_path)
    base = read_grid_raster(base_path).astype("float64")
    base[~np.isfinite(base)] = 0.0
    base[base < 0] = 0.0
    numeric_to_iso3 = load_wpp_numeric_map(wpp_path)
    analysis = cfg.get("analysis", {})
    aliases = {
        str(key).upper(): str(value).upper()
        for key, value in (analysis.get("population_iso_aliases", {}) or {}).items()
    }
    groups = {
        str(key).upper(): [str(value).upper() for value in values]
        for key, values in (analysis.get("population_reference_groups", {}) or {}).items()
    }
    outputs = []
    for scenario in scenarios:
        scenario = str(scenario).upper()
        csv_path = raw_dir / f"SSP{scenario[-1]}_zen2025V01.csv"
        if not csv_path.exists():
            logger.warning("fallback table not available: %s", csv_path)
            continue
        for year in years:
            year = int(year)
            totals = read_country_totals(csv_path, year, numeric_to_iso3)
            out = np.zeros(grid.shape, dtype="float64")
            rows = []
            grouped_members: dict[str, list[tuple[str, np.ndarray]]] = {}
            for _, country in lookup.iterrows():
                cid = int(country["country_id"])
                iso3 = str(country["iso3"]).upper()
                mask = country_id == cid
                if not np.any(mask):
                    continue
                reference_key = aliases.get(iso3, iso3)
                group_key = next(
                    (
                        key
                        for key, members in groups.items()
                        if iso3 in members or reference_key in members
                    ),
                    reference_key,
                )
                grouped_members.setdefault(group_key, []).append((iso3, mask))
            used_targets: dict[str, float] = {}
            for group_key, members in grouped_members.items():
                target = totals.get(group_key)
                if target is None and len(members) == 1:
                    target = totals.get(members[0][0])
                if target is None:
                    continue
                used_targets[group_key] = float(target)
                weights = np.concatenate([base[mask] for _, mask in members])
                weights[~np.isfinite(weights)] = 0.0
                weights[weights < 0] = 0.0
                weight_sum = float(weights.sum())
                cell_count = int(sum(int(mask.sum()) for _, mask in members))
                cursor = 0
                for iso3, mask in members:
                    n = int(mask.sum())
                    country_weights = weights[cursor : cursor + n]
                    cursor += n
                    if weight_sum > 0:
                        allocated = float(target) * country_weights / weight_sum
                    else:
                        allocated = np.full(n, float(target) / max(cell_count, 1), dtype="float64")
                    out[mask] = allocated
                    rows.append({"scenario": scenario, "year": year, "iso3": iso3, "reference_group": group_key, "target_population": float(allocated.sum()), "allocated_population": float(out[mask].sum()), "spatial_basis": f"unadjusted WorldPop {baseline_year} distribution; modelled allocation"})
            out_path = root / "02_data_processed" / f"grid_population_{scenario}_{year}.tif"
            write_raster(out_path, out, grid, nodata=-9999, dtype="float64", tags={"metric": "population_count", "scenario": scenario, "year": year, "source": "IIASA zen2025V01 country SSP fallback", "spatial_downscaling": f"modelled allocation from unadjusted WorldPop {baseline_year} distribution within Natural Earth admin0"})
            total_input = float(sum(totals.values()))
            total_output = float(out.sum())
            outputs.append({"scenario": scenario, "year": year, "csv": str(csv_path.relative_to(root)).replace("\\", "/"), "country_total_input": total_input, "recognized_country_total": float(sum(used_targets.values())), "grid_total_output": total_output, "closure_residual": total_input - total_output, "unmapped_country_total": total_input - float(sum(used_targets.values())), "status": "processed_fallback"})
            pd.DataFrame(rows).to_csv(root / "04_results" / "tables" / f"future_fallback_country_{scenario}_{year}.csv", index=False, encoding="utf-8-sig")
    metadata = {"created_at": datetime.now(timezone.utc).isoformat(), "provider": fallback.get("provider"), "version": fallback.get("version"), "dataset_doi": fallback.get("dataset_doi"), "spatial_basis_year": baseline_year, "spatial_basis_adjustment": "none", "outputs": outputs, "warning": f"These are modelled spatial allocations of IIASA country-total SSP values using the unadjusted WorldPop {baseline_year} spatial pattern; they are not native FuturePop 1-km rasters or observations."}
    (root / "02_data_processed" / "future_population_fallback_processing.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"outputs": len(outputs), "scenarios": sorted({o['scenario'] for o in outputs})}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
