"""Apply numerical-support and visual-QA corrections without changing source data."""
import json
import numpy as np
import pandas as pd
import revise_ns_exposure as n

n.STATS.update(json.loads((n.OUT/'verification.json').read_text(encoding='utf-8')))
names=['Fig3_population_area_and_capacity_exposure','Supplementary_Fig6_accounting_and_composition_sensitivity','Fig4_historical_and_future_fixed_resource_loading','Fig1_area_pressure_and_resource_definition_differences','Fig2_three_definition_national_transitions','Supplementary_Fig4_production_pressure_zoom_and_full_range']
for name,text in zip(names,(n.OUT/'figure_legends.md').read_text(encoding='utf-8').strip().split('\n\n')):n.CAP[name]=text
n.paint_exposure(pd.read_csv(n.SD/'Supplementary_Table4_weighted_exposure.csv'))
n.crop_audit();n.historical();n.contrasts()
p=n.v.P
pop_total=float(n.STATS['exposure']['country_population'])
zero=n.v.D&(p>0)&np.logical_and.reduce([r<=0 for r in n.v.R])
rows=[]
for label,mask in [('Populated cells without any represented resource',zero),('Common-positive cells',n.v.COMMON)]:
    pop=float(p[mask].sum(dtype='float64'))
    rows.append(dict(support=label,cells=int(mask.sum()),population=pop,population_percent_country_domain=100*pop/pop_total))
pd.DataFrame(rows).to_csv(n.SD/'population_resource_support_diagnostic.csv',index=False)
n.STATS['population_resource_support']=rows
n.report()
note='\n\n## Population support diagnostic\n\n'
for r in rows:note+=f"{r['support']}: {r['cells']:,} cells, {r['population_percent_country_domain']:.2f}% of retained population. "
note+='These support totals use the cached float32 display population array with float64 accumulation; the weighted exposure table uses the original population raster. Pressure in populated cells lacking represented resources is sensitive to the numerical floor and must not be interpreted as directly measured food insecurity.\n'
with (n.OUT/'Results_and_Supplementary_additions.md').open('a',encoding='utf-8') as f:f.write(note)
print('Numerical and visual QA corrections complete',flush=True)
