"""Audit country totals under cell-centre and all-touched boundary masks.

This sensitivity check never changes population values. It quantifies how
assigning a 5-arc-min cell to an admin-0 unit only when its centre is inside a
polygon differs from assigning it when any part of the cell intersects one.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
import yaml
from rasterio.features import rasterize
from rasterio.warp import Resampling

from pipeline_core import extract_zip_safely, make_grid, reproject_to_grid


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--year", type=int, default=None)
    args = parser.parse_args()
    root = args.root.resolve()
    cfg = yaml.safe_load((root / "config.yaml").read_text(encoding="utf-8"))
    year = int(args.year or cfg.get("project", {}).get("year", 2015))
    grid = make_grid(cfg)

    population_dir = root / "01_data_raw" / "population"
    candidates = [
        population_dir / f"worldpop_{year}_1km.tif",
        population_dir / f"worldpop_{year}_5arcmin_sum_native_slice.tif",
        population_dir / f"worldpop_{year}_5arcmin_sum.tif",
    ]
    population_path = next((path for path in candidates if path.exists()), None)
    if population_path is None:
        raise FileNotFoundError(f"no verified population raster found for {year}")
    population = np.asarray(
        reproject_to_grid(population_path, grid, resampling=Resampling.sum, dtype="float64"),
        dtype="float64",
    )
    population[~np.isfinite(population)] = 0.0
    population[population < 0] = 0.0

    center_path = root / "02_data_processed" / "grid_country_id.tif"
    with rasterio.open(center_path) as src:
        center_ids = src.read(1).astype("int32", copy=False)
    lookup_path = root / "04_results" / "country" / "country_lookup.csv"
    lookup = pd.read_csv(lookup_path)

    boundary_spec = cfg.get("sources", {}).get("natural_earth_admin0", {})
    boundary_path = root / "01_data_raw" / boundary_spec.get(
        "target", "boundaries/ne_10m_admin_0_map_units.zip"
    )
    extracted = extract_zip_safely(
        boundary_path,
        root / "work" / f"natural_earth_{boundary_path.stem}",
    )
    shp = next((path for path in extracted if path.suffix.lower() == ".shp"), None)
    if shp is None:
        raise FileNotFoundError(f"no shapefile found in {boundary_path}")
    polygons = gpd.read_file(shp).to_crs(grid.crs)
    all_touched_shapes = [(row.geometry, index + 1) for index, (_, row) in enumerate(polygons.iterrows())]
    touched_ids = rasterize(
        all_touched_shapes,
        out_shape=grid.shape,
        transform=grid.transform,
        fill=0,
        dtype="int32",
        all_touched=True,
    )

    n_ids = int(max(center_ids.max(), touched_ids.max(), lookup["country_id"].max())) + 1
    center_totals = np.bincount(center_ids.ravel(), weights=population.ravel(), minlength=n_ids)
    touched_totals = np.bincount(touched_ids.ravel(), weights=population.ravel(), minlength=n_ids)
    rows = lookup.copy()
    rows["period"] = year
    rows["cell_centre_total"] = center_totals[rows["country_id"].to_numpy(dtype=int)]
    rows["all_touched_total"] = touched_totals[rows["country_id"].to_numpy(dtype=int)]
    rows["count_difference"] = rows["all_touched_total"] - rows["cell_centre_total"]
    rows["difference_percent"] = np.where(
        rows["cell_centre_total"] > 0,
        100.0 * rows["count_difference"] / rows["cell_centre_total"],
        np.nan,
    )
    rows["positive_cells_cell_centre"] = [
        int(np.count_nonzero((center_ids == cid) & (population > 0)))
        for cid in rows["country_id"].to_numpy(dtype=int)
    ]
    rows["positive_cells_all_touched"] = [
        int(np.count_nonzero((touched_ids == cid) & (population > 0)))
        for cid in rows["country_id"].to_numpy(dtype=int)
    ]

    full_total = float(population.sum(dtype=np.float64))
    center_domain = float(center_totals[1:].sum(dtype=np.float64))
    touched_domain = float(touched_totals[1:].sum(dtype=np.float64))
    summary = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "year": year,
        "population_source": str(population_path.relative_to(root)).replace("\\", "/"),
        "population_adjustment": "none",
        "boundary_source": str(boundary_path.relative_to(root)).replace("\\", "/"),
        "full_harmonised_grid_total": full_total,
        "cell_centre_country_domain_total": center_domain,
        "cell_centre_unassigned_total": full_total - center_domain,
        "cell_centre_coverage_fraction": center_domain / full_total if full_total else None,
        "all_touched_country_domain_total": touched_domain,
        "all_touched_unassigned_total": full_total - touched_domain,
        "all_touched_coverage_fraction": touched_domain / full_total if full_total else None,
        "all_touched_rule_is_sensitivity_only": True,
        "interpretation": "Population values are unchanged. The alternative rule changes country assignment of boundary cells and is not used to replace the primary cell-centre analysis.",
    }
    tables = root / "04_results" / "tables"
    tables.mkdir(parents=True, exist_ok=True)
    rows.to_csv(tables / f"population_mask_sensitivity_{year}.csv", index=False, encoding="utf-8-sig")
    (tables / f"population_mask_sensitivity_{year}.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
