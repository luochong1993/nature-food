"""Five-figure manuscript contract and Python-only evidence figures.

Contract: 183 mm, Arial 7 pt, editable PDF/SVG, PNG and 600 dpi TIFF.
Main 1 definition contrasts; 2 national transitions; 3 accounting components;
4 weighted exposure; 5 demographic loading. No causal interpretation of the
accounting identity. Every country in the stated subset is shown, not trimmed.
"""
from pathlib import Path
import json,shutil,io,re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
import tifffile

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'07_manuscript/packages/nature_sustainability/revision_20261020_exposure'
OUT=BASE.parent/'manuscript_five_figures_20261020'
FIG=OUT/'figures';SD=OUT/'source_data'
for p in (FIG,SD):p.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.titlesize':7,'axes.labelsize':7,'xtick.labelsize':6,'ytick.labelsize':6,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,'pdf.fonttype':42,'svg.fonttype':'none','legend.frameon':False})
BLUE='#3d7093';RED='#b85443';GOLD='#c6832e'
CAP={}

def axis(f,rect,letter,title):
    a=f.add_axes(rect);a.text(-.10,1.045,letter,transform=a.transAxes,fontsize=8,weight='bold',va='bottom');a.set_title(title,loc='left',pad=8);return a

def save(f,name):
    for ext in ['pdf','svg','png']:f.savefig(FIG/(name+'.'+ext),dpi=300)
    b=io.BytesIO();f.savefig(b,format='png',dpi=600);b.seek(0)
    tifffile.imwrite(FIG/(name+'.tiff'),np.array(Image.open(b).convert('RGB')),compression='zlib',resolution=(600,600),metadata=None)
    plt.close(f);print('Exported',name,flush=True)

def composition_only():
    c=pd.read_csv(BASE/'source_data/national_crop_weight_and_decomposition.csv')
    c=c[c.robust_151.astype(str).str.lower()=='true']
    f=plt.figure(figsize=(183/25.4,100/25.4))
    lim=[min(c.potential_capacity_mt_pressure_log2.min(),c.energy_pressure.min(),c.protein_pressure.min())-.3,max(c.potential_capacity_mt_pressure_log2.max(),c.energy_pressure.max(),c.protein_pressure.max())+.3]
    for i,(metric,color,label) in enumerate([('energy',BLUE,'Energy-composition weights'),('protein','#8562a8','Protein-composition weights')]):
        a=axis(f,[.10+.50*i,.20,.35,.66],chr(97+i),label)
        a.axvspan(-.5,.5,color='#f0f0f0',zorder=-2);a.axhspan(-.5,.5,color='#f0f0f0',zorder=-2)
        a.scatter(c.potential_capacity_mt_pressure_log2,c[metric+'_pressure'],c=color,s=11,alpha=.65)
        a.plot(lim,lim,'--',c='#777',lw=.6);a.set_xlim(lim);a.set_ylim(lim)
        a.set_xlabel('Tonnes-based pressure (log2)');a.set_ylabel('Composition-weighted pressure (log2)')
        rho=.9986685256186824 if metric=='energy' else .987148832345765;changed=4 if metric=='energy' else 19
        a.text(.04,.94,'n = 151; '+r'$r_s$'+f' = {rho:.4f}\n{changed} codes change class',transform=a.transAxes,va='top',fontsize=6)
    save(f,'Supplementary_Fig6_crop_composition_sensitivity')

def generate():
    oldcaps=[c.strip() for c in re.split(r'\n\s*\n',(BASE/'figure_legends.md').read_text(encoding='utf-8')) if c.strip()]
    fallback=[c.strip() for c in re.split(r'\n\s*\n',(BASE.parent/'revision_20261020/figure_legends.md').read_text(encoding='utf-8')) if c.strip()]
    oldcaps+=fallback
    mapping=[('Fig1_area_pressure_and_resource_definition_differences','Fig1_resource_definition_contrasts',1),('Fig2_three_definition_national_transitions','Fig2_national_classification_transitions',2),('Fig3_population_area_and_capacity_exposure','Fig4_population_and_capacity_exposure',4),('Fig4_historical_and_future_fixed_resource_loading','Fig5_historical_and_future_loading',5)]
    for src,dst,num in mapping:
        for ext in ['pdf','svg','png','tiff']:shutil.copy2(BASE/'figures'/(src+'.'+ext),FIG/(dst+'.'+ext))
        oldnum=int(src[3]);caption=next(c for c in oldcaps if c.startswith(f'Fig. {oldnum} |'))
        caption=caption.replace(f'Fig. {oldnum} |',f'Fig. {num} |',1)
        if num==2:caption=caption.replace('All-240-code transitions and illustrative national profiles remain available in the preceding source release.','Transitions for all 240 populated codes and illustrative national profiles are reported in Supplementary Tables 10 and 3, respectively.')
        if num==1:caption=caption.replace('Source arrays are unchanged from the preceding audited release.','Source Data include the full-precision contrast arrays and display-range audit.')
        caption=caption.replace('map_display_range_audit.csv','the Source Data display-range audit').replace('Source data: Supplementary_Table4_weighted_exposure.csv.','Source Data are provided.')
        CAP[dst]=caption
    for num in [1,2,3,4,5]:
        name=next(p.stem for p in (BASE/'figures').glob(f'Supplementary_Fig{num}_*.png'))
        for ext in ['pdf','svg','png','tiff']:shutil.copy2(BASE/'figures'/(name+'.'+ext),FIG/(name+'.'+ext))
        CAP[name]=next(c for c in oldcaps if c.startswith(f'Supplementary Fig. {num} |'))
    c=pd.read_csv(BASE/'source_data/national_crop_weight_and_decomposition.csv')
    c=c[c.robust_151.astype(str).str.lower()=='true'].copy();assert len(c)==151
    types=pd.read_csv(BASE/'source_data/country_accounting_typology.csv')
    f=plt.figure(figsize=(183/25.4,172/25.4))
    a=axis(f,[.10,.54,.44,.36],'a','Harvest geography and attainable yield')
    a.scatter(c.harvest_component,c.yield_component,c=np.where(c.delta_capacity_area<0,BLUE,RED),s=13,alpha=.72)
    a.axhline(0,c='#bbb',lw=.5);a.axvline(0,c='#bbb',lw=.5)
    xx=[c.harvest_component.min()-.5,c.harvest_component.max()+.5];yy=[c.yield_component.min()-.6,c.yield_component.max()+.5]
    a.plot(xx,[-xx[0],-xx[1]],'--',c='#666',lw=.7);a.set_xlim(xx);a.set_ylim(yy)
    a.set_xlabel('Harvest/physical-area component (log2)');a.set_ylabel('Attainable-yield component (log2)')
    for iso,offset in {'SLE':(-8,16),'IRQ':(12,15),'CHN':(20,10),'USA':(18,-18)}.items():
        r=c[c.iso3==iso].iloc[0];a.annotate(iso,(r.harvest_component,r.yield_component),xytext=offset,textcoords='offset points',fontsize=6,arrowprops={'arrowstyle':'-','lw':.4,'color':'#777'})
    a=axis(f,[.76,.54,.21,.36],'b','National accounting types')
    y=np.arange(4)
    a.barh(y,-types.capacity_pressure_lower,color=BLUE,height=.6,label='Lower pressure')
    a.barh(y,types.capacity_pressure_higher,color=RED,height=.6,label='Higher pressure')
    a.set_yticks(y,['High H/A\nhigh yield','High H/A\nlow yield','Low H/A\nhigh yield','Low H/A\nlow yield'],fontsize=5.5);a.invert_yaxis();a.axvline(0,c='#777',lw=.5)
    a.set_xlim(-30,45);a.set_xticks([-20,0,20,40],['20','0','20','40']);a.set_xlabel('National codes')
    for i,r in types.iterrows():
        if r.capacity_pressure_lower:a.text(-r.capacity_pressure_lower-.8,i,str(r.capacity_pressure_lower),ha='right',va='center',fontsize=6)
        if r.capacity_pressure_higher:a.text(r.capacity_pressure_higher+.8,i,str(r.capacity_pressure_higher),ha='left',va='center',fontsize=6)
    a.legend(loc='lower center',bbox_to_anchor=(.35,-.27),ncol=1,fontsize=5.5)
    a=axis(f,[.22,.11,.73,.25],'c','Accounting components in illustrative national cases')
    sample=c.set_index('iso3').loc[['SLE','NIC','NPL','IRQ','CHN','IND','BRA','USA']];y=np.arange(8)
    a.barh(y-.15,sample.harvest_component,height=.27,color=BLUE,label='Harvest/physical-area component')
    a.barh(y+.15,sample.yield_component,height=.27,color=GOLD,label='Attainable-yield component')
    a.scatter(sample.delta_capacity_area,y,c='#222',marker='D',s=13,label='Net capacity − area pressure',zorder=4)
    a.set_yticks(y,sample.index);a.invert_yaxis();a.axvline(0,c='#999',lw=.5);a.set_xlabel('Pressure change or component (log2)')
    a.legend(loc='lower center',bbox_to_anchor=(.5,-.37),ncol=2,fontsize=5.5)
    save(f,'Fig3_national_accounting_decomposition')
    CAP['Fig3_national_accounting_decomposition']='Fig. 3 | Harvest geography and attainable yield account for national pressure contrasts. a, Components of capacity-minus-area pressure for 151 national codes with at least one million inhabitants and positive area, quality-equivalent and capacity stocks. Components are negative logarithms of each national harvest/physical-area ratio and weighted attainable yield relative to the corresponding ratios of country-domain totals. The dashed line denotes zero unregularised net change. Blue/red points indicate lower/higher capacity-based pressure. b, Counts with lower or higher capacity pressure in the four accounting types; high and low refer to the same domain ratios, not country medians. H denotes matched four-crop harvested area and A physical cropland. c, Two components and the net stabilised pressure contrast for eight illustrative cases. Component sums use the unregularised identity; the maximum stabilisation/rounding residual in the 151-code set is 2.3 × 10−5 log2 units. This decomposition is an accounting identity, not independent evidence of climate, irrigation or multiple-cropping causation. Source Data contain all national components and comparison-set flags.'
    f=plt.figure(figsize=(183/25.4,100/25.4))
    lim=[min(c.potential_capacity_mt_pressure_log2.min(),c.energy_pressure.min(),c.protein_pressure.min())-.3,max(c.potential_capacity_mt_pressure_log2.max(),c.energy_pressure.max(),c.protein_pressure.max())+.3]
    for i,(metric,color,label) in enumerate([('energy',BLUE,'Energy-composition weights'),('protein','#8562a8','Protein-composition weights')]):
        a=axis(f,[.10+.50*i,.20,.35,.66],chr(97+i),label)
        a.axvspan(-.5,.5,color='#f0f0f0',zorder=-2);a.axhspan(-.5,.5,color='#f0f0f0',zorder=-2)
        a.scatter(c.potential_capacity_mt_pressure_log2,c[metric+'_pressure'],c=color,s=11,alpha=.65)
        a.plot(lim,lim,'--',c='#777',lw=.6);a.set_xlim(lim);a.set_ylim(lim)
        a.set_xlabel('Tonnes-based pressure (log2)');a.set_ylabel('Composition-weighted pressure (log2)')
        rho=.9986685256186824 if metric=='energy' else .987148832345765;changed=4 if metric=='energy' else 19
        a.text(.04,.94,'n = 151; '+r'$r_s$'+f' = {rho:.4f}\n{changed} codes change class',transform=a.transAxes,va='top',fontsize=6)
    save(f,'Supplementary_Fig6_crop_composition_sensitivity')
    CAP['Supplementary_Fig6_crop_composition_sensitivity']='Supplementary Fig. 6 | Sensitivity to relative crop-composition weights. a,b, Capacity pressure under energy- and protein-composition weights versus the tonnes baseline in the same 151-code restricted set. The dashed line denotes equality and shaded bands denote ±0.5 balance on each axis. Spearman correlations and class changes relative to the tonnes baseline are labelled. Weights are ratios of FAO as-purchased commodity coefficients to wheat coefficients, applied as dimensionless scenarios to configured crop-specific capacity. They are not edible-calorie or protein production, because dry matter, moisture, processing and utilisation bases are not harmonised. The same full-country-domain normalisation is used for each scenario. Source Data retain all points and both the 151-code and positive-capacity-only 180-code summaries.'
    old=ROOT/'07_manuscript/packages/nature_communications/revision_20261015/figures/Supplementary_Fig4_resource_concentration'
    for ext in ['pdf','svg','png','tiff']:shutil.copy2(old.with_suffix('.'+ext),FIG/('Supplementary_Fig7_resource_concentration.'+ext))
    CAP['Supplementary_Fig7_resource_concentration']='Supplementary Fig. 7 | Concentration of national resource totals. a, Lorenz curves for physical cropland, quality-equivalent cropland and attainable capacity across the 240 populated national codes, sorting each resource independently and weighting countries equally. The dashed line denotes equal stocks across countries. b, Corresponding Gini coefficients of 0.868, 0.873 and 0.887. These describe marginal resource concentration, not joint population–resource mismatch. Source Data provide national stocks and Lorenz coordinates.'
    for p in (BASE/'source_data').iterdir():
        if p.is_file():shutil.copy2(p,SD/p.name)
    oldsd=ROOT/'07_manuscript/packages/nature_communications/revision_20261015/source_data'
    for p in oldsd.glob('*lorenz*'):shutil.copy2(p,SD/p.name)
    (OUT/'figure_legends.json').write_text(json.dumps(CAP,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'figure_contract.md').write_text(__doc__+'\n',encoding='utf-8')
    print('Five main figures and seven supplementary figures ready',flush=True)

if __name__=='__main__':generate()
