"""Five evidence-led Python figures, with panel-level source tables.

Contract: resource-definition effect; reclassification; accounting geography;
weighted exposure; future redistribution. Nature quantitative grids, 183 mm,
Arial 7 pt, editable vectors and 600 dpi TIFF. No inferential error bars on
deterministic comparisons; country quartiles are descriptive, not uncertainty.
"""
from pathlib import Path
import io,json,shutil
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import ListedColormap
from PIL import Image
import tifffile
import revise_nc_figures as v

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'07_manuscript/packages/nature_sustainability/regional_imbalance_20261020'
OUT=BASE.parent/'evidence_figures_20261020'
FIG=OUT/'figures';SD=OUT/'source_data'
for p in [OUT,FIG,SD]:p.mkdir(exist_ok=True)
BLUE='#3d7093';RED='#b85443';GOLD='#c6832e';PURPLE='#8562a8';TEAL='#287d8e'
RESOURCE_COL=[TEAL,PURPLE,GOLD]
plt.rcParams.update({'legend.frameon':False})
REGIONS=['Africa','Asia','Europe','North America','South America','Oceania']
KEYS=['cropland_area_ha','quality_equivalent_cropland_ha','potential_capacity_mt']
SHORT=['Area','Quality-equivalent','Capacity']
NAMES=['Fig1_resource_definitions_and_imbalance','Fig2_national_reclassification','Fig3_accounting_geography','Fig4_population_capacity_separation','Fig5_future_regional_divergence']
CAP={};STATS={}
C=pd.read_csv(BASE/'source_data/national_crop_weight_and_decomposition.csv')
C=C[C.robust_151.astype(str).str.lower()=='true'].copy();assert len(C)==151
MATCH=pd.read_csv(BASE/'source_data/matched_country_continental_inputs.csv')
REG=pd.read_csv(BASE/'source_data/continental_pressure_all_ssps.csv')
TV=pd.read_csv(BASE/'source_data/continental_population_resource_total_variation.csv')

def axis(f,rect,letter,title):
    a=f.add_axes(rect);a.set_title(title,loc='left',pad=8,fontsize=7)
    a.text(-.10,1.04,letter,transform=a.transAxes,weight='bold',fontsize=8,va='bottom')
    return a

def figure(h):return plt.figure(figsize=(183/25.4,h/25.4))

def save(f,name,caption):
    for ext in ['pdf','svg','png']:f.savefig(FIG/(name+'.'+ext),dpi=300)
    buf=io.BytesIO();f.savefig(buf,format='png',dpi=600);buf.seek(0)
    tifffile.imwrite(FIG/(name+'.tiff'),np.array(Image.open(buf).convert('RGB')),compression='zlib',resolution=(600,600),metadata=None)
    plt.close(f);CAP[name]=caption;print('EXPORTED',name,flush=True)

def regional_exposure():
    units=pd.read_csv(BASE/'source_data/map_unit_audit.csv')
    assert len(units)==266
    labels=units.continent.replace({'Seven seas (open ocean)':'Other island territories'})
    groups=sorted(labels.unique());lut=np.zeros(int(units.country_id.max())+1,dtype='int8')
    for cid,region in zip(units.country_id,labels):lut[int(cid)]=groups.index(region)
    ids=lut[v.CID];cls=v.classify(v.M);m=v.ACTIVE
    code=ids[m]*7+cls[m]
    latitude=np.deg2rad(90-np.arange(2161)/12)
    rowarea=6371.0088**2*np.deg2rad(1/12)*(np.sin(latitude[:-1])-np.sin(latitude[1:]))
    area=np.broadcast_to(rowarea[:,None],v.P.shape)
    arrays={'cells':np.ones(code.size),'area':area[m],'population':v.P[m].astype('float64'),'capacity':v.R[2][m].astype('float64'),'cropland':v.R[0][m].astype('float64')}
    sums={k:np.bincount(code,weights=w,minlength=7*len(groups)).reshape(len(groups),7) for k,w in arrays.items()}
    rows=[]
    for g,region in enumerate(groups):
        if sums['cells'][g].sum()==0:continue
        for cl in range(7):
            r=dict(region=region,display_class=cl,label=v.CLABEL[cl])
            for k,x in sums.items():
                r[k]=float(x[g,cl]);r[k+'_percent']=100*x[g,cl]/x[g].sum() if x[g].sum()>0 else np.nan
            rows.append(r)
    df=pd.DataFrame(rows);df.to_csv(SD/'fig4_regional_class_exposure.csv',index=False)
    old=pd.read_csv(BASE/'source_data/Supplementary_Table4_weighted_exposure.csv')
    old=old[old.support=='active_domain'].sort_values('display_class')
    for key,oldkey in [('cells','cells'),('population','population'),('capacity','capacity_t'),('cropland','cropland_ha')]:
        assert np.allclose(df.groupby('display_class')[key].sum().values,old[oldkey].values,rtol=2e-7)
    assert np.allclose(df.groupby('display_class').area.sum().values,old.spherical_cell_area_km2,rtol=2e-7)
    return df,cls

def fig1():
    rows=[];p=MATCH['2020']/MATCH['2020'].sum()
    reg=REG[REG.scenario=='SSP2'].copy()
    for key,label in zip(KEYS,SHORT):
        stock=MATCH[key+'_total']/MATCH[key+'_total'].sum()
        country=.5*np.abs(p-stock).sum()
        col=['area','quality','capacity'][KEYS.index(key)]
        continental=float(TV[(TV.resource==col)&(TV.scenario=='SSP2')].tv_2020.iloc[0])
        rows.extend([dict(scale='National codes (201)',resource=label,distance=country),dict(scale='Continental groups (7)',resource=label,distance=continental)])
    pd.DataFrame(rows).to_csv(SD/'fig1_multiscale_population_resource_imbalance.csv',index=False)
    reg[reg.region.isin(REGIONS)].to_csv(SD/'fig1_continental_baseline_pressures.csv',index=False)
    f=figure(164)
    for i,j in enumerate([1,2]):
        a=axis(f,[.07+.50*i,.61,.40,.29],chr(97+i),['Quality-equivalent minus area pressure','Capacity minus area pressure'][i])
        im=v.mapplot(a,v.M[j]-v.M[0],vmin=-3,vmax=3,mask=v.COMMON)
    cb=f.add_axes([.30,.565,.43,.012]);c=f.colorbar(im,cax=cb,orientation='horizontal',extend='both',ticks=[-3,0,3]);c.set_label('Pressure difference (log2)',labelpad=2);c.ax.tick_params(labelsize=6,length=2)
    a=axis(f,[.17,.15,.34,.29],'c','Which continents change pressure?')
    reg=reg.set_index('region').loc[REGIONS];y=np.arange(6)
    for j,key in enumerate(['area','quality','capacity']):
        a.scatter(reg[key+'_pressure_2020_log2'],y+(j-1)*.18,color=RESOURCE_COL[j],marker=['o','s','^'][j],s=18,label=SHORT[j])
    a.axvspan(-.5,.5,color='#f0f0f0',zorder=-1);a.axvline(0,color='#888',lw=.5)
    a.set_yticks(y,REGIONS);a.set_ylim(5.6,-.6);a.set_xlim(-2.1,1.5);a.set_xlabel('Regional pressure (log2)')
    a.legend(ncol=1,loc='upper left',bbox_to_anchor=(-.01,-.23),fontsize=6)
    a=axis(f,[.68,.15,.29,.29],'d','How much imbalance is missed?')
    for j,(scale,mark) in enumerate([('National codes (201)','o'),('Continental groups (7)','s')]):
        vals=[next(r['distance'] for r in rows if r['scale']==scale and r['resource']==lab) for lab in SHORT]
        a.plot(range(3),vals,color=BLUE if j==0 else '#777',marker=mark,lw=.8,ms=4,label=scale)
        for x,val in enumerate(vals):a.text(x,val+(.009 if j==0 else -.018),f'{val:.3f}',ha='center',fontsize=6)
    a.set_xticks(range(3),['Area','Quality-\nequivalent','Capacity']);a.set_ylim(.20,.48);a.set_ylabel('Total-variation distance')
    a.legend(loc='upper center',bbox_to_anchor=(.5,-.25),fontsize=5.7)
    STATS['multiscale_imbalance']=rows
    save(f,NAMES[0],'Fig. 1 | Resource definitions alter both the geography and magnitude of population–cropland imbalance. a,b, Quality-equivalent-minus-area and capacity-minus-area pressure on the same 569,780 common-positive cells. Shares retain full-country-domain normalisation; white denotes unsupported cells, not zero differences. The common colour limits are ±3 log2 units, with numerical extremes retained in Source Data. Maps sample every second row and column. c, Continental pressures for all three definitions on the matched 201-code domain, summing stocks before calculating shares. The shaded interval is ±0.5 log2 units. d, Paired population–resource total-variation distances at national and continental scales on those same 201 codes, including zero resource stocks. Seven exhaustive geographic groups enter continental calculations, although the six continents are displayed in c. This paired mismatch statistic is not the marginal resource Gini. National and continental normalisation is separate from the full-grid map support. Source Data are provided.')

def fig2():
    f=figure(166);bands=[C[k+'_band'] for k in KEYS]
    for i,(start,end,title) in enumerate([(0,1,'Area → quality'),(1,2,'Quality → capacity'),(0,2,'Area → capacity')]):
        a=axis(f,[.09+.31*i,.62,.23,.25],chr(97+i),title)
        mat=pd.crosstab(bands[end],bands[start]).reindex(index=[0,1,2],columns=[0,1,2],fill_value=0).to_numpy()
        a.imshow(mat,cmap='Blues',vmin=0,vmax=70,aspect='auto');a.set_xticks(range(3),['S','B','P']);a.set_yticks(range(3),['S','B','P']);a.set_xlabel('From');a.set_ylabel('To')
        for row in range(3):
            for col in range(3):a.text(col,row,str(mat[row,col]),ha='center',va='center',fontsize=7,color='white' if mat[row,col]>40 else '#222')
        a.text(.5,-.37,f'{151-np.trace(mat)} / 151 change class',transform=a.transAxes,ha='center',fontsize=6)
    rates=[]
    for region in REGIONS:
        x=C[C.continent==region];changed=x[KEYS[0]+'_band']!=x[KEYS[2]+'_band']
        rates.append(dict(region=region,n=len(x),changed=int(changed.sum()),country_percent=100*changed.mean(),population_percent=100*x.loc[changed,'population_total'].sum()/x.population_total.sum()))
    pd.DataFrame(rates).to_csv(SD/'fig2_regional_reclassification_exposure.csv',index=False)
    a=axis(f,[.17,.15,.31,.28],'d','Reclassification within each continent')
    for j,(k,lab,col,marker) in enumerate([('country_percent','National codes',BLUE,'o'),('population_percent','Baseline population',GOLD,'D')]):
        a.scatter([r[k] for r in rates],np.arange(6)+(j-.5)*.2,c=col,s=19,marker=marker,label=lab)
    a.set_yticks(range(6),[f'{r["region"]} (n={r["n"]})' for r in rates]);a.set_ylim(5.6,-.6);a.set_xlim(-2,102);a.set_xlabel('Area-to-capacity reclassification (%)')
    a.legend(loc='upper left',bbox_to_anchor=(-.02,-.24),fontsize=6)
    a=axis(f,[.66,.15,.30,.28],'e','Class change versus pressure magnitude')
    changed=C[KEYS[0]+'_band']!=C[KEYS[2]+'_band'];x=C[KEYS[0]+'_pressure_log2'];y=C[KEYS[2]+'_pressure_log2']
    a.axhspan(-.5,.5,color='#f0f0f0',zorder=-2);a.axvspan(-.5,.5,color='#f0f0f0',zorder=-2)
    a.scatter(x[~changed],y[~changed],s=11,c='#a1a1a1',alpha=.7,label='Same class');a.scatter(x[changed],y[changed],s=15,c=RED,alpha=.8,label='Changed class')
    lim=[min(x.min(),y.min())-.5,max(x.max(),y.max())+.5];a.plot(lim,lim,'--',c='#666',lw=.6);a.set_xlim(lim);a.set_ylim(lim)
    a.set_xlabel('Area pressure (log2)');a.set_ylabel('Capacity pressure (log2)');a.legend(loc='upper center',bbox_to_anchor=(.5,-.24),ncol=2,fontsize=5.5)
    save(f,NAMES[1],'Fig. 2 | Resource choice changes national classes and the populations represented by those changes. a–c, Pairwise transition matrices for the identical 151 national codes with at least one million inhabitants and positive area, quality-equivalent and capacity stocks. Columns are starting classes and rows destination classes; S, B and P indicate surplus, balance and pressure at ±0.5 log2 thresholds. d, Area-to-capacity class changes weighted by national-code count or baseline population within each displayed continent. Both denominators are restricted to that continent’s qualifying codes; n labels the code count. Population weighting describes people represented by reclassified national indices, not affected or food-insecure people. e, Full-range national pressures, with changed classes highlighted and the equality line dashed. All 151 points are retained; shaded bands denote balance on each axis. Complete ordered three-definition paths are shown in Supplementary Fig. 9 and Source Data. No inferential tests are applied.')

def fig3():
    f=figure(173)
    a=axis(f,[.10,.58,.36,.32],'a','Harvest geography and attainable yield')
    a.scatter(C.harvest_component,C.yield_component,c=np.where(C.delta_capacity_area<0,BLUE,RED),s=12,alpha=.72)
    a.axhline(0,c='#aaa',lw=.5);a.axvline(0,c='#aaa',lw=.5)
    xx=[C.harvest_component.min()-.5,C.harvest_component.max()+.5];yy=[C.yield_component.min()-.5,C.yield_component.max()+.5]
    a.plot(xx,[-xx[0],-xx[1]],'--',c='#777',lw=.6);a.set_xlim(xx);a.set_ylim(yy)
    a.set_xlabel('Harvest/physical-area component (log2)');a.set_ylabel('Attainable-yield component (log2)')
    a.text(.03,.96,'n = 151 national codes',transform=a.transAxes,va='top',fontsize=6)
    a.legend(handles=[Line2D([],[],c=BLUE,marker='o',ls='none',ms=3,label='Lower capacity pressure'),Line2D([],[],c=RED,marker='o',ls='none',ms=3,label='Higher capacity pressure')],loc='upper center',bbox_to_anchor=(.5,-.23),fontsize=5.5)
    types=['High harvest/physical; high yield','High harvest/physical; low yield','Low harvest/physical; high yield','Low harvest/physical; low yield']
    # Preserve source labels rather than infer type order from display text.
    source_types=pd.read_csv(BASE/'source_data/country_accounting_typology.csv').accounting_type.tolist()
    typ=[]
    for region in REGIONS:
        x=C[C.continent==region]
        for typenum,ty in enumerate(source_types):typ.append(dict(region=region,accounting_type=ty,n=int((x.accounting_type==ty).sum()),denominator=len(x),percent=100*(x.accounting_type==ty).mean()))
    pd.DataFrame(typ).to_csv(SD/'fig3_regional_accounting_types.csv',index=False)
    a=axis(f,[.65,.58,.32,.32],'b','Accounting types differ across continents')
    left=np.zeros(6);colors=[BLUE,'#82a8b8',GOLD,RED]
    labels=['High H/A; high yield','High H/A; low yield','Low H/A; high yield','Low H/A; low yield']
    for i,ty in enumerate(source_types):
        values=[next(r['percent'] for r in typ if r['region']==g and r['accounting_type']==ty) for g in REGIONS]
        a.barh(range(6),values,left=left,color=colors[i],height=.65,label=labels[i],edgecolor='white',lw=.3);left+=values
    a.set_yticks(range(6),[f'{r} (n={sum(C.continent==r)})' for r in REGIONS]);a.set_ylim(5.5,-.5);a.set_xlim(0,100);a.set_xlabel('National codes within continent (%)')
    a.legend(loc='upper left',bbox_to_anchor=(-.05,-.22),ncol=2,fontsize=5.3,columnspacing=.7)
    comp=[]
    a=axis(f,[.17,.14,.30,.26],'c','National accounting-component distributions')
    for j,(metric,col,label) in enumerate([('harvest_component',BLUE,'Harvest/physical area'),('yield_component',GOLD,'Attainable yield')]):
        for i,g in enumerate(REGIONS):
            q=C.loc[C.continent==g,metric].quantile([.25,.5,.75]).values
            comp.append(dict(region=g,component=metric,q25=q[0],median=q[1],q75=q[2],n=int(sum(C.continent==g))))
            a.plot([q[0],q[2]],[i+(j-.5)*.22]*2,c=col,lw=1.4);a.scatter(q[1],i+(j-.5)*.22,c=col,s=15,marker='o' if j==0 else 'D')
    a.axvline(0,c='#777',lw=.5);a.set_yticks(range(6),REGIONS);a.set_ylim(5.6,-.6);a.set_xlabel('Median and interquartile range (log2)')
    a.legend(handles=[Line2D([],[],c=BLUE,marker='o',lw=1,label='Harvest/physical area'),Line2D([],[],c=GOLD,marker='D',lw=1,label='Attainable yield')],loc='upper left',bbox_to_anchor=(-.01,-.24),fontsize=5.8)
    pd.DataFrame(comp).to_csv(SD/'fig3_regional_component_quartiles.csv',index=False)
    crops=pd.read_csv(BASE/'source_data/national_crop_components.csv').merge(C[['iso3','continent']],on='iso3',validate='many_to_one')
    h=crops.groupby(['continent','crop']).matched_harvested_area_ha.sum().unstack().reindex(REGIONS)[['WHE','MZE','RCD','SOY']];h=h.div(h.sum(axis=1),axis=0)*100
    h.to_csv(SD/'fig3_four_crop_harvest_composition.csv')
    a=axis(f,[.68,.14,.29,.26],'d','Four-crop harvested-area composition')
    im=a.imshow(h.to_numpy(),cmap='YlGnBu',vmin=0,vmax=100,aspect='auto')
    a.set_xticks(range(4),['Wheat','Maize','Rice','Soybean'],rotation=30,ha='right');a.set_yticks(range(6),REGIONS)
    for i in range(6):
        for j in range(4):a.text(j,i,'<1' if 0<h.iloc[i,j]<.5 else f'{h.iloc[i,j]:.0f}',ha='center',va='center',fontsize=6,color='white' if h.iloc[i,j]>55 else '#222')
    a.set_xlabel('Matched harvested area within continent (%)')
    save(f,NAMES[2],'Fig. 3 | National accounting contrasts have distinct regional compositions. a, Harvested-to-physical-area and attainable-yield components for all 151 restricted national codes. Blue/red points have lower/higher capacity-based pressure; the dashed line marks zero unregularised net change. b, National-code composition of four accounting types within each continent. High/low refer to the corresponding ratios of full-country-domain totals, not country medians; H denotes matched four-crop harvested area and A physical cropland. c, Country-level median components with interquartile ranges, giving countries equal weight; these are descriptive distributions, not confidence intervals, causal effects or a decomposition of aggregated regional pressure. d, Four-crop shares of matched harvested area, summed over the same restricted codes within each continent. Values are percentages, not nutritional contributions or fractions of all physical cropland. All panels use the same 151-code set. The accounting identity does not identify climate, irrigation or multiple cropping as causes. Source Data retain country components and crop inputs.')

def fig4(exposure,cls):
    f=figure(183)
    a=axis(f,[.08,.68,.89,.23],'a','Where population and represented capacity separate')
    v.mapplot(a,cls,cmap=ListedColormap(v.CC),vmin=-.5,vmax=6.5,mask=v.ACTIVE)
    handles=[Line2D([],[],marker='s',color='none',markerfacecolor=co,markeredgecolor='none',ms=4,label=lab) for co,lab in zip(v.CC,v.CLABEL)]
    f.legend(handles=handles,loc='center',bbox_to_anchor=(.52,.615),ncol=3,fontsize=5.3,columnspacing=1)
    a=axis(f,[.28,.34,.66,.20],'b','Cell prevalence is not population or capacity exposure')
    d=pd.read_csv(BASE/'source_data/Supplementary_Table4_weighted_exposure.csv');d=d[d.support=='active_domain'].sort_values('display_class')
    for j,(key,label,col,mark) in enumerate([('cells','Active cells','#888','o'),('area','Whole-cell area',TEAL,'s'),('population','Population',RED,'D'),('capacity','Capacity',GOLD,'^')]):
        a.scatter(d[key+'_percent'],np.arange(7)+(j-1.5)*.15,c=col,s=15,marker=mark,label=label)
    a.set_yticks(range(7),['All balanced','All pressure','All surplus','Area P; capacity B','Area B; capacity P','Opposite area–capacity','Other']);a.set_ylim(6.7,-.7);a.set_xlim(-1,100);a.set_xlabel('Share of the stated active-domain denominator (%)')
    a.legend(loc='upper center',bbox_to_anchor=(.5,1.30),ncol=4,fontsize=5.7)
    for j,(metric,title) in enumerate([('population','Where each continent’s population lies'),('capacity','Where each continent’s capacity lies')]):
        a=axis(f,[.17+.49*j,.08,.31,.16],chr(99+j),title)
        left=np.zeros(6)
        for cl in range(7):
            vals=[exposure[(exposure.region==g)&(exposure.display_class==cl)][metric+'_percent'].iloc[0] for g in REGIONS]
            a.barh(range(6),vals,left=left,color=v.CC[cl],edgecolor='white',lw=.2,height=.7);left+=vals
        assert np.allclose(left,100)
        a.set_yticks(range(6),REGIONS);a.set_ylim(5.5,-.5);a.set_xlim(0,100);a.set_xticks([0,50,100]);a.set_xlabel(f'{metric.capitalize()} within continent (%)')
    STATS['regional_pressure_exposure']=exposure[exposure.display_class==1][['region','population_percent','capacity_percent']].to_dict('records')
    save(f,NAMES[3],'Fig. 4 | Population and capacity occupy different concordant pressure classes within and across continents. a, Seven display classes on the active raster domain; map display is subsampled by two. b, Class shares weighted by cell count, spherical whole-cell area, population or capacity at full resolution. c,d, The same seven classes weighted by population and capacity separately within each continent. Each continental bar sums to 100% of that continent’s represented stock, not 100% of the global stock. All classification thresholds are ±0.5 log2 units and pressure normalisation retains the full country domain. Structural-zero cells are excluded from cell/area denominators but carry no population or capacity. Whole-cell area is spherical raster-domain area rather than fractional land area. Continental labels follow each map unit’s retained geographic metadata. These descriptive exposures do not measure hunger, food access or trade dependence. Source Data include all geographic groups and full-resolution values.')

def fig5():
    f=figure(175);s=REG[REG.scenario=='SSP2'].set_index('region').loc[REGIONS]
    a=axis(f,[.17,.59,.31,.30],'a','Population shifts against fixed capacity')
    for j,(col,label,color,mark) in enumerate([('population_share_2020_percent','Population 2020',BLUE,'o'),('population_share_2050_percent','Population 2050 SSP2',RED,'D'),('capacity_share_percent','Fixed capacity',GOLD,'^')]):
        a.scatter(s[col],np.arange(6)+(j-1)*.18,c=color,marker=mark,s=16,label=label)
    a.set_yticks(range(6),REGIONS);a.set_ylim(5.5,-.5);a.set_xlim(-1,65);a.set_xlabel('Matched-domain stock share (%)');a.grid(axis='x',color='#eee',lw=.5)
    a.legend(loc='upper left',bbox_to_anchor=(-.04,1.32),ncol=2,fontsize=5.4,columnspacing=.7)
    a=axis(f,[.67,.59,.29,.30],'b','Pressure diverges across continents')
    for i,g in enumerate(REGIONS):
        vals=REG[REG.region==g].set_index('scenario').delta_pressure_log2
        a.plot([vals.min(),vals.max()],[i,i],c='#999',lw=1.7);a.scatter(vals,np.full(5,i),c='#999',s=10);a.scatter(vals.SSP2,i,c=RED,marker='D',s=22,zorder=4)
    a.axvline(0,c='#444',lw=.5);a.set_yticks(range(6),REGIONS);a.set_ylim(5.5,-.5);a.set_xlim(-.52,.72);a.set_xlabel('2050 minus 2020 pressure (log2)')
    a.legend(handles=[Line2D([],[],c=RED,marker='D',ls='none',ms=4,label='SSP2'),Line2D([],[],c='#999',marker='o',lw=1,ms=3,label='Five-scenario range')],loc='upper left',bbox_to_anchor=(-.02,-.24),fontsize=5.5)
    a=axis(f,[.13,.15,.35,.27],'c','Imbalance increases in all five scenarios')
    for j,(key,color,label) in enumerate([('area',TEAL,'Area'),('quality',PURPLE,'Quality-equivalent'),('capacity',GOLD,'Capacity')]):
        x=TV[TV.resource==key].set_index('scenario');vals=[x.tv_2020.iloc[0]]+[x.loc[f'SSP{i}','tv_2050'] for i in range(1,6)]
        a.scatter(np.arange(6)+(j-1)*.12,vals,c=color,s=18,marker=['o','s','^'][j],label=label);a.axhline(vals[0],c=color,lw=.5,ls=':')
    a.set_xticks(range(6),['2020','SSP1','SSP2','SSP3','SSP4','SSP5'],rotation=35,ha='right');a.set_ylim(.23,.39);a.set_ylabel('Continental total-variation distance');a.legend(loc='upper left',fontsize=5.5)
    a.set_xlabel('Baseline and alternative 2050 endpoints')
    s=REG[REG.scenario=='SSP2'].copy();p0=s.population_share_2020_percent/100;p1=s.population_share_2050_percent/100;r=s.capacity_share_percent/100
    s['tv_change_contribution_pp']=50*(abs(p1-r)-abs(p0-r));total=float(s.tv_change_contribution_pp.sum())
    expected=float(100*(TV[(TV.resource=='capacity')&(TV.scenario=='SSP2')].tv_2050.iloc[0]-TV[(TV.resource=='capacity')&(TV.scenario=='SSP2')].tv_2020.iloc[0]));assert abs(total-expected)<1e-10
    s[['region','tv_change_contribution_pp']].to_csv(SD/'fig5_regional_contributions_to_capacity_imbalance.csv',index=False)
    order=REGIONS+['Other island territories'];s=s.set_index('region').loc[order]
    vals=s.tv_change_contribution_pp.tolist()+[total];labels=REGIONS+['Other territories','Total change']
    a=axis(f,[.72,.15,.25,.27],'d','Which regions widen the capacity gap?')
    a.barh(range(8),vals,color=[RED if x>=0 else BLUE for x in vals[:-1]]+['#444'],height=.65);a.axvline(0,c='#777',lw=.5)
    a.set_yticks(range(8),labels,fontsize=5.8);a.set_ylim(7.7,-.7);a.set_xlim(-3.4,5.2);a.set_xlabel('Contribution to ΔTV (percentage points)')
    for i,x in enumerate(vals):
        inside=x<-.5
        a.text(x+.15 if inside else x+(.08 if x>=0 else -.08),i,f'{x:+.3f}' if abs(x)<.01 else f'{x:+.2f}',ha='left' if inside or x>=0 else 'right',va='center',fontsize=5.7,color='white' if inside else '#222')
    STATS['capacity_tv_change_ssp2_pp']=total;STATS['capacity_tv_contributions_ssp2_pp']=s.tv_change_contribution_pp.to_dict()
    save(f,NAMES[4],'Fig. 5 | Regional pressure relief can coexist with a widening continental population–capacity gap. a, Continental population shares in 2020 and SSP2 2050 compared with fixed capacity shares. b, Pressure changes across five 2050 scenarios; diamonds denote SSP2 and grey points/ranges alternative endpoints, not confidence intervals. The pressure change is common to all fixed resource definitions. c, Paired continental population–resource total-variation distances. Dotted lines mark 2020 baselines; the future columns are alternative scenarios, not sequential times. d, SSP2 regional contributions to the change in capacity-based distance, calculated as one half of the change in each region’s absolute population-minus-capacity share gap, expressed in percentage points. Signed contributions sum to the total. Falling pressure in an already resource-surplus region can increase its absolute share gap. All calculations retain the same 201 codes and seven geographic groups. Six continents are displayed in a,b; other island territories remain in denominators and appear in d. Resources and within-country allocation weights are fixed. Source Data are provided.')

def joint_paths():
    df=pd.read_csv(BASE/'source_data/three_step_national_classification_paths.csv')
    mat=np.zeros((9,3),int)
    for _,r in df.iterrows():mat[int(r[KEYS[0]+'_band'])*3+int(r[KEYS[1]+'_band']),int(r[KEYS[2]+'_band'])]+=int(r['n'])
    assert mat.sum()==151
    f=figure(98);a=axis(f,[.24,.16,.57,.69],'a','Ordered area → quality → capacity paths (n = 151)')
    a.imshow(mat,cmap='Blues',vmin=0,vmax=60,aspect='auto');a.set_xticks(range(3),['Surplus','Balance','Pressure']);a.set_yticks(range(9),[f'{x} → {y}' for x in ['S','B','P'] for y in ['S','B','P']]);a.set_ylabel('Area → quality class');a.set_xlabel('Capacity class')
    for i in range(9):
        for j in range(3):a.text(j,i,str(mat[i,j]),ha='center',va='center',fontsize=7,color='white' if mat[i,j]>35 else '#222')
    save(f,'Supplementary_Fig9_ordered_joint_paths','Supplementary Fig. 9 | Complete ordered three-definition classification paths. Rows retain the joint area-to-quality pair and columns the capacity destination, giving all 27 possible paths for the same 151 restricted national codes. S, B and P denote surplus, balance and pressure at ±0.5 log2 thresholds. Counts sum to 151. This joint table preserves information that cannot be reconstructed from pairwise matrices alone. No independent replication or inferential test is implied. Source Data are provided.')

def run():
    # Existing supplementary evidence remains intact; no old manuscript is overwritten.
    inherited=json.loads((BASE/'figure_legends.json').read_text(encoding='utf-8'))
    for p in (BASE/'figures').iterdir():
        if p.name.startswith('Supplementary_'):shutil.copy2(p,FIG/p.name)
    CAP.update({k:val for k,val in inherited.items() if k.startswith('Supplementary_')})
    exposure,cls=regional_exposure()
    fig1();fig2();fig3();fig4(exposure,cls);fig5();joint_paths()
    (OUT/'figure_legends.json').write_text(json.dumps(CAP,indent=2),encoding='utf-8')
    (OUT/'figure_verification.json').write_text(json.dumps(STATS,indent=2),encoding='utf-8')
    print('COMPLETE',json.dumps(STATS),flush=True)

if __name__=='__main__':run()
