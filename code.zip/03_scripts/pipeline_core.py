"""Core spatial processing and mismatch metrics for the project."""

from __future__ import annotations

import csv
import json
import logging
import math
import re
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from pyproj import CRS
from rasterio.features import rasterize
from rasterio.io import MemoryFile
from rasterio.transform import from_origin
from rasterio.warp import Resampling, reproject


SPAM_SYSTEM_CODE = {"total": "A", "irrigated": "I", "rainfed": "R"}
SPAM_VARIABLE_CODE = {
    "harvested_area": "H",
    "physical_area": "A",
    "yield": "Y",
    "production": "P",
}


@dataclass(frozen=True)
class GridSpec:
    xmin: float
    xmax: float
    ymin: float
    ymax: float
    resolution: float
    width: int
    height: int
    crs: str = "EPSG:4326"
    earth_radius_km: float = 6371.0088

    @property
    def transform(self):
        return from_origin(self.xmin, self.ymax, self.resolution, self.resolution)

    @property
    def shape(self) -> tuple[int, int]:
        return self.height, self.width

    @property
    def lat_centers(self) -> np.ndarray:
        return self.ymax - (np.arange(self.height) + 0.5) * self.resolution

    @property
    def lon_centers(self) -> np.ndarray:
        return self.xmin + (np.arange(self.width) + 0.5) * self.resolution

    @property
    def cell_area_km2_by_row(self) -> np.ndarray:
        """Spherical area of one longitude-latitude cell for each grid row."""
        lat_n = np.deg2rad(self.ymax - np.arange(self.height) * self.resolution)
        lat_s = np.deg2rad(self.ymax - (np.arange(self.height) + 1) * self.resolution)
        dlon = math.radians(self.resolution)
        return (self.earth_radius_km**2) * dlon * (np.sin(lat_n) - np.sin(lat_s))

    def cell_area_km2(self) -> np.ndarray:
        return np.repeat(self.cell_area_km2_by_row[:, None], self.width, axis=1)


def make_grid(cfg: dict) -> GridSpec:
    spec = cfg["grid"]
    grid = GridSpec(
        xmin=float(spec["xmin"]),
        xmax=float(spec["xmax"]),
        ymin=float(spec["ymin"]),
        ymax=float(spec["ymax"]),
        resolution=float(spec["resolution"]),
        width=int(spec["width"]),
        height=int(spec["height"]),
        crs=str(spec.get("crs", "EPSG:4326")),
        earth_radius_km=float(spec.get("earth_radius_km", 6371.0088)),
    )
    expected_width = round((grid.xmax - grid.xmin) / grid.resolution)
    expected_height = round((grid.ymax - grid.ymin) / grid.resolution)
    if (grid.width, grid.height) != (expected_width, expected_height):
        raise ValueError(
            f"grid dimensions do not match extent/resolution: "
            f"configured {(grid.width, grid.height)}, expected {(expected_width, expected_height)}"
        )
    return grid


def setup_logger(log_path: Path) -> logging.Logger:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("spatial_pipeline")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    for handler in (logging.StreamHandler(), logging.FileHandler(log_path, encoding="utf-8")):
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger


def write_raster(
    path: Path,
    array: np.ndarray,
    grid: GridSpec,
    *,
    nodata: float | int = -9999,
    dtype: str | None = None,
    tags: dict | None = None,
    descriptions: Iterable[str] | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = np.asarray(array)
    if data.ndim != 2:
        raise ValueError(f"expected 2-D raster, got {data.shape}")
    out_dtype = np.dtype(dtype or data.dtype)
    if np.issubdtype(out_dtype, np.floating):
        prepared = np.where(np.isfinite(data), data, nodata).astype(out_dtype, copy=False)
    else:
        prepared = np.where(np.isfinite(data), data, nodata).astype(out_dtype, copy=False)
    profile = {
        "driver": "GTiff",
        "height": grid.height,
        "width": grid.width,
        "count": 1,
        "dtype": out_dtype.name,
        "crs": CRS.from_user_input(grid.crs),
        "transform": grid.transform,
        "nodata": nodata,
        "compress": "DEFLATE",
        "predictor": 2 if np.issubdtype(out_dtype, np.floating) else 1,
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "BIGTIFF": "IF_SAFER",
    }
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(prepared, 1)
        if tags:
            dst.update_tags(**{str(k): str(v) for k, v in tags.items()})
        if descriptions:
            dst.set_band_description(1, next(iter(descriptions)))


def write_stack(
    path: Path,
    arrays: list[np.ndarray],
    names: list[str],
    grid: GridSpec,
    *,
    nodata: float = -9999.0,
) -> None:
    if len(arrays) != len(names):
        raise ValueError("arrays and names must have equal length")
    path.parent.mkdir(parents=True, exist_ok=True)
    profile = {
        "driver": "GTiff",
        "height": grid.height,
        "width": grid.width,
        "count": len(arrays),
        "dtype": "float32",
        "crs": CRS.from_user_input(grid.crs),
        "transform": grid.transform,
        "nodata": nodata,
        "compress": "DEFLATE",
        "predictor": 2,
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "BIGTIFF": "IF_SAFER",
    }
    with rasterio.open(path, "w", **profile) as dst:
        for band, (array, name) in enumerate(zip(arrays, names), start=1):
            data = np.where(np.isfinite(array), array, nodata).astype("float32", copy=False)
            dst.write(data, band)
            dst.set_band_description(band, name)
            dst.update_tags(band, metric=name)


def read_grid_raster(path: Path) -> np.ndarray:
    with rasterio.open(path) as src:
        data = src.read(1).astype("float32", copy=False)
        nodata = src.nodata
    if nodata is not None:
        data = np.where(data == nodata, np.nan, data)
    data[~np.isfinite(data)] = np.nan
    return data


def reproject_to_grid(
    path: Path,
    grid: GridSpec,
    *,
    resampling: Resampling,
    dtype: str = "float32",
    nodata: float | int | None = None,
    respect_source_nodata: bool = True,
) -> np.ndarray:
    """Read/reproject a raster to the fixed global grid."""
    destination = np.zeros(grid.shape, dtype=dtype)
    with rasterio.open(path) as src:
        source_nodata = src.nodata if (nodata is None and respect_source_nodata) else nodata
        source_crs = src.crs or CRS.from_user_input(grid.crs)
        same_transform = np.allclose(
            tuple(src.transform)[:6],
            tuple(grid.transform)[:6],
            rtol=0.0,
            atol=1e-12,
        )
        if (
            src.shape == grid.shape
            and source_crs == CRS.from_user_input(grid.crs)
            and same_transform
        ):
            data = src.read(1).astype(dtype, copy=False)
            if source_nodata is not None:
                try:
                    nodata_is_nan = bool(np.isnan(source_nodata))
                except TypeError:
                    nodata_is_nan = False
                if nodata_is_nan:
                    data[~np.isfinite(data)] = 0.0
                else:
                    data[data == source_nodata] = 0.0
            data[~np.isfinite(data)] = np.nan
            return data
        reproject(
            source=rasterio.band(src, 1),
            destination=destination,
            src_transform=src.transform,
            src_crs=source_crs,
            src_nodata=source_nodata,
            dst_transform=grid.transform,
            dst_crs=grid.crs,
            dst_nodata=0,
            resampling=resampling,
            num_threads=2,
        )
    # Preserve the requested precision. Population counts are reprojected in
    # float64 so that country-level calibration and global closure do not
    # silently round large totals back to float32.
    data = destination.astype(dtype, copy=False)
    data[~np.isfinite(data)] = np.nan
    return data


def clean_raster_values(data: np.ndarray, *, min_value: float | None = None) -> np.ndarray:
    out = data.astype("float32", copy=False)
    out[~np.isfinite(out)] = np.nan
    if min_value is not None:
        out[out < min_value] = np.nan
    return out


def weighted_median(values: np.ndarray, weights: np.ndarray | None = None) -> float:
    v = np.asarray(values).ravel()
    valid = np.isfinite(v)
    if weights is None:
        w = np.ones(v.size, dtype="float64")
    else:
        w = np.asarray(weights).ravel().astype("float64", copy=False)
        valid &= np.isfinite(w) & (w > 0)
    v = v[valid].astype("float64", copy=False)
    w = w[valid]
    if v.size == 0 or np.sum(w) <= 0:
        return float("nan")
    order = np.argsort(v)
    v = v[order]
    w = w[order]
    return float(v[np.searchsorted(np.cumsum(w), 0.5 * np.sum(w), side="left")])


def gini(values: np.ndarray, weights: np.ndarray | None = None) -> float:
    """Weighted Gini coefficient for non-negative amounts."""
    v = np.asarray(values).ravel().astype("float64", copy=False)
    valid = np.isfinite(v) & (v >= 0)
    if weights is None:
        w = np.ones(v.size, dtype="float64")
    else:
        w = np.asarray(weights).ravel().astype("float64", copy=False)
        valid &= np.isfinite(w) & (w > 0)
    v = v[valid]
    w = w[valid]
    if v.size < 2:
        return float("nan")
    total = float(np.sum(w * v))
    weight_total = float(np.sum(w))
    if total <= 0 or weight_total <= 0:
        return 0.0
    order = np.argsort(v)
    v = v[order]
    w = w[order]
    cumulative_w_before = np.cumsum(w) - w
    numerator = np.sum(w * (2.0 * cumulative_w_before + w - weight_total) * v)
    return float(numerator / (weight_total * total))


def lorenz_curve(values: np.ndarray, points: int = 101) -> pd.DataFrame:
    v = np.asarray(values).ravel().astype("float64", copy=False)
    v = v[np.isfinite(v) & (v >= 0)]
    if v.size == 0:
        return pd.DataFrame({"population_quantile": [], "cumulative_share": []})
    v.sort()
    cumulative = np.concatenate(([0.0], np.cumsum(v)))
    total = cumulative[-1]
    if total <= 0:
        shares = np.zeros(points, dtype="float64")
    else:
        positions = np.linspace(0, v.size, points)
        lower = np.floor(positions).astype(int)
        fraction = positions - lower
        lower = np.clip(lower, 0, v.size)
        upper = np.clip(lower + 1, 0, v.size)
        cumulative_at = cumulative[lower] + fraction * (cumulative[upper] - cumulative[lower])
        shares = cumulative_at / total
    return pd.DataFrame(
        {
            "population_quantile": np.linspace(0.0, 1.0, points),
            "cumulative_share": shares,
        }
    )


def resource_share(data: np.ndarray) -> tuple[np.ndarray, float]:
    clean = np.where(np.isfinite(data) & (data > 0), data, 0.0).astype("float64")
    total = float(clean.sum())
    if total <= 0:
        return np.full(data.shape, np.nan, dtype="float32"), total
    return (clean / total).astype("float32"), total


def pressure_log2(pop_share: np.ndarray, resource_share_array: np.ndarray, eps: float) -> np.ndarray:
    out = np.full(pop_share.shape, np.nan, dtype="float32")
    valid = np.isfinite(pop_share) & np.isfinite(resource_share_array)
    out[valid] = np.log2(
        (pop_share[valid].astype("float64") + eps)
        / (resource_share_array[valid].astype("float64") + eps)
    ).astype("float32")
    return out


def band_codes(values: np.ndarray, threshold: float) -> np.ndarray:
    out = np.full(values.shape, -1, dtype="int8")
    valid = np.isfinite(values)
    out[valid & (values < -threshold)] = 0
    out[valid & (values >= -threshold) & (values <= threshold)] = 1
    out[valid & (values > threshold)] = 2
    return out


def class_lookup() -> pd.DataFrame:
    labels = {0: "resource_surplus", 1: "balanced", 2: "population_pressure"}
    rows = []
    for q in range(3):
        for quality in range(3):
            for capacity in range(3):
                code = q * 9 + quality * 3 + capacity
                rows.append(
                    {
                        "triple_code": code,
                        "quantity_band": labels[q],
                        "quality_band": labels[quality],
                        "capacity_band": labels[capacity],
                        "triple_label": f"{labels[q]}|{labels[quality]}|{labels[capacity]}",
                    }
                )
    return pd.DataFrame(rows)


def extract_zip_safely(archive: Path, out_dir: Path) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    extracted = []
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            relative = Path(info.filename)
            if relative.is_absolute() or ".." in relative.parts:
                continue
            target = out_dir / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            if not target.exists() or target.stat().st_size != info.file_size:
                with zf.open(info) as source, target.open("wb") as dest:
                    while True:
                        block = source.read(1024 * 1024)
                        if not block:
                            break
                        dest.write(block)
            extracted.append(target)
    return extracted


def build_country_raster(
    boundary_zip: Path,
    root: Path,
    grid: GridSpec,
    logger: logging.Logger,
) -> tuple[np.ndarray, pd.DataFrame]:
    # Keep each Natural Earth resolution in its own extraction directory.  A
    # previous 110m archive may still be present in work/ and must not be
    # accidentally selected when the configured 10m archive is processed.
    extract_dir = root / "work" / f"natural_earth_{boundary_zip.stem}"
    extracted = extract_zip_safely(boundary_zip, extract_dir)
    shp = next((p for p in extracted if p.suffix.lower() == ".shp"), None)
    if shp is None:
        raise FileNotFoundError(f"no .shp found in {boundary_zip}")
    countries = gpd.read_file(shp)
    countries = countries.to_crs(grid.crs)
    fields = list(countries.columns)

    def first_value(row: pd.Series, names: list[str], default: str = "") -> str:
        for name in names:
            if name in fields and pd.notna(row.get(name)):
                value = str(row.get(name)).strip()
                if value and value not in {"-99", "-999"}:
                    return value
        return default

    records = []
    shapes = []
    for _, row in countries.iterrows():
        iso3 = first_value(row, ["ISO_A3", "ADM0_A3", "SU_A3", "SOV_A3"], "UNK")
        name = first_value(row, ["ADMIN", "NAME", "SOVEREIGNT"], iso3)
        continent = first_value(row, ["CONTINENT", "REGION_UN"], "")
        records.append({"iso3": iso3, "country": name, "continent": continent})
        shapes.append((row.geometry, len(records)))

    country_id = rasterize(
        shapes,
        out_shape=grid.shape,
        transform=grid.transform,
        fill=0,
        dtype="int16",
        all_touched=False,
    )
    lookup = pd.DataFrame(records)
    lookup.insert(0, "country_id", np.arange(1, len(lookup) + 1))
    lookup_path = root / "04_results" / "country" / "country_lookup.csv"
    lookup_path.parent.mkdir(parents=True, exist_ok=True)
    lookup.to_csv(lookup_path, index=False, encoding="utf-8-sig")
    write_raster(
        root / "02_data_processed" / "grid_country_id.tif",
        country_id,
        grid,
        nodata=0,
        dtype="int16",
        tags={"description": "Natural Earth Admin-0 rasterized at 5 arc-min"},
    )
    logger.info("rasterized %s country polygons", len(lookup))
    return country_id, lookup


def list_spam_members(archive: Path) -> list[str]:
    with zipfile.ZipFile(archive) as zf:
        return [
            name
            for name in zf.namelist()
            if Path(name).suffix.lower() in {".tif", ".tiff"}
        ]


def parse_spam_member(name: str) -> dict:
    base = Path(name).stem.upper()
    tokens = [token for token in re.split(r"[_\-]+", base) if token]
    variable = ""
    crop = ""
    system = ""
    # SPAM 2020 convention: ..._global_<variable code>_<crop code>_<system code>.tif
    for index, token in enumerate(tokens):
        if token in {"H", "A", "Y", "P"} and index + 2 < len(tokens):
            candidate_crop = tokens[index + 1]
            candidate_system = tokens[index + 2]
            if len(candidate_crop) >= 3 and candidate_system in {"A", "I", "R"}:
                variable, crop, system = token, candidate_crop, candidate_system
                break
    if not variable:
        lower = base.lower()
        if "harvest" in lower or "harv" in lower:
            variable = "H"
        elif "phys" in lower or "physical" in lower:
            variable = "A"
        elif "yield" in lower:
            variable = "Y"
        elif "prod" in lower:
            variable = "P"
    return {"member": name, "variable_code": variable, "crop_code": crop, "system_code": system}


def write_spam_inventory(archive: Path, root: Path) -> pd.DataFrame:
    inventory = pd.DataFrame([parse_spam_member(name) for name in list_spam_members(archive)])
    out = root / "04_results" / "tables" / "spam_member_inventory.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    inventory.to_csv(out, index=False, encoding="utf-8-sig")
    return inventory


def read_spam_member(zf: zipfile.ZipFile, member: str, grid: GridSpec) -> np.ndarray:
    raw = zf.read(member)
    with MemoryFile(raw) as memory:
        with memory.open() as src:
            if (
                src.width == grid.width
                and src.height == grid.height
                and src.crs is not None
                and CRS.from_user_input(src.crs) == CRS.from_user_input(grid.crs)
                and np.allclose(
                    [src.transform.a, src.transform.e, src.transform.c, src.transform.f],
                    [grid.transform.a, grid.transform.e, grid.transform.c, grid.transform.f],
                    atol=1e-9,
                )
            ):
                data = src.read(1).astype("float32", copy=False)
            else:
                data = np.zeros(grid.shape, dtype="float32")
                reproject(
                    source=rasterio.band(src, 1),
                    destination=data,
                    src_transform=src.transform,
                    src_crs=src.crs or grid.crs,
                    src_nodata=src.nodata,
                    dst_transform=grid.transform,
                    dst_crs=grid.crs,
                    dst_nodata=0,
                    resampling=Resampling.nearest,
                )
            if src.nodata is not None:
                data = np.where(data == src.nodata, np.nan, data)
    data[~np.isfinite(data)] = np.nan
    data[data < 0] = np.nan
    return data


def select_spam_members(
    inventory: pd.DataFrame,
    variable: str,
    system: str,
    crop: str | None = None,
) -> list[str]:
    variable_code = SPAM_VARIABLE_CODE.get(variable, variable.upper())
    system_code = SPAM_SYSTEM_CODE.get(system, system.upper())
    selected = inventory[
        (inventory["variable_code"] == variable_code)
        & (inventory["system_code"] == system_code)
    ]
    if crop:
        selected = selected[selected["crop_code"].str.upper() == crop.upper()]
    return selected["member"].tolist()


def aggregate_spam_variable(
    archive: Path,
    inventory: pd.DataFrame,
    grid: GridSpec,
    *,
    variable: str,
    system: str = "total",
    crops: list[str] | None = None,
    logger: logging.Logger | None = None,
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    """Aggregate selected SPAM GeoTIFFs and return total plus crop-specific arrays."""
    crop_arrays: dict[str, np.ndarray] = {}
    all_crops = crops if crops is not None else sorted(inventory["crop_code"].dropna().unique())
    with zipfile.ZipFile(archive) as zf:
        for crop in all_crops:
            members = select_spam_members(inventory, variable, system, crop)
            if not members and system == "total":
                # If a release lacks the all-system layer, add irrigated and rainfed.
                members = select_spam_members(inventory, variable, "irrigated", crop)
                members += select_spam_members(inventory, variable, "rainfed", crop)
            if not members:
                continue
            array = np.zeros(grid.shape, dtype="float32")
            for member in members:
                part = read_spam_member(zf, member, grid)
                array += np.nan_to_num(part, nan=0.0).astype("float32", copy=False)
            array[array <= 0] = np.nan
            crop_arrays[crop] = array
            if logger:
                logger.info("SPAM %s %s: %s", variable, crop, members[0])
    if crop_arrays:
        total = np.zeros(grid.shape, dtype="float32")
        for array in crop_arrays.values():
            total += np.nan_to_num(array, nan=0.0)
        total[total <= 0] = np.nan
    else:
        total = np.full(grid.shape, np.nan, dtype="float32")
    return total, crop_arrays


def find_gaez_files(root: Path, cfg: dict) -> dict[str, Path]:
    analysis = cfg.get("analysis", {})
    gaez_dir = root / "01_data_raw" / "gaez"
    result = {}
    for crop in analysis.get("gaez_crops", []):
        pattern = (
            f"*RES05-YXX.{analysis.get('gaez_time_period', 'HP0120')}."
            f"{analysis.get('gaez_climate_model', 'AGERA5')}."
            f"{analysis.get('gaez_scenario', 'HIST')}.{crop}."
            f"{analysis.get('gaez_water_management', 'HRLM')}.tif"
        )
        matches = list(gaez_dir.glob(pattern))
        if matches:
            result[crop] = matches[0]
            continue
        # A v4 fallback has a different name; match by the crop code suffix.
        v4 = list(gaez_dir.glob(f"*_{crop.lower()}.tif"))
        if v4:
            result[crop] = v4[0]
    return result


def load_un_wpp_population_totals(path: Path, year: int) -> dict[str, float]:
    """Read UN WPP 2024 mid-year population totals keyed by ISO3."""
    from openpyxl import load_workbook

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook["Estimates"]
        header_row = None
        header_values = None
        for row_number, row in enumerate(
            worksheet.iter_rows(min_row=1, max_row=100, values_only=True), start=1
        ):
            labels = {str(value).strip() for value in row if value is not None}
            if {"ISO3 Alpha-code", "Year", "Total Population, as of 1 July (thousands)"}.issubset(labels):
                header_row = row_number
                header_values = list(row)
                break
        if header_row is None or header_values is None:
            raise ValueError(f"could not find WPP header row in {path}")

        columns = {str(value).strip(): index for index, value in enumerate(header_values) if value is not None}
        iso_index = columns["ISO3 Alpha-code"]
        year_index = columns["Year"]
        population_index = columns["Total Population, as of 1 July (thousands)"]
        totals: dict[str, float] = {}
        for row in worksheet.iter_rows(min_row=header_row + 1, values_only=True):
            if len(row) <= max(iso_index, year_index, population_index) or row[year_index] != year:
                continue
            iso3 = str(row[iso_index] or "").strip().upper()
            if not iso3 or iso3 in {"NAN", "NONE"}:
                continue
            try:
                value = float(row[population_index]) * 1000.0
            except (TypeError, ValueError):
                continue
            if np.isfinite(value) and value >= 0:
                totals[iso3] = value
        return totals
    finally:
        workbook.close()


def calibrate_population_to_country_totals(
    population: np.ndarray,
    country_id: np.ndarray,
    lookup: pd.DataFrame,
    targets: dict[str, float],
    aliases: dict[str, str] | None = None,
    groups: dict[str, list[str]] | None = None,
) -> tuple[np.ndarray, pd.DataFrame]:
    """Scale WorldPop within each country to a reference country total."""
    adjusted = population.copy()
    aliases = {str(key).upper(): str(value).upper() for key, value in (aliases or {}).items()}
    groups = {
        str(key).upper(): [str(value).upper() for value in values]
        for key, values in (groups or {}).items()
    }
    group_rows: dict[str, list[tuple[pd.Series, np.ndarray]]] = {}
    for _, country in lookup.iterrows():
        iso3 = str(country["iso3"]).upper()
        reference_key = aliases.get(iso3, iso3)
        group_key = next(
            (key for key, members in groups.items() if iso3 in members or reference_key in members),
            reference_key,
        )
        group_rows.setdefault(group_key, []).append((country, country_id == int(country["country_id"])))

    rows = []
    for group_key, members in group_rows.items():
        target_total = float(targets.get(group_key, np.nan))
        raw_group_total = float(sum(np.nansum(population[mask]) for _, mask in members))
        group_cell_total = int(sum(np.count_nonzero(mask) for _, mask in members))
        factor = float("nan")
        group_status = "unmatched_reference"
        if np.isfinite(target_total) and target_total > 0 and raw_group_total > 0:
            factor = target_total / raw_group_total
            group_status = "calibrated"
            for _, mask in members:
                adjusted[mask] = population[mask] * factor
        elif np.isfinite(target_total) and target_total == 0:
            group_status = "zero_reference"
            for _, mask in members:
                adjusted[mask] = 0.0
            factor = 0.0 if raw_group_total > 0 else 1.0
        elif np.isfinite(target_total) and raw_group_total <= 0:
            # Very small islands can disappear when a 1-km source is summed
            # to 5 arc-min, even though the boundary raster still contains a
            # land cell and WPP reports a positive population.  Allocate the
            # reference total uniformly over those cells and record the
            # fallback explicitly rather than silently dropping the people.
            if target_total > 0 and group_cell_total > 0:
                group_status = "uniform_no_worldpop_signal"
                for _, mask in members:
                    cell_count = int(np.count_nonzero(mask))
                    if cell_count > 0:
                        adjusted[mask] = target_total / group_cell_total
            else:
                group_status = "no_worldpop_signal"

        for country, mask in members:
            cid = int(country["country_id"])
            iso3 = str(country["iso3"]).upper()
            raw_total = float(np.nansum(population[mask]))
            if np.isfinite(target_total) and raw_group_total > 0:
                allocated_reference = target_total * raw_total / raw_group_total
            elif np.isfinite(target_total) and raw_group_total <= 0 and group_cell_total > 0:
                allocated_reference = target_total * np.count_nonzero(mask) / group_cell_total
            else:
                allocated_reference = target_total
            rows.append(
                {
                    "country_id": cid,
                    "iso3": iso3,
                    "country": country["country"],
                    "reference_group": group_key,
                    "worldpop_raw_total": raw_total,
                    "reference_total": allocated_reference,
                    "calibration_factor": factor,
                    "status": group_status,
                }
            )
    return adjusted, pd.DataFrame(rows)


def process_inputs(cfg: dict, root: Path, logger: logging.Logger) -> dict:
    grid = make_grid(cfg)
    raw = root / "01_data_raw"
    processed = root / "02_data_processed"
    results = root / "04_results"
    analysis = cfg.get("analysis", {})
    paths: dict[str, Path] = {}

    # Use only a real raster from the configured observation year. Never
    # substitute the known-bad server-side Aggregate export or a temporal
    # proxy for observed population.
    baseline_year = int(cfg.get("project", {}).get("year", 2020))
    population_candidates = [
        raw / "population" / f"worldpop_{baseline_year}_1km.tif",
        raw / "population" / f"worldpop_{baseline_year}_5arcmin_sum_native_slice.tif",
        raw / "population" / f"worldpop_{baseline_year}_5arcmin_sum.tif",
    ]
    population_path = next((candidate for candidate in population_candidates if candidate.exists()), None)
    if population_path is None:
        raise FileNotFoundError(f"required population raster missing: {population_candidates[0]}")
    population_raw = reproject_to_grid(population_path, grid, resampling=Resampling.sum, dtype="float64")
    # Keep population counts in float64 through summaries.
    # A float32 raster cannot represent integer counts at billion-person
    # country totals without rounding by tens or hundreds of people.
    population_raw = np.asarray(population_raw, dtype="float64")
    population_raw[~np.isfinite(population_raw)] = np.nan
    population_raw[population_raw < 0] = np.nan
    with rasterio.open(population_path) as population_source:
        population_source_tags = population_source.tags()
    if "server-side Aggregate" in population_source_tags.get("aggregation", ""):
        raise ValueError(f"Refusing invalid server Aggregate population export: {population_path}")

    glad_path = raw / "cropland" / "Global_cropland_3km_2019.tif"
    if not glad_path.exists():
        raise FileNotFoundError(f"required cropland raster missing: {glad_path}")
    # In the GLAD overview product, zero is a valid "no cropland" value, so
    # do not let a source nodata tag of zero make the average ignore zeros.
    cropland_percent = reproject_to_grid(
        glad_path,
        grid,
        resampling=Resampling.average,
        dtype="float32",
        respect_source_nodata=False,
    )
    cropland_percent = np.clip(clean_raster_values(cropland_percent, min_value=0), 0, 100)
    cropland_fraction = cropland_percent / 100.0
    cell_area = grid.cell_area_km2()
    cropland_area_km2 = cropland_fraction * cell_area
    cropland_area_ha = cropland_area_km2 * 100.0
    write_raster(
        processed / "grid_cropland_fraction_2019.tif",
        cropland_fraction,
        grid,
        tags={"metric": "cropland_fraction", "source": "GLAD_Potapov", "value_range": "0-1"},
    )
    write_raster(
        processed / "grid_cropland_area_km2_2019.tif",
        cropland_area_km2,
        grid,
        tags={"metric": "cropland_area", "units": "km2", "area_method": "spherical_cell_area"},
    )
    write_raster(
        processed / "grid_cropland_area_ha_2019.tif",
        cropland_area_ha,
        grid,
        tags={"metric": "cropland_area", "units": "ha", "area_method": "spherical_cell_area"},
    )
    paths.update(
        {
            "cropland_fraction": processed / "grid_cropland_fraction_2019.tif",
            "cropland_area_ha": processed / "grid_cropland_area_ha_2019.tif",
        }
    )

    boundary_spec = cfg.get("sources", {}).get("natural_earth_admin0", {})
    boundary_target = Path(
        boundary_spec.get("target", "boundaries/ne_10m_admin_0_countries.zip")
    )
    boundary_path = (
        root / boundary_target
        if boundary_target.parts and boundary_target.parts[0].lower() == "01_data_raw"
        else raw / boundary_target
    )
    if not boundary_path.exists():
        raise FileNotFoundError(f"required country boundary archive missing: {boundary_path}")
    country_id, country_lookup = build_country_raster(boundary_path, root, grid, logger)
    # Use the country layer as the analysis domain.  This removes ocean cells
    # from Lorenz/Gini statistics and prevents zero-valued ocean cells from
    # being classified as falsely "balanced" in the triple mismatch map.
    land_mask = country_id > 0
    if not np.any(land_mask):
        raise ValueError("country boundary raster contains no land cells")
    for array in [population_raw, cropland_percent, cropland_fraction, cropland_area_km2, cropland_area_ha]:
        array[~land_mask] = np.nan

    # Preserve the unadjusted WorldPop surface, then optionally calibrate its
    # within-country spatial distribution to official UN mid-year totals.
    write_raster(
        processed / f"grid_population_{baseline_year}_worldpop_unadjusted.tif",
        population_raw,
        grid,
        nodata=-9999,
        dtype="float64",
        tags={
            "metric": "population_count",
            "aggregation": "sum",
            "source": "WorldPop Global1 spatial pattern",
            "source_path": str(population_path.relative_to(root)).replace("\\", "/"),
            "source_year_surface": population_source_tags.get("source_year", "2020"),
            "provenance_type": population_source_tags.get("provenance_type", "observation"),
            "temporal_proxy_warning": population_source_tags.get("warning", ""),
            "adjustment": "none",
            "domain": "admin0_land",
        },
    )
    population = population_raw.copy()
    # Retain the source counts as published; no UN or global-total rescaling.
    population_adjustment = "none"
    population_raw_total = float(np.nansum(population_raw))
    population_reference_total = float("nan")
    population_global_closure_factor = 1.0
    population_global_closure_residual = 0.0
    calibration_table = pd.DataFrame()
    if population_adjustment == "un_wpp2024_country_totals":
        reference_spec = cfg.get("sources", {}).get("un_wpp_2024", {})
        reference_target = Path(reference_spec.get("target", "population/WPP2024_GEN_F01_DEMOGRAPHIC_INDICATORS_COMPACT.xlsx"))
        reference_path = root / reference_target if reference_target.parts[0].lower() == "01_data_raw" else raw / reference_target
        if reference_path.exists():
            targets = load_un_wpp_population_totals(reference_path, int(cfg.get("project", {}).get("year", 2020)))
            population, calibration_table = calibrate_population_to_country_totals(
                population_raw,
                country_id,
                country_lookup,
                targets,
                aliases=analysis.get("population_iso_aliases", {}),
                groups=analysis.get("population_reference_groups", {}),
            )
            population_reference_total = float(calibration_table["reference_total"].sum(skipna=True))
            calibrated = int((calibration_table["status"] == "calibrated").sum())
            uniform_fallback = int(
                (calibration_table["status"] == "uniform_no_worldpop_signal").sum()
            )
            logger.info(
                "population calibration: %s/%s countries calibrated; uniform fallback=%s; raw=%.0f target=%.0f",
                calibrated,
                len(calibration_table),
                uniform_fallback,
                population_raw_total,
                population_reference_total,
            )
            calibration_table.to_csv(
                processed / "population_country_calibration.csv", index=False, encoding="utf-8-sig"
            )
            paths["population_calibration"] = processed / "population_country_calibration.csv"
        else:
            logger.warning("UN WPP reference missing; retaining unadjusted WorldPop: %s", reference_path)
            population_adjustment = "none_reference_missing"
    if np.isfinite(population_reference_total) and population_reference_total > 0:
        current_population_total = float(np.nansum(population))
        valid_population = land_mask & np.isfinite(population)
        if current_population_total > 0 and np.any(valid_population):
            population_global_closure_factor = population_reference_total / current_population_total
            population_global_closure_residual = population_reference_total - current_population_total
            if not np.isclose(population_global_closure_factor, 1.0, rtol=0.0, atol=1.0e-12):
                population[valid_population] *= population_global_closure_factor
                population_adjustment = "un_wpp2024_country_totals_with_global_closure"
                logger.info(
                    "population global closure: residual=%.0f factor=%.9f; residual assigned proportionally over represented land cells",
                    population_global_closure_residual,
                    population_global_closure_factor,
                )
    write_raster(
        processed / f"grid_population_{baseline_year}.tif",
        population,
        grid,
        nodata=-9999,
        dtype="float64",
        tags={
            "metric": "population_count",
            "aggregation": "sum",
            "source": "WorldPop",
            "source_path": str(population_path.relative_to(root)).replace("\\", "/"),
            "source_year_surface": population_source_tags.get("source_year", str(baseline_year)),
            "provenance_type": population_source_tags.get("provenance_type", "observation"),
            "temporal_proxy_warning": population_source_tags.get("warning", ""),
            "adjustment": population_adjustment,
            "domain": "admin0_land",
        },
    )
    paths["population"] = processed / f"grid_population_{baseline_year}.tif"
    write_raster(
        processed / "grid_cropland_fraction_2019.tif",
        cropland_fraction,
        grid,
        tags={"metric": "cropland_fraction", "source": "GLAD_Potapov", "value_range": "0-1", "domain": "admin0_land"},
    )
    write_raster(
        processed / "grid_cropland_area_km2_2019.tif",
        cropland_area_km2,
        grid,
        tags={"metric": "cropland_area", "units": "km2", "area_method": "spherical_cell_area", "domain": "admin0_land"},
    )
    write_raster(
        processed / "grid_cropland_area_ha_2019.tif",
        cropland_area_ha,
        grid,
        tags={"metric": "cropland_area", "units": "ha", "area_method": "spherical_cell_area", "domain": "admin0_land"},
    )

    spam_area_path = raw / "spam2020" / "spam2020V2r2_global_harvested_area.geotiff.zip"
    spam_prod_path = raw / "spam2020" / "spam2020V2r2_global_production.geotiff.zip"
    spam_area_total = np.full(grid.shape, np.nan, dtype="float32")
    spam_area_by_crop: dict[str, np.ndarray] = {}
    spam_production_total = np.full(grid.shape, np.nan, dtype="float32")
    spam_area_basis = "unavailable"
    if spam_area_path.exists():
        inventory = write_spam_inventory(spam_area_path, root)
        spam_area_total, spam_area_by_crop = aggregate_spam_variable(
            spam_area_path,
            inventory,
            grid,
            variable=analysis.get("spam_area_variable", "harvested_area"),
            system=analysis.get("spam_system", "total"),
            logger=logger,
        )
        spam_area_total[~land_mask] = np.nan
        for crop_grid in spam_area_by_crop.values():
            crop_grid[~land_mask] = np.nan
        spam_area_basis = analysis.get("spam_area_variable", "harvested_area")
        write_raster(
            processed / "grid_spam_area_ha_2020.tif",
            spam_area_total,
            grid,
            tags={
                "metric": "spam_crop_area",
                "units": "ha",
                "variable": spam_area_basis,
                "system": analysis.get("spam_system", "total"),
            },
        )
        paths["spam_area"] = processed / "grid_spam_area_ha_2020.tif"
    else:
        logger.warning("SPAM area archive not found; capacity will use a documented fallback")

    if spam_prod_path.exists():
        inventory_prod = write_spam_inventory(spam_prod_path, root)
        spam_production_total, _ = aggregate_spam_variable(
            spam_prod_path,
            inventory_prod,
            grid,
            variable="production",
            system=analysis.get("spam_system", "total"),
            logger=logger,
        )
        spam_production_total[~land_mask] = np.nan
        write_raster(
            processed / "grid_spam_production_mt_2020.tif",
            spam_production_total,
            grid,
            tags={"metric": "spam_production", "units": "metric_tonnes"},
        )
        paths["spam_production"] = processed / "grid_spam_production_mt_2020.tif"
    else:
        logger.warning("SPAM production archive not found; actual production is omitted")

    gaez_files = find_gaez_files(root, cfg)
    gaez_yields: dict[str, np.ndarray] = {}
    gaez_yield_scale = float(analysis.get("gaez_yield_scale_to_t_ha", 0.001))
    gaez_yield_input_units = str(analysis.get("gaez_yield_input_units", "kg_DM_ha"))
    for crop, gaez_path in gaez_files.items():
        yield_grid = reproject_to_grid(gaez_path, grid, resampling=Resampling.average, dtype="float32")
        yield_grid = clean_raster_values(yield_grid, min_value=0)
        yield_grid = (yield_grid * gaez_yield_scale).astype("float32")
        yield_grid[~land_mask] = np.nan
        gaez_yields[crop] = yield_grid
        out = processed / f"grid_gaez_{crop.lower()}_attainable_yield_t_ha.tif"
        write_raster(
            out,
            yield_grid,
            grid,
            tags={
                "metric": "gaez_attainable_yield",
                "units": "t_ha-1",
                "input_units": gaez_yield_input_units,
                "input_to_output_scale": str(gaez_yield_scale),
                "crop": crop,
                "source_version": "GAEZ_v5_or_v4_fallback",
            },
        )
        paths[f"gaez_{crop}"] = out
    if not gaez_yields:
        logger.warning("no GAEZ crop yield layer available; quality and capacity are omitted")

    # Quality and potential capacity use the overlap between configured GAEZ crops and SPAM crops.
    spam_crop_map = analysis.get("gaez_to_spam_crop", {})
    area_for_yield: dict[str, np.ndarray] = {}
    for gaez_crop in gaez_yields:
        spam_crop = spam_crop_map.get(gaez_crop, gaez_crop)
        if spam_crop in spam_area_by_crop:
            area_for_yield[gaez_crop] = spam_area_by_crop[spam_crop]

    if gaez_yields:
        numerator = np.zeros(grid.shape, dtype="float64")
        denominator = np.zeros(grid.shape, dtype="float64")
        equal_yields = []
        for crop, yield_grid in gaez_yields.items():
            area_grid = area_for_yield.get(crop)
            if area_grid is not None:
                valid = np.isfinite(area_grid) & np.isfinite(yield_grid) & (area_grid > 0)
                numerator[valid] += area_grid[valid].astype("float64") * yield_grid[valid]
                denominator[valid] += area_grid[valid].astype("float64")
            equal_yields.append(np.nan_to_num(yield_grid, nan=0.0))
        weighted_yield = np.full(grid.shape, np.nan, dtype="float32")
        valid_den = denominator > 0
        weighted_yield[valid_den] = (numerator[valid_den] / denominator[valid_den]).astype("float32")
        if not np.any(valid_den):
            weighted_yield = np.nanmean(np.stack(equal_yields), axis=0).astype("float32")
            denominator = np.where(np.isfinite(weighted_yield) & (weighted_yield > 0), cropland_area_ha, 0.0)
            numerator = np.nan_to_num(weighted_yield, nan=0.0) * denominator
            capacity_basis = "GLAD cropland area x unweighted mean GAEZ yield (SPAM overlap unavailable)"
        else:
            capacity_basis = "SPAM crop area x crop-specific GAEZ attainable yield"
        quality_reference = weighted_median(weighted_yield, denominator)
        quality_index = np.full(grid.shape, np.nan, dtype="float32")
        if np.isfinite(quality_reference) and quality_reference > 0:
            quality_index = np.clip(weighted_yield / quality_reference, 0, float(analysis.get("quality_index_cap", 4.0)))
        quality_equiv = cropland_area_ha * quality_index
        potential_capacity = (numerator / 1.0).astype("float32")
        potential_capacity[~np.isfinite(potential_capacity)] = np.nan
        potential_capacity[~land_mask] = np.nan
        write_raster(
            processed / "grid_gaez_weighted_attainable_yield_t_ha.tif",
            weighted_yield,
            grid,
            tags={
                "metric": "weighted_attainable_yield",
                "units": "t_ha-1",
                "input_units": gaez_yield_input_units,
                "input_to_output_scale": str(gaez_yield_scale),
                "basis": capacity_basis,
            },
        )
        write_raster(
            processed / "grid_quality_index.tif",
            quality_index,
            grid,
            tags={"metric": "quality_index", "reference": str(quality_reference)},
        )
        write_raster(
            processed / "grid_quality_equivalent_cropland_ha.tif",
            quality_equiv,
            grid,
            tags={"metric": "quality_equivalent_cropland", "units": "ha", "reference_yield_t_ha": str(quality_reference)},
        )
        write_raster(
            processed / "grid_potential_capacity_mt.tif",
            potential_capacity,
            grid,
            tags={"metric": "potential_production_capacity", "units": "metric_tonnes", "basis": capacity_basis},
        )
        paths.update(
            {
                "quality_index": processed / "grid_quality_index.tif",
                "quality_equiv": processed / "grid_quality_equivalent_cropland_ha.tif",
                "potential_capacity": processed / "grid_potential_capacity_mt.tif",
            }
        )
    else:
        weighted_yield = np.full(grid.shape, np.nan, dtype="float32")
        quality_index = np.full(grid.shape, np.nan, dtype="float32")
        quality_equiv = np.full(grid.shape, np.nan, dtype="float32")
        potential_capacity = np.full(grid.shape, np.nan, dtype="float32")
        quality_reference = float("nan")
        capacity_basis = "unavailable"

    pop_share, pop_total = resource_share(population)
    crop_share, cropland_area_ha_total = resource_share(cropland_area_ha)
    cropland_area_km2_total = float(np.nansum(cropland_area_km2))
    quality_share, quality_total = resource_share(quality_equiv)
    capacity_share, capacity_total = resource_share(potential_capacity)
    eps = float(analysis.get("zero_share_epsilon", 1e-12))
    q_mismatch = pop_share - crop_share
    q_pressure = pressure_log2(pop_share, crop_share, eps)
    quality_mismatch = pop_share - quality_share
    quality_pressure = pressure_log2(pop_share, quality_share, eps)
    capacity_mismatch = pop_share - capacity_share
    capacity_pressure = pressure_log2(pop_share, capacity_share, eps)
    for array in [q_mismatch, q_pressure, quality_mismatch, quality_pressure, capacity_mismatch, capacity_pressure]:
        array[~land_mask] = np.nan
    threshold = float(analysis.get("pressure_log2_threshold", 0.5))
    q_band = band_codes(q_pressure, threshold)
    quality_band = band_codes(quality_pressure, threshold)
    capacity_band = band_codes(capacity_pressure, threshold)
    triple = np.full(grid.shape, -9999, dtype="int16")
    valid_triple = (q_band >= 0) & (quality_band >= 0) & (capacity_band >= 0)
    triple[valid_triple] = (
        q_band[valid_triple].astype("int16") * 9
        + quality_band[valid_triple].astype("int16") * 3
        + capacity_band[valid_triple].astype("int16")
    )

    raster_arrays = [
        population,
        cropland_area_km2,
        cropland_area_ha,
        spam_area_total,
        spam_production_total,
        quality_index,
        quality_equiv,
        potential_capacity,
        q_mismatch,
        q_pressure,
        quality_mismatch,
        quality_pressure,
        capacity_mismatch,
        capacity_pressure,
        triple.astype("float32"),
    ]
    raster_names = [
        "population_count",
        "cropland_area_km2",
        "cropland_area_ha",
        "spam_area_ha",
        "spam_production_mt",
        "quality_index",
        "quality_equivalent_cropland_ha",
        "potential_capacity_mt",
        "quantity_mismatch_share",
        "quantity_pressure_log2",
        "quality_mismatch_share",
        "quality_pressure_log2",
        "capacity_mismatch_share",
        "capacity_pressure_log2",
        "triple_mismatch_code",
    ]
    write_stack(results / "rasters" / f"metrics_{baseline_year}.tif", raster_arrays, raster_names, grid)
    class_lookup().to_csv(results / "tables" / "triple_class_lookup.csv", index=False, encoding="utf-8-sig")

    arrays = {
        "population": population,
        "cropland_area_km2": cropland_area_km2,
        "cropland_area_ha": cropland_area_ha,
        "spam_area_ha": spam_area_total,
        "spam_production_mt": spam_production_total,
        "quality_index": quality_index,
        "quality_equivalent_cropland_ha": quality_equiv,
        "potential_capacity_mt": potential_capacity,
        "quantity_mismatch_share": q_mismatch,
        "quantity_pressure_log2": q_pressure,
        "quality_mismatch_share": quality_mismatch,
        "quality_pressure_log2": quality_pressure,
        "capacity_mismatch_share": capacity_mismatch,
        "capacity_pressure_log2": capacity_pressure,
        "triple_mismatch_code": triple.astype("float32"),
    }
    metadata = {
        "grid": {
            "crs": grid.crs,
            "xmin": grid.xmin,
            "xmax": grid.xmax,
            "ymin": grid.ymin,
            "ymax": grid.ymax,
            "resolution": grid.resolution,
            "width": grid.width,
            "height": grid.height,
        },
        "totals": {
            "population_count": pop_total,
            "cropland_area_km2": cropland_area_km2_total,
            "cropland_area_ha": cropland_area_ha_total,
            "quality_equivalent_cropland_ha": quality_total,
            "potential_capacity_mt": capacity_total,
            "spam_area_ha": float(np.nansum(spam_area_total)),
            "spam_production_mt": float(np.nansum(spam_production_total)),
        },
        "population_raw_total_count": population_raw_total,
        "analysis_population_year": baseline_year,
        "population_source_path": str(population_path.relative_to(root)).replace("\\", "/"),
        "population_source_year": population_source_tags.get("source_year", str(baseline_year)),
        "population_reference_total_count": population_reference_total,
        "population_adjustment": population_adjustment,
        "population_global_closure_factor": population_global_closure_factor,
        "population_global_closure_residual_count": population_global_closure_residual,
        "population_boundary_archive": str(boundary_path.relative_to(root)).replace("\\", "/"),
        "population_boundary_feature_count": int(len(country_lookup)),
        "population_land_cell_count": int(np.count_nonzero(land_mask)),
        "population_calibration_table": "02_data_processed/population_country_calibration.csv"
        if not calibration_table.empty
        else None,
        "quality_reference_yield_t_ha": quality_reference,
        "gaez_yield_input_units": gaez_yield_input_units,
        "gaez_yield_scale_to_t_ha": gaez_yield_scale,
        "capacity_output_units": "metric_tonnes_of_GAEZ_yield_output",
        "capacity_basis": capacity_basis,
        "spam_area_basis": spam_area_basis,
        "gaez_crops_available": sorted(gaez_yields),
        "gaez_spam_overlap": sorted(area_for_yield),
        "pressure_log2_threshold": threshold,
    }
    (results / "tables").mkdir(parents=True, exist_ok=True)
    (processed / "metrics_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False, allow_nan=True), encoding="utf-8"
    )

    _write_global_summary(results, arrays, metadata, grid)
    _write_lorenz(results, arrays)
    _write_country_summary(results, arrays, country_id, country_lookup, grid)
    _write_grid_parquet(results, arrays, country_id, grid)
    logger.info("spatial processing and metrics completed")
    return {"arrays": arrays, "metadata": metadata, "grid": grid}


def _write_global_summary(results: Path, arrays: dict[str, np.ndarray], metadata: dict, grid: GridSpec) -> None:
    rows = []
    for name, values in arrays.items():
        if name.endswith("mismatch_share") or name.endswith("pressure_log2") or name == "triple_mismatch_code":
            continue
        valid = values[np.isfinite(values)]
        rows.append(
            {
                "metric": name,
                "total": float(np.nansum(values)),
                "mean_valid_cell": float(np.nanmean(values)) if valid.size else float("nan"),
                "median_valid_cell": float(np.nanmedian(values)) if valid.size else float("nan"),
                "gini_valid_cells": gini(values),
                "n_valid_cells": int(valid.size),
            }
        )
    rows.append(
        {
            "metric": "quantity_pressure_log2",
            "total": float("nan"),
            "mean_valid_cell": float(np.nanmean(arrays["quantity_pressure_log2"])),
            "median_valid_cell": float(np.nanmedian(arrays["quantity_pressure_log2"])),
            "gini_valid_cells": float("nan"),
            "n_valid_cells": int(np.isfinite(arrays["quantity_pressure_log2"]).sum()),
        }
    )
    pd.DataFrame(rows).to_csv(results / "tables" / "global_summary.csv", index=False, encoding="utf-8-sig")


def _write_lorenz(results: Path, arrays: dict[str, np.ndarray]) -> None:
    frames = []
    for name in [
        "population",
        "cropland_area_ha",
        "quality_equivalent_cropland_ha",
        "potential_capacity_mt",
    ]:
        curve = lorenz_curve(arrays[name])
        curve.insert(0, "dimension", name)
        frames.append(curve)
    pd.concat(frames, ignore_index=True).to_csv(
        results / "tables" / "lorenz_global.csv", index=False, encoding="utf-8-sig"
    )


def _write_country_summary(
    results: Path,
    arrays: dict[str, np.ndarray],
    country_id: np.ndarray,
    lookup: pd.DataFrame,
    grid: GridSpec,
) -> None:
    metrics = [
        "population",
        "cropland_area_km2",
        "cropland_area_ha",
        "spam_area_ha",
        "spam_production_mt",
        "quality_equivalent_cropland_ha",
        "potential_capacity_mt",
    ]
    totals = {name: float(np.nansum(arrays[name])) for name in metrics}
    rows = []
    for _, country in lookup.iterrows():
        cid = int(country["country_id"])
        mask = country_id == cid
        if not np.any(mask):
            continue
        row = {
            "country_id": cid,
            "iso3": country["iso3"],
            "country": country["country"],
            "continent": country.get("continent", ""),
            "n_grid_cells": int(mask.sum()),
        }
        for name in metrics:
            value = arrays[name][mask]
            row[f"{name}_total"] = float(np.nansum(value))
            row[f"{name}_gini"] = gini(value)
            total = totals[name]
            row[f"{name}_global_share"] = float(np.nansum(value) / total) if total > 0 else float("nan")
        pop_share = row["population_global_share"]
        for resource in ["cropland_area_ha", "quality_equivalent_cropland_ha", "potential_capacity_mt"]:
            resource_share_value = row[f"{resource}_global_share"]
            row[f"{resource}_mismatch_share"] = pop_share - resource_share_value
            row[f"{resource}_pressure_log2"] = (
                math.log2((pop_share + 1e-12) / (resource_share_value + 1e-12))
                if np.isfinite(resource_share_value)
                else float("nan")
            )
        rows.append(row)
    pd.DataFrame(rows).to_csv(
        results / "country" / "country_summary.csv", index=False, encoding="utf-8-sig"
    )


def _write_grid_parquet(
    results: Path,
    arrays: dict[str, np.ndarray],
    country_id: np.ndarray,
    grid: GridSpec,
    chunk_size: int = 500_000,
) -> None:
    mask = np.zeros(grid.shape, dtype=bool)
    for name in ["population", "cropland_area_ha", "quality_equivalent_cropland_ha", "potential_capacity_mt"]:
        mask |= np.isfinite(arrays[name]) & (arrays[name] > 0)
    flat_indices = np.flatnonzero(mask.ravel())
    if flat_indices.size == 0:
        return
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except Exception:
        return
    lon_all = np.tile(grid.lon_centers, grid.height)
    lat_all = np.repeat(grid.lat_centers, grid.width)
    columns = [
        "population",
        "cropland_area_km2",
        "cropland_area_ha",
        "spam_area_ha",
        "spam_production_mt",
        "quality_index",
        "quality_equivalent_cropland_ha",
        "potential_capacity_mt",
        "quantity_mismatch_share",
        "quantity_pressure_log2",
        "quality_mismatch_share",
        "quality_pressure_log2",
        "capacity_mismatch_share",
        "capacity_pressure_log2",
        "triple_mismatch_code",
    ]
    out = results / "grid" / "grid_metrics_2020.parquet"
    out.parent.mkdir(parents=True, exist_ok=True)
    writer = None
    try:
        for start in range(0, flat_indices.size, chunk_size):
            indices = flat_indices[start : start + chunk_size]
            data = {
                "row": (indices // grid.width).astype("int32"),
                "col": (indices % grid.width).astype("int32"),
                "lon": lon_all[indices].astype("float32"),
                "lat": lat_all[indices].astype("float32"),
                "country_id": country_id.ravel()[indices].astype("int16"),
            }
            for column in columns:
                data[column] = arrays[column].ravel()[indices].astype("float32")
            table = pa.Table.from_pydict(data)
            if writer is None:
                writer = pq.ParquetWriter(out, table.schema, compression="zstd")
            writer.write_table(table)
    finally:
        if writer is not None:
            writer.close()


def process_future_population(cfg: dict, root: Path, logger: logging.Logger) -> None:
    """Aggregate every downloaded FuturePop scenario/year to the common grid.

    FuturePop archives contain multiple future years.  We select the configured
    year explicitly and keep each SSP in a separate output so that scenario
    values cannot be overwritten or mixed during later analysis.
    """
    future = cfg.get("sources", {}).get("future_population", {})
    grid = make_grid(cfg)
    scenarios = (
        cfg.get("analysis", {}).get("future_scenarios")
        or future.get("download_scenarios")
        or list(future.get("scenarios", {}))
    )
    years = cfg.get("analysis", {}).get("future_years") or [future.get("target_year", 2050)]
    processed_summary = []
    for scenario in scenarios:
        scenario = str(scenario).upper()
        archive = root / "01_data_raw" / "future_population" / f"FuturePop_{scenario}_1km_v0_2.zip"
        if not archive.exists():
            logger.info("future population archive absent for %s; hook remains configured", scenario)
            continue
        for year in years:
            year = int(year)
            with zipfile.ZipFile(archive) as zf:
                members = [
                    info
                    for info in zf.infolist()
                    if Path(info.filename).suffix.lower() in {".tif", ".tiff"}
                    and str(year) in Path(info.filename).name
                ]
                if not members:
                    logger.warning("no %s raster found in %s", year, archive)
                    continue
                # A year may occur in a documentation name or in multiple
                # resolutions.  The largest GeoTIFF is the global 30 arc-sec
                # population surface requested by this project.
                member_info = max(members, key=lambda info: info.file_size)
                member = member_info.filename
                logger.info(
                    "reading FuturePop %s %s (%s; %.1f GB uncompressed)",
                    scenario,
                    year,
                    member,
                    member_info.file_size / 1024**3,
                )
                with MemoryFile(zf.read(member)) as memory:
                    with memory.open() as src:
                        destination = np.zeros(grid.shape, dtype="float64")
                        reproject(
                            source=rasterio.band(src, 1),
                            destination=destination,
                            src_transform=src.transform,
                            src_crs=src.crs or grid.crs,
                            src_nodata=src.nodata,
                            dst_transform=grid.transform,
                            dst_crs=grid.crs,
                            dst_nodata=0,
                            resampling=Resampling.sum,
                        )
            destination[~np.isfinite(destination)] = 0.0
            destination[destination < 0] = 0.0
            output = root / "02_data_processed" / f"grid_population_{scenario}_{year}.tif"
            write_raster(
                output,
                destination,
                grid,
                nodata=0.0,
                dtype="float64",
                tags={
                    "metric": "future_population_count",
                    "scenario": scenario,
                    "year": year,
                    "source": "WorldPop FuturePop v0.2",
                    "aggregation": "sum_to_5_arcmin",
                },
            )
            total = float(np.nansum(destination))
            processed_summary.append({"scenario": scenario, "year": year, "member": member, "total": total})
            logger.info("processed future population: %s %s total=%.0f", scenario, year, total)
    (root / "02_data_processed" / "future_population_processing.json").write_text(
        json.dumps(
            {
                "created_at": datetime.now(timezone.utc).isoformat(),
                "provider": "WorldPop FuturePop v0.2",
                "files": processed_summary,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
