"""Reproducible evidence audit for the Nature Communications revision."""
from pathlib import Path
import json, re, hashlib, zipfile, concurrent.futures, urllib.request, urllib.parse
import numpy as np
import pandas as pd
import rasterio
from rasterio.warp import reproject, Resampling
from lxml import etree

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '07_manuscript/packages/nature_communications/revision_20261015'
OUT.mkdir(parents=True, exist_ok=True)
DATA = OUT / 'source_data'
DATA.mkdir(exist_ok=True)
EPS = 1e-12
KEYS = ['cropland_area_ha', 'quality_equivalent_cropland_ha', 'potential_capacity_mt']

def read(name):
    with rasterio.open(ROOT/'02_data_processed'/name) as ds:
        a = ds.read(1, masked=True).astype('float64').filled(np.nan)
    return a

def aligned(path, profile):
    a = np.full((profile['height'],profile['width']), np.nan, dtype='float64')
    with rasterio.open(path) as ds:
        reproject(rasterio.band(ds,1), a, src_transform=ds.transform, src_crs=ds.crs,
                  src_nodata=ds.nodata, dst_transform=profile['transform'],
                  dst_crs=profile['crs'], dst_nodata=np.nan, resampling=Resampling.sum)
    return a

def pressure(p, r, domain):
    ps=np.where(domain,np.nan_to_num(p,nan=0),0); rs=np.where(domain,np.nan_to_num(r,nan=0),0)
    return np.log2((ps/ps.sum()+EPS)/(rs/rs.sum()+EPS))

def audit():
    cid = read('grid_country_id.tif')
    domain = np.isfinite(cid)&(cid>0)
    pop = read('grid_population_2020.tif')
    resources=[read(x) for x in ['grid_cropland_area_ha_2019.tif','grid_quality_equivalent_cropland_ha.tif','grid_potential_capacity_mt.tif']]
    with rasterio.open(ROOT/'02_data_processed/grid_country_id.tif') as ds: profile=ds.profile
    arrays={ 'country_id':cid.astype('float32'), 'population':pop.astype('float32') }
    for k,r in zip(KEYS,resources): arrays[k]=r.astype('float32')
    pm=[pressure(pop,r,domain) for r in resources]
    bands=[np.where(m<-.5,0,np.where(m>.5,2,1)) for m in pm]
    codes=9*bands[0]+3*bands[1]+bands[2]
    active=domain & ((np.nan_to_num(pop)>0)|np.logical_or.reduce([np.nan_to_num(r)>0 for r in resources]))
    common=domain & (pop>0)&np.logical_and.reduce([r>0 for r in resources])
    def class_rows(mask,label):
        vals,ns=np.unique(codes[mask],return_counts=True)
        return [dict(support=label,code=int(v),cells=int(n),cell_fraction=float(n/mask.sum())) for v,n in zip(vals,ns)]
    pd.DataFrame(class_rows(domain,'country_domain')+class_rows(active,'active_domain')+class_rows(common,'common_positive')).to_csv(DATA/'triple_class_support_audit.csv',index=False)
    country=pd.read_csv(ROOT/'04_results/figdata/fig3_country_share_source.csv')
    country=country[country.period.astype(str)=='2020'].copy()
    for j,k in enumerate(KEYS):
        country[k+'_band']=np.where(country[k+'_pressure_log2']<-.5,0,np.where(country[k+'_pressure_log2']>.5,2,1))
    country['area_capacity_band_changed']=country[KEYS[0]+'_band']!=country[KEYS[2]+'_band']
    country['area_capacity_sign_changed']=(country[KEYS[0]+'_pressure_log2']>0)!=(country[KEYS[2]+'_pressure_log2']>0)
    country.to_csv(DATA/'country_denominator_audit.csv',index=False)
    production=np.zeros(domain.shape,dtype='float64')
    prodfiles=sorted((ROOT/'01_data_raw/spam2020').glob('**/*_P_*_A.tif'))
    for f in prodfiles:
        if any('_P_'+c+'_A' in f.name for c in ['WHEA','MAIZ','RICE','SOYB']):
            x=aligned(f,profile); production+=np.where(np.isfinite(x)&(x>0),x,0)
    production[~domain]=0
    prod_press=pressure(pop,production,domain)
    country['production_total']=np.bincount(np.nan_to_num(cid,nan=0).astype('int32').ravel(),weights=production.ravel())[country.country_id.astype(int).values]
    country['production_share']=country.production_total/production.sum()
    country['production_pressure_log2']=np.log2((country.population_global_share+EPS)/(country.production_share+EPS))
    country.to_csv(DATA/'country_production_audit.csv',index=False)
    native=aligned(ROOT/'01_data_raw/future_population/FuturePop_SSP2_2050_5arcmin_sum.tif',profile)
    allocated=read('grid_population_SSP2_2050.tif')
    native_country=np.bincount(np.nan_to_num(cid,nan=0).astype('int32').ravel(),weights=np.nan_to_num(native,nan=0).ravel())
    allocated_country=np.bincount(np.nan_to_num(cid,nan=0).astype('int32').ravel(),weights=np.nan_to_num(allocated,nan=0).ravel())
    country['native_population_2050']=native_country[country.country_id.astype(int).values]
    country['allocated_population_2050']=allocated_country[country.country_id.astype(int).values]
    country['delta_share_pressure_2050']=np.log2((country.allocated_population_2050/np.nansum(allocated[domain])+EPS)/(country.population_global_share+EPS))
    country.to_csv(DATA/'map_unit_audit.csv',index=False)
    # Natural Earth map units are not independent countries. Sum components
    # before taking shares or ratios, never average their pressure values.
    country['iso3']=country.iso3.replace({'PSX':'PSE','KOS':'XKX'})
    sums=['population_total','production_total','native_population_2050','allocated_population_2050','n_grid_cells']+[k+'_total' for k in KEYS]
    country=country.groupby('iso3',as_index=False).agg({**{c:'sum' for c in sums},'country':'first','continent':'first'})
    country['population_global_share']=country.population_total/country.population_total.sum()
    for key in KEYS+['production']:
        country[key+'_global_share']=country[key+'_total']/country[key+'_total'].sum()
        country[key+'_pressure_log2']=np.log2((country.population_global_share+EPS)/(country[key+'_global_share']+EPS))
    for key in KEYS:
        country[key+'_band']=np.where(country[key+'_pressure_log2']<-.5,0,np.where(country[key+'_pressure_log2']>.5,2,1))
    country['area_capacity_band_changed']=country[KEYS[0]+'_band']!=country[KEYS[2]+'_band']
    country['area_capacity_sign_changed']=(country[KEYS[0]+'_pressure_log2']>0)!=(country[KEYS[2]+'_pressure_log2']>0)
    country['delta_share_pressure_2050']=np.where(country.allocated_population_2050>0,np.log2((country.allocated_population_2050/country.allocated_population_2050.sum()+EPS)/(country.population_global_share+EPS)),np.nan)
    country.to_csv(DATA/'country_audit.csv',index=False)
    arrays.update(production=production.astype('float32'),native=native.astype('float32'),allocated=allocated.astype('float32'))
    np.savez_compressed(DATA/'figure_arrays.npz',**arrays)
    def facts(mask):
        return dict(cells=int(mask.sum()),balanced=float(np.mean(codes[mask]==13)),all_pressure=float(np.mean(codes[mask]==26)),zero_population_zero_resources=int(np.count_nonzero(mask & (np.nan_to_num(pop)==0)&np.logical_and.reduce([np.nan_to_num(r)==0 for r in resources]))))
    ncountry=len(country); populated=country.population_total>0
    summary=dict(domain=facts(domain),active=facts(active),common_positive=facts(common),
                 country_units=ncountry,populated_units=int(populated.sum()),
                 changed_bands=int(country.loc[populated,'area_capacity_band_changed'].sum()),
                 changed_sign=int(country.loc[populated,'area_capacity_sign_changed'].sum()),
                 production_total_country_domain=float(production.sum()),
                 native_global=float(np.nansum(native)),native_country_domain=float(np.nansum(native[domain])),
                 allocated_country_domain=float(np.nansum(allocated[domain])),
                 country_delta_quantiles=country.loc[populated,'delta_share_pressure_2050'].quantile([.1,.5,.9]).to_dict(),
                 future_country_support=int(((country.allocated_population_2050>0)&populated).sum()))
    for key in KEYS:
        summary[key+'_country_resource_gini']=gini(country[key+'_total'].values)
    summary['examples']=country[country.iso3.isin(['SLE','NPL','NIC','IRQ','CHN','USA','IND','BRA'])][['iso3','country','population_total']+[k+'_pressure_log2' for k in KEYS]+['production_total','production_pressure_log2','delta_share_pressure_2050']].to_dict('records')
    (DATA/'evidence_audit.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))

def gini(a):
    a=np.sort(np.asarray(a)[np.isfinite(a)&(np.asarray(a)>=0)])
    return float(2*np.dot(np.arange(1,len(a)+1),a)/(len(a)*a.sum())-(len(a)+1)/len(a))

def references():
    source=(ROOT/'07_manuscript/packages/nature_communications/manuscript.md').read_text(encoding='utf-8')
    dois=list(dict.fromkeys(re.findall(r'https://doi.org/(10\.\S+)',source)))
    extra=['10.1038/sdata.2017.4','10.1038/sdata.2018.72','10.1016/j.gloenvcha.2015.01.004','10.1016/j.gloenvcha.2013.11.014','10.1073/pnas.1405557111','10.1073/pnas.1222474110','10.1038/nature10452','10.1038/nature11420','10.1038/s41586-018-0594-0','10.1038/s41467-020-16819-2','10.1038/s43016-021-00273-5']
    extra=['10.1038/sdata.2017.4','10.1016/j.gloenvcha.2015.01.004','10.1038/nature10452','10.1038/nature11420','10.1038/s41586-018-0594-0','10.1088/1748-9326/11/8/084003','10.1007/s10584-013-0905-2','10.1371/journal.pone.0107042','10.1038/sdata.2018.6','10.1038/s41597-020-0413-9']
    dois=list(dict.fromkeys([x.rstrip('.') for x in dois]+extra))
    def fetch(doi):
        url='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='')
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'CroplandPopulationResearch/1.0 (bibliographic verification)'})
            with urllib.request.urlopen(req,timeout=35) as res: msg=json.load(res)['message']
            return dict(doi=doi,status='resolved_crossref',metadata=msg)
        except Exception as e: return dict(doi=doi,status='lookup_failed',error=str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: records=list(ex.map(fetch,dois))
    (DATA/'reference_metadata.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Reference lookups',len(records),'resolved',sum(x['status']=='resolved_crossref' for x in records))

def template():
    source = ROOT / 'inputs' / 'Manuscript_template.docx'  # Optional user-supplied template
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with zipfile.ZipFile(source) as z:
        inv=[dict(part=n,size=z.getinfo(n).file_size,sha256=hashlib.sha256(z.read(n)).hexdigest()) for n in z.namelist()]
        xml=etree.fromstring(z.read('word/document.xml'))
        sect=xml.find('.//w:sectPr',ns)
        print('SECT',etree.tostring(sect,encoding='unicode'))
        print('PARA PROPS',[(i,etree.tostring(p.find('w:pPr',ns),encoding='unicode') if p.find('w:pPr',ns) is not None else '') for i,p in enumerate(xml.findall('w:body/w:p',ns)[:6])])
    (OUT/'template_package_inventory.json').write_text(json.dumps(inv,indent=2),encoding='utf-8')
    (OUT/'template_sha256.txt').write_text(hashlib.sha256(source.read_bytes()).hexdigest(),encoding='ascii')

if __name__=='__main__':
    import sys
    if 'references' in sys.argv: references()
    elif 'template' in sys.argv: template()
    else: audit()
