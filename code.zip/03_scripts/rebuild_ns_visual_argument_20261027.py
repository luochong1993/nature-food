"""Evidence-preserving reconstruction of five main figures and SI 5/9.

Contracts: resource definition and aggregation; population-weighted joint paths;
accounting (not causal agronomy); stock exposure; demographic counterfactuals.
Python only, 183-mm quantitative/map composites, editable PDF/SVG and 600-dpi TIFF.
Global projected display uses nearest-neighbour sampling; all ROI/summary numbers
use the native 5-arc-minute arrays, never projected display pixels.
"""
from pathlib import Path
import io,json,shutil
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,ListedColormap,Normalize
from matplotlib.patches import PathPatch,Rectangle,Patch
from matplotlib.path import Path as MPath
from matplotlib.lines import Line2D
from pyproj import Transformer,CRS
from PIL import Image
import tifffile
import rebuild_ns_evidence_figures as r

ROOT=r.ROOT;BASE=r.BASE.parent/'aligned_layout_20261020'
OUT=BASE.parent/'paired_insets_20261027';FIG=OUT/'figures';SD=OUT/'source_data'
for p in [OUT,FIG,SD]:p.mkdir(parents=True,exist_ok=True)
v=r.v;C=r.C;ALL=pd.read_csv(BASE/'source_data/national_crop_weight_and_decomposition.csv')
BLUE='#2e55a4';RED='#d43d2f';GOLD='#dda545';PURPLE='#9276ad';GRAY='#bdbdbd'
CLASSCOL=[BLUE,'#aaa79e',RED];CAP={};AUDIT={}
plt.rcParams.update({'legend.frameon':False,'font.size':7,'axes.labelsize':7,
                     'xtick.labelsize':6,'ytick.labelsize':6,'svg.fonttype':'none','pdf.fonttype':42})
ROBIN=CRS.from_proj4('+proj=robin +lon_0=0 +datum=WGS84 +units=m +no_defs')
TO=Transformer.from_crs(4326,ROBIN,always_xy=True);BACK=Transformer.from_crs(ROBIN,4326,always_xy=True)
GEOM=v.G.to_crs(ROBIN)
# Fixed display grid with inverse projection. Nearest native-cell lookup only.
EXT=(-17005833,17005833,-8625155,8625155)
xx=np.linspace(EXT[0],EXT[1],1400);yy=np.linspace(EXT[3],EXT[2],710)
lon,lat=BACK.transform(*np.meshgrid(xx,yy));VALID=np.isfinite(lon)&np.isfinite(lat)&(abs(lon)<=180)&(abs(lat)<=90)
RI=np.clip(((90-np.nan_to_num(lat,nan=0,posinf=0))*12).astype(int),0,2159)
CI=np.clip(((np.nan_to_num(lon,nan=0,posinf=0)+180)*12).astype(int),0,4319)
DIFF=LinearSegmentedColormap.from_list('difference',[BLUE,'#5ca5c8','#fff4db','#dd8f65',RED]);DIFF.set_bad((0,0,0,0))
REGIONS=r.REGIONS
ROIS=[('West Africa',(-18,10,3,16)),('Indo-Gangetic',(72,90,22,32)),('North China',(110,121,32,41)),('US Midwest',(-102,-82,35,49))]

def fig(h):return plt.figure(figsize=(183/25.4,h/25.4))
def ax(f,rect,letter,title):
    a=f.add_axes(rect);a.set_title(title,loc='left',fontsize=7,pad=8)
    a.text(-.05,1.035,letter,transform=a.transAxes,fontsize=8,weight='bold',va='bottom')
    return a
def save(f,name,cap):
    if name.startswith(('Fig1_','Fig3_','Fig4_','Fig5_','Supplementary_Fig1_','Supplementary_Fig2_','Supplementary_Fig3_')) and 'World maps omit Antarctica' not in cap:
        cap+=' World maps omit Antarctica from the displayed extent; numerical summaries retain their stated global support.'
    # Panel explanations live in the external legend, not inside the artwork.
    for panel in f.axes:
        for loc in ['left','center','right']:panel.set_title('',loc=loc)
    for ext in ['pdf','svg','png']:f.savefig(FIG/(name+'.'+ext),dpi=300)
    buf=io.BytesIO();f.savefig(buf,format='png',dpi=600);buf.seek(0)
    tifffile.imwrite(FIG/(name+'.tiff'),np.array(Image.open(buf).convert('RGB')),resolution=(600,600),compression='zlib',metadata=None)
    plt.close(f);CAP[name]=cap;print('EXPORTED',name,flush=True)
def world(a,z=None,mask=None,cmap=DIFF,vmin=-3,vmax=3):
    GEOM.plot(ax=a,color='#ededed',edgecolor='none',zorder=0)
    im=None
    if z is not None:
        m=VALID & mask[RI,CI];zz=np.ma.array(z[RI,CI],mask=~m)
        im=a.imshow(zz,extent=EXT,origin='upper',interpolation='nearest',cmap=cmap,vmin=vmin,vmax=vmax,rasterized=True,zorder=1)
    GEOM.boundary.plot(ax=a,color='#a0a0a0',linewidth=.10,zorder=2)
    # Display crop removes Antarctic white space; numerical support remains global.
    a.set_xlim(EXT[:2]);a.set_ylim(-6500000,8400000);a.set_aspect('equal');a.axis('off')
    return im
def legend(f,handles,where,ncol=3):f.legend(handles=handles,loc='center',bbox_to_anchor=where,ncol=ncol,fontsize=5.6)
def roi_slice(bounds):
    x0,x1,y0,y1=bounds
    return (slice(int((90-y1)*12),int((90-y0)*12)),slice(int((x0+180)*12),int((x1+180)*12)))
def prepare():
    for p in (BASE/'source_data').iterdir():
        if p.is_file() and not (SD/p.name).exists():shutil.copy2(p,SD/p.name)
    for p in (BASE/'figures').iterdir():
        if p.name.startswith('Supplementary_') and not (FIG/p.name).exists():shutil.copy2(p,FIG/p.name)
    if (OUT/'figure_legends.json').exists():CAP.update(json.loads((OUT/'figure_legends.json').read_text(encoding='utf-8')))
    for k,val in json.loads((BASE/'figure_legends.json').read_text(encoding='utf-8')).items():
        if k.startswith('Supplementary_'):CAP.setdefault(k,val)

def fig1():
    f=fig(180)
    for j,(letter,y) in enumerate([('a',.69),('b',.385)]):
        a=ax(f,[.035,y,.625,.285],letter,['Quality-equivalent minus area pressure','Capacity minus area pressure'][j])
        im=world(a,v.M[j+1]-v.M[0],v.COMMON)
        for k,(_,bounds) in enumerate(ROIS):
            x0,x1,y0,y1=bounds;xs=[x0,x1,x1,x0,x0];ys=[y0,y0,y1,y1,y0]
            xp,yp=TO.transform(xs,ys);a.plot(xp,yp,c='#333',lw=.6)
            a.text(xp[1]+2e5,yp[1],str(k+1),fontsize=5.5,weight='bold')
    cb=f.add_axes([.16,.342,.37,.009]);b=f.colorbar(im,cax=cb,orientation='horizontal',extend='both',ticks=[-3,0,3]);b.set_label('Pressure difference (log2); zero is cream',fontsize=6,labelpad=1)
    legend(f,[Patch(fc='#ededed',label='Unsupported land'),Patch(fc='#fff4db',ec='#777',lw=.3,label='Supported, zero difference')],(.35,.282),2)
    out=[]
    for j in range(2):
        for k,(name,bounds) in enumerate(ROIS):
            a=f.add_axes([.68+.16*(k%2),.835-.305*j-.135*(k//2),.145,.115]);sl=roi_slice(bounds);m=v.COMMON[sl]
            vals=np.ma.array((v.M[j+1]-v.M[0])[sl],mask=~m)
            a.set_facecolor('#ededed');a.imshow(vals,extent=[bounds[0],bounds[1],bounds[2],bounds[3]],origin='upper',cmap=DIFF,vmin=-3,vmax=3,aspect='auto',interpolation='nearest')
            subset=v.G.cx[bounds[0]:bounds[1],bounds[2]:bounds[3]];subset.boundary.plot(ax=a,color='#666',lw=.2)
            a.set_xlim(bounds[:2]);a.set_ylim(bounds[2:]);a.set_aspect('auto');a.set_xticks([]);a.set_yticks([])
            a.text(.025,.97,f'{k+1}  {name}',transform=a.transAxes,va='top',fontsize=5.1,bbox=dict(fc='white',ec='none',alpha=.88,pad=1))
            if j==1:
                flip=m&(v.M[0][sl]>.5)&(v.M[2][sl]<-.5)
                n=int(m.sum());out.append(dict(region=name,common_positive_cells=n,area_pressure_to_capacity_surplus_cells=int(flip.sum()),flip_percent=100*flip.sum()/n if n else 0))
    f.text(.825,.36,'Native 5-arc-minute cells; no interpolation',ha='center',fontsize=5.3)
    AUDIT['fig1_insets']={'count':8,'columns':2,'width_mm':.145*183,'height_mm':.115*180,'upper_group':'quality minus area','lower_group':'capacity minus area'}
    pd.DataFrame(out).to_csv(SD/'fig1_native_roi_reversals.csv',index=False);AUDIT['roi_reversals']=out
    a=ax(f,[.17,.08,.31,.155],'c','Continental area → capacity shifts')
    d=r.REG[r.REG.scenario=='SSP2'].set_index('region').loc[REGIONS]
    for i,g in enumerate(REGIONS):
        x=d.loc[g,'area_pressure_2020_log2'];y=d.loc[g,'capacity_pressure_2020_log2']
        a.annotate('',xy=(y,i),xytext=(x,i),arrowprops=dict(arrowstyle='->',lw=1,color=RED if y>x else BLUE,shrinkA=0,shrinkB=0))
    a.scatter(d.area_pressure_2020_log2,range(6),s=15,facecolors='white',edgecolors='#333',label='Area',zorder=3)
    a.scatter(d.capacity_pressure_2020_log2,range(6),s=16,c=GOLD,marker='D',label='Capacity',zorder=4)
    a.axvline(0,c='#999',lw=.5);a.set_yticks(range(6),REGIONS);a.set_ylim(5.6,-.6);a.set_xlabel('Share pressure (log2)');f.legend(*a.get_legend_handles_labels(),loc='center',bbox_to_anchor=(.32,.02),ncol=2,fontsize=5.5)
    a=ax(f,[.69,.08,.27,.155],'d','Imbalance attenuated by aggregation')
    mult=pd.read_csv(SD/'fig1_multiscale_population_resource_imbalance.csv');stats=[]
    for i,key in enumerate(r.SHORT):
        x=mult[(mult.resource==key)&(mult.scale=='National codes (201)')].distance.iloc[0];y=mult[(mult.resource==key)&(mult.scale=='Continental groups (7)')].distance.iloc[0]
        a.plot([x,y],[i,i],c='#888',lw=1);a.scatter(x,i,c=BLUE,s=17);a.scatter(y,i,c='#888',s=17,marker='s')
        a.text(.48,i,f'−{100*(1-y/x):.1f}%',ha='right',va='center',fontsize=6)
        stats.append(dict(resource=key,national_tv=x,continental_tv=y,attenuation_percent=100*(1-y/x)))
    a.set_yticks(range(3),['Area','Quality-eq.','Capacity']);a.set_ylim(2.7,-.6);a.set_xlim(.22,.49);a.set_xlabel('Total-variation distance')
    legend(f,[Line2D([],[],c=BLUE,marker='o',ls='none',label='201 national codes'),Line2D([],[],c='#888',marker='s',ls='none',label='7 continental groups')],(.82,.02),1)
    pd.DataFrame(stats).to_csv(SD/'fig1_aggregation_attenuation.csv',index=False)
    save(f,r.NAMES[0],'Fig. 1 | Resource definitions and aggregation change the geography of imbalance. a,b, Robinson-projected quality-minus-area and capacity-minus-area pressures on 569,780 common-positive native cells. Each world map has its own four equal-sized enlargements in two columns on its right: the upper group corresponds to a and the lower group to b. Region numbers 1–4 identify West Africa, the Indo-Gangetic Plain, North China and the US Midwest in both groups. Grey denotes unsupported land; cream denotes supported values near zero. All maps share ±3 log2 colour limits; source extremes remain in Source Data. Enlargements retain native 5-arc-minute cells without interpolation. A negative difference alone is not a pressure-to-surplus reversal; the source table applies both thresholds explicitly. c, Arrows connect continental area and capacity pressures, aggregating stocks before ratios. d, Paired total-variation distances for the same 201 national codes before and after grouping into seven geographic groups; percentages denote distance attenuation, not variance explained. Six continents appear in c; all seven groups enter d. Maps retain full-country-domain normalisation; c,d use the matched 201-code support. Supplementary Fig. 2 and the display-range audit document resource support and off-scale values. Source Data are provided.')


def ribbon(a,x0,x1,y0,y1,w,color):
    verts=[(x0,y0),(x0+.18,y0),(x1-.18,y1),(x1,y1),(x1,y1+w),(x1-.18,y1+w),(x0+.18,y0+w),(x0,y0+w),(x0,y0)]
    codes=[MPath.MOVETO]+[MPath.CURVE4]*3+[MPath.LINETO]+[MPath.CURVE4]*3+[MPath.CLOSEPOLY]
    a.add_patch(PathPatch(MPath(verts,codes),fc=color,alpha=.52,lw=0))

def fig2():
    f=fig(183);a=ax(f,[.12,.52,.80,.36],'a','Population-weighted national paths across three resource definitions')
    bands=[k+'_band' for k in r.KEYS];paths=C.groupby(bands).agg(population=('population_total','sum'),national_codes=('iso3','size')).reset_index()
    total=paths.population.sum();paths['population_percent']=100*paths.population/total;paths.to_csv(SD/'fig2_population_weighted_joint_paths.csv',index=False)
    positions={};offsets={};gap=.055;scale=.89
    for stage,col in enumerate(bands):
        bottom=0
        for cl in range(3):
            sub=paths[paths[col]==cl];height=scale*sub.population.sum()/total;positions[stage,cl]=bottom;offsets[stage,cl]=bottom
            a.add_patch(Rectangle((stage-.012,bottom),.024,height,fc=CLASSCOL[cl],zorder=5))
            n=int(sub.national_codes.sum());pct=100*sub.population.sum()/total
            a.text(stage+(.025 if stage<2 else -.025),bottom+height/2,f'{["Surplus","Balance","Pressure"][cl]}\n{pct:.1f}% · n={n}',ha='left' if stage<2 else 'right',va='center',fontsize=5.5,zorder=6,bbox=dict(fc='white',ec='none',alpha=.85,pad=.5))
            bottom+=height+gap
        a.text(stage,1.055,['Area','Quality-equivalent','Capacity'][stage],ha='center',fontsize=7)
    loc={}
    for idx,row in paths.iterrows():
        w=scale*row.population/total
        for j,col in enumerate(bands):loc[idx,j]=offsets[j,int(row[col])];offsets[j,int(row[col])]+=w
        for j in range(2):ribbon(a,j+.012,j+1-.012,loc[idx,j],loc[idx,j+1],w,CLASSCOL[int(row[bands[0]])])
    a.set_xlim(-.09,2.09);a.set_ylim(-.02,1.11);a.axis('off')
    a.text(1,-.11,f'151 national codes; baseline population = {total/1e9:.3f} billion; ribbon width represents population',ha='center',fontsize=6)
    AUDIT['alluvial_population']=float(total);assert paths.national_codes.sum()==151 and np.isclose(paths.population_percent.sum(),100)
    a=ax(f,[.17,.13,.31,.25],'b','Regional reclassification exposure')
    d=pd.read_csv(SD/'fig2_regional_reclassification_exposure.csv').set_index('region').loc[REGIONS]
    a.scatter(d.country_percent,np.arange(6)-.1,c=BLUE,s=15,label='National-code count');a.scatter(d.population_percent,np.arange(6)+.1,c=GOLD,marker='D',s=17,label='Baseline population')
    a.set_yticks(range(6),REGIONS);a.set_ylim(5.6,-.6);a.set_xlim(-2,102);a.set_xlabel('Area-to-capacity class change (%)');a.legend(loc='upper left',bbox_to_anchor=(-.02,-.25),fontsize=5.5)
    a=ax(f,[.66,.13,.31,.25],'c','National pressure contrasts and population size')
    x=C[r.KEYS[0]+'_pressure_log2'];y=C[r.KEYS[2]+'_pressure_log2'];change=C[r.KEYS[0]+'_band']!=C[r.KEYS[2]+'_band']
    sizes=3+140*C.population_total/C.population_total.max()
    a.axvspan(-.5,.5,color='#f1f1f1',zorder=-1);a.axhspan(-.5,.5,color='#f1f1f1',zorder=-1)
    a.scatter(x,y,s=sizes,c=np.where(change,RED,'#aaa'),alpha=.6,edgecolors='white',lw=.25)
    limits=[min(x.min(),y.min())-.5,max(x.max(),y.max())+.5];a.plot(limits,limits,'--',c='#777',lw=.6);a.set_xlim(limits);a.set_ylim(limits)
    offsets={'SLE':(9,22),'NPL':(26,2),'NIC':(17,-20),'IRQ':(-19,22),'CHN':(-18,-30),'IND':(32,31),'USA':(-22,3)}
    for iso,off in offsets.items():
        row=C.set_index('iso3').loc[iso];a.annotate(iso,(row[r.KEYS[0]+'_pressure_log2'],row[r.KEYS[2]+'_pressure_log2']),xytext=off,textcoords='offset points',fontsize=5.7,arrowprops=dict(arrowstyle='-',lw=.45,color='#444'),bbox=dict(fc='white',ec='none',alpha=.8,pad=.2))
    a.set_xlabel('Area pressure (log2)');a.set_ylabel('Capacity pressure (log2)')
    a.legend(handles=[Line2D([],[],marker='o',c=RED,ls='none',label='Changed class'),Line2D([],[],marker='o',c='#aaa',ls='none',label='Same class')],loc='upper left',bbox_to_anchor=(-.01,-.25),fontsize=5.4,ncol=2)
    C[['iso3','population_total']+bands+[r.KEYS[0]+'_pressure_log2',r.KEYS[2]+'_pressure_log2']].to_csv(SD/'fig2_national_bubble_inputs.csv',index=False)
    save(f,r.NAMES[1],'Fig. 2 | National reclassification follows population-weighted joint paths. a, Alluvial paths for the same 151 national codes with at least one million people and positive resource totals. Ribbon widths represent baseline population and preserve the complete ordered area-to-quality-to-capacity path; colours denote the initial area class. Node labels show population percentages and national-code counts, which are different weights. States use ±0.5 log2 thresholds. b, Area-to-capacity reclassification percentages weighted by national-code count or baseline population within each continent’s qualifying subset. c, Full-range national area and capacity pressures; bubble area above a small visibility floor is proportional to population. Red/grey denotes changed/unchanged class. ISO labels identify Sierra Leone, Nepal, Nicaragua, Iraq, China, India and the United States. Labels do not imply that every highlighted country reverses sign. The equality line is dashed; shaded bands mark balance. All 151 points remain visible. Supplementary Fig. 9 retains all three count matrices and the complete 27-state joint table. These classifications do not measure food insecurity. Source Data are provided.')

def fig3():
    f=fig(182);a=ax(f,[.14,.57,.34,.33],'a','Harvest coverage and attainable-yield accounting')
    xs=C.harvest_component;ys=C.yield_component
    xlim=(xs.min()-.5,xs.max()+.5);ylim=(ys.min()-.5,ys.max()+.5)
    for x0,x1,y0,y1,col in [(xlim[0],0,ylim[0],0,BLUE),(0,xlim[1],0,ylim[1],RED),(xlim[0],0,0,ylim[1],GOLD),(0,xlim[1],ylim[0],0,PURPLE)]:a.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc=col,alpha=.065,zorder=-3))
    a.scatter(xs,ys,c=np.where(C.delta_capacity_area<0,BLUE,RED),s=12,alpha=.7)
    a.axvline(0,c='#999',lw=.5);a.axhline(0,c='#999',lw=.5);a.plot(xlim,[-xlim[0],-xlim[1]],'--',c='#777',lw=.5);a.set_xlim(xlim);a.set_ylim(ylim)
    labels=[(.02,.97,'Higher coverage\nLower yield'),(.98,.97,'Lower coverage\nLower yield'),(.02,.03,'Higher coverage\nHigher yield'),(.98,.03,'Lower coverage\nHigher yield')]
    for x,y,t in labels:a.text(x,y,t,transform=a.transAxes,ha='left' if x<.5 else 'right',va='top' if y>.5 else 'bottom',fontsize=5.2,bbox=dict(fc='white',ec='none',alpha=.8,pad=.5))
    a.set_xlabel('Harvested/physical-area component (log2)');a.set_ylabel('Attainable-yield component (log2)')
    a=ax(f,[.66,.57,.31,.33],'b','Country-component distributions by continent')
    for j,(key,col,label) in enumerate([('harvest_component',BLUE,'Harvest coverage'),('yield_component',GOLD,'Attainable yield')]):
        for i,g in enumerate(REGIONS):
            q=C.loc[C.continent==g,key].quantile([.25,.5,.75]);a.plot([q.iloc[0],q.iloc[2]],[i+(j-.5)*.22]*2,c=col,lw=1.3);a.scatter(q.iloc[1],i+(j-.5)*.22,c=col,s=16,marker='o' if j==0 else 'D')
    a.axvline(0,c='#999',lw=.5);a.set_yticks(range(6),REGIONS);a.set_ylim(5.5,-.5);a.set_xlabel('Median and interquartile range (log2)');a.legend(handles=[Line2D([],[],marker='o',c=BLUE,label='Harvest coverage'),Line2D([],[],marker='D',c=GOLD,label='Attainable yield')],loc='upper center',bbox_to_anchor=(.5,-.23),fontsize=5.5,ncol=2)
    a=ax(f,[.035,.06,.94,.39],'c','Regional four-crop harvested-area composition')
    world(a)
    h=pd.read_csv(SD/'fig3_four_crop_harvest_composition.csv').set_index('continent').loc[REGIONS]
    colours=[BLUE,GOLD,'#42968b',PURPLE];anchors=[(15,0),(100,35),(20,59),(-113,44),(-62,-23),(134,-23)]
    for region,(lon,lat) in zip(REGIONS,anchors):
        px,py=TO.transform(lon,lat);w=5.5e6;left=px-w/2
        for crop,col in zip(['WHE','MZE','RCD','SOY'],colours):
            value=h.loc[region,crop];a.add_patch(Rectangle((left,py),w*value/100,6e5,fc=col,ec='white',lw=.3,zorder=4));left+=w*value/100
        a.text(px,py+8.7e5,region,ha='center',fontsize=5.5,zorder=5,bbox=dict(fc='white',ec='none',alpha=.8,pad=.2))
    legend(f,[Patch(fc=c,label=l) for c,l in zip(colours,['Wheat','Maize','Rice','Soybean'])],(.5,.035),4)
    sensitivity=ALL.set_index('iso3').loc[['BRA','USA','CHN','IND'],['potential_capacity_mt_pressure_log2','protein_pressure','energy_pressure']].copy()
    sensitivity['protein_minus_tonnes']=sensitivity.protein_pressure-sensitivity.potential_capacity_mt_pressure_log2;sensitivity.to_csv(SD/'fig3_protein_country_examples.csv')
    save(f,r.NAMES[2],'Fig. 3 | National accounting contrasts accompany distinct regional crop compositions. a, Harvested-to-physical-area and attainable-yield pressure components for 151 qualifying national codes. Shading and quadrant labels describe whether each underlying ratio exceeds the corresponding full-domain reference. Higher coverage is not a direct measure of multiple cropping or harvest index. Red/blue points have higher/lower capacity pressure than area pressure; the dashed line marks zero net unregularised change. b, Country medians and interquartile ranges, with equal country weights; these are descriptive distributions, not confidence intervals or decompositions of continental ratios. c, Stacked four-crop harvested-area shares geographically anchored to six continental outlines. Every bar totals 100% within that continent’s restricted-country, four-crop subset; bar length is not total crop area. Wheat, maize, rice and soybean do not represent all crops or nutritional supply. Oceania contains only three qualifying codes. Quadrants do not identify management, climate or biophysical constraints as causes. Protein-weight sensitivity is reported in Supplementary Fig. 6; independently sorted resource concentration in Supplementary Fig. 7 is not paired population–resource imbalance. Source Data are provided.')

def fig4():
    f=fig(185);cls=v.classify(v.M);simple=np.where(cls==1,1,np.where(cls==2,2,np.where(cls>=3,3,0)))
    cmap=ListedColormap(['#e4e3df',RED,BLUE,'#c38c4e']);cmap.set_bad((0,0,0,0))
    a=ax(f,[.035,.65,.94,.32],'a','Concordant pressure and surplus against divergent classes');world(a,simple,v.ACTIVE,cmap,-.5,3.5)
    legend(f,[Patch(fc=c,label=l) for c,l in zip(cmap.colors,['All balanced','All pressure','All surplus','Divergent / other'])],(.5,.61),4)
    a=ax(f,[.13,.34,.80,.19],'b','Population and capacity concentrate in opposite classes')
    data=pd.read_csv(SD/'Supplementary_Table4_weighted_exposure.csv');d=data[data.support=='active_domain'].set_index('display_class')
    gap=8
    for cl,lefty,righty,col in [(1,1,0,RED),(2,0,1,BLUE)]:
        p=float(d.loc[cl,'population_percent']);c=float(d.loc[cl,'capacity_percent'])
        a.barh(lefty,-p,left=-gap,color=col,height=.52);a.barh(righty,c,left=gap,color=col,height=.52)
        a.plot([-gap,gap],[lefty,righty],c=col,lw=1.3)
        a.text(-gap-p-1,lefty,f'{p:.1f}%',ha='right',va='center',fontsize=7,weight='bold');a.text(gap+c+1,righty,f'{c:.1f}%',ha='left',va='center',fontsize=7,weight='bold')
    a.text(-43,1.65,'Population',ha='center',fontsize=7);a.text(43,1.65,'Capacity',ha='center',fontsize=7)
    a.set_xlim(-90,90);a.set_ylim(-.55,1.95);a.set_yticks([]);ticks=[-78,-43,-8,8,43,78];a.set_xticks(ticks,['70','35','0','0','35','70']);a.set_xlabel('Share of represented stock (%)')
    a.text(.5,-.35,'Lines match classes, not flows; residual classes: population 26.4%, capacity 30.0%',transform=a.transAxes,ha='center',fontsize=5.5)
    exp=pd.read_csv(SD/'fig4_regional_class_exposure.csv')
    for j,metric in enumerate(['population','capacity']):
        a=ax(f,[.17+j*.49,.075,.31,.15],chr(99+j),f'Within-continent {metric} shares')
        left=np.zeros(6)
        for cl,col,label in [(1,RED,'All pressure'),(2,BLUE,'All surplus'),(3,'#c38c4e','Divergent / other'),(0,'#e4e3df','All balanced')]:
            vals=[]
            for region in REGIONS:
                sub=exp[exp.region==region];vals.append(sub.loc[sub.display_class>=3,metric+'_percent'].sum() if cl==3 else sub.loc[sub.display_class==cl,metric+'_percent'].iloc[0])
            a.barh(range(6),vals,left=left,color=col,height=.7,edgecolor='white',lw=.2);left+=vals
        assert np.allclose(left,100)
        a.set_yticks(range(6),REGIONS);a.set_ylim(5.5,-.5);a.set_xlim(0,100);a.set_xlabel(f'{metric.capitalize()} within continent (%)')
    save(f,r.NAMES[3],'Fig. 4 | Population and represented capacity concentrate in opposite spatial classes. a, Robinson display of all-axis pressure (red), all-axis surplus (blue), divergent/other classes (ochre) and all-axis balance (pale grey). This visual grouping retains the seven original classes and all numerical values in Source Data. b, Mirrored population and capacity percentages for the pressure and surplus classes. Each side orders these two classes by its own stock share; crossing lines match the same classes, not population or food flows. The unplotted residual classes retain the stated remaining percentages. c,d, The same grouped classes weighted separately by population and capacity within each continent; every bar totals 100% of its stated within-continent stock. Statistics use full-resolution native cells, not projected display pixels. Classification uses ±0.5 log2 thresholds and full-country-domain normalisation. Supplementary Fig. 5 reports weighted exposure across four thresholds and three supports; changing support is not equivalent to changing values. These exposures measure spatial separation, not hunger, trade dependence or food access. Source Data are provided.')

def fig5():
    f=fig(180);m=r.MATCH.set_index('iso3');changes=np.log2(m.SSP2_2050/m.SSP2_2050.sum())-np.log2(m['2020']/m['2020'].sum())
    units=pd.read_csv(SD/'map_unit_audit.csv');mp=units.iso3.replace({'PSX':'PSE','KOS':'XKX'}).map(changes);lut=np.full(int(units.country_id.max())+1,np.nan)
    for cid,val in zip(units.country_id,mp):lut[int(cid)]=val
    surface=lut[v.CID];a=ax(f,[.035,.575,.645,.38],'a','SSP2 population-share pressure shift, 2020 → 2050');im=world(a,surface,v.D&np.isfinite(surface),DIFF,-1,1)
    cb=f.add_axes([.14,.55,.39,.009]);b=f.colorbar(im,cax=cb,orientation='horizontal',extend='both',ticks=[-1,0,1]);b.set_label('2050 minus 2020 pressure (log2); resources fixed',fontsize=6,labelpad=2)
    a=ax(f,[.795,.61,.18,.30],'b','Population-share displacement against capacity')
    d=r.REG[r.REG.scenario=='SSP2'].set_index('region').loc[REGIONS]
    for i,g in enumerate(REGIONS):
        a.annotate('',xy=(d.loc[g,'population_share_2050_percent'],i),xytext=(d.loc[g,'population_share_2020_percent'],i),arrowprops=dict(arrowstyle='->',lw=1.2,color=RED if g in ['Africa','Oceania'] else BLUE))
    a.scatter(d.population_share_2020_percent,range(6),facecolors='white',edgecolors='#333',s=13,label='Population 2020');a.scatter(d.capacity_share_percent,range(6),c=GOLD,marker='^',s=19,label='Fixed capacity')
    a.set_yticks(range(6),REGIONS);a.set_ylim(5.5,-.5);a.set_xlim(-1,65);a.set_xlabel('Matched stock share (%)');a.legend(loc='upper left',bbox_to_anchor=(-.02,-.24),fontsize=5.2)
    a=ax(f,[.10,.14,.30,.27],'c','Absolute endowment and relative imbalance')
    area=m.cropland_area_ha_total.sum();ps=[m['2020'].sum()]+[m[f'SSP{i}_2050'].sum() for i in range(1,6)]
    ha=area/np.array(ps);tv=r.TV[r.TV.resource=='capacity'].set_index('scenario');dist=[tv.tv_2020.iloc[0]]+[tv.loc[f'SSP{i}','tv_2050'] for i in range(1,6)]
    a.bar(range(6),ha,color='#b8b5ae',width=.55,label='Cropland / person');a.set_ylim(0,.20);a.set_ylabel('Cropland (ha per person)');a.set_xticks(range(6),['2020','SSP1','SSP2','SSP3','SSP4','SSP5'],rotation=40,ha='right');a.set_xlabel('Alternative 2050 endpoints')
    twin=a.twinx();twin.scatter(range(6),dist,c=RED,marker='D',s=16,label='Capacity imbalance');twin.set_ylim(0,.4);twin.set_ylabel('Continental TV distance');twin.spines['right'].set_visible(True);twin.tick_params(labelsize=6)
    legend(f,[Patch(fc='#b8b5ae',label='Cropland / person (left)'),Line2D([],[],c=RED,marker='D',ls='none',label='Capacity TV (right)')],(.25,.025),1)
    pd.DataFrame(dict(scenario=['2020']+[f'SSP{i}' for i in range(1,6)],cropland_ha_per_person=ha,continental_capacity_tv=dist)).to_csv(SD/'fig5_absolute_relative_matched_201.csv',index=False)
    rows=[]
    for sc,g in r.REG.groupby('scenario'):
        for _,row in g.iterrows():
            p0=row.population_share_2020_percent/100;p1=row.population_share_2050_percent/100;rr=row.capacity_share_percent/100
            rows.append(dict(scenario=sc,region=row.region,contribution_pp=50*(abs(p1-rr)-abs(p0-rr)),population_ratio=row.population_2050/row.population_2020,ha_per_person_ratio=row.population_2020/row.population_2050))
    out=pd.DataFrame(rows);out.to_csv(SD/'fig5_all_scenario_regional_contributions.csv',index=False)
    a=ax(f,[.66,.14,.315,.27],'d','Regional contributions to continental capacity-imbalance change')
    groups=REGIONS+['Other island territories','Total'];labs=['Africa','Asia','Europe','N. Am.','S. Am.','Oceania','Other','Total']
    for j,(sc,col) in enumerate([('SSP1',BLUE),('SSP2',GOLD),('SSP3',RED)]):
        subset=out[out.scenario==sc].set_index('region');vals=[subset.loc[g,'contribution_pp'] for g in groups[:-1]]+[subset.contribution_pp.sum()]
        expected=100*(tv.loc[sc,'tv_2050']-tv.loc[sc,'tv_2020']);assert np.isclose(vals[-1],expected)
        a.bar(np.arange(8)+(j-1)*.22,vals,width=.21,color=col,label=sc)
    a.axhline(0,c='#777',lw=.5);a.set_xticks(range(8),labs,rotation=35,ha='right',fontsize=5.7);a.set_ylabel('Contribution to ΔTV\n(percentage points)');a.legend(loc='upper right',ncol=3,fontsize=5.7)
    AUDIT['future_absolute_ssp2']=out[out.scenario=='SSP2'].to_dict('records')
    save(f,r.NAMES[4],'Fig. 5 | Regional relief coexists with widening continental imbalance under fixed resources. a, SSP2 change in national population-share pressure on the matched 201-code domain, displayed in Robinson projection. Grey land has no matched allocation. Because resource shares are fixed, this pressure change is common to all three resource definitions. b, Continental population-share arrows connect 2020 to SSP2 2050; triangles denote fixed capacity shares. Arrows do not encode migration. c, Fixed physical cropland per person (bars, left axis) and paired continental population–capacity total-variation distance (diamonds, right axis), using the same 201-code support. Units and scales differ; the future columns are alternative endpoints, not sequential times or a correlation test. d, Signed regional contributions to the capacity-distance increase under SSP1, SSP2 and SSP3. Contributions are one half of each region’s change in absolute population-minus-capacity share gap and sum to the displayed total. These are demographic counterfactuals, not estimated policy effects. All five scenarios and regional absolute endowments are in Source Data; agricultural stocks and baseline within-country allocation weights remain fixed. Source Data are provided.')

def supp9():
    f=fig(158);bands=[C[k+'_band'] for k in r.KEYS]
    for i,(s,t,title) in enumerate([(0,1,'Area → quality'),(1,2,'Quality → capacity'),(0,2,'Area → capacity')]):
        a=ax(f,[.10+i*.30,.63,.22,.23],chr(97+i),title);mat=pd.crosstab(bands[t],bands[s]).reindex(index=[0,1,2],columns=[0,1,2],fill_value=0).values
        a.imshow(mat,cmap='Blues',vmin=0,vmax=70,aspect='auto');a.set_xticks(range(3),['S','B','P']);a.set_yticks(range(3),['S','B','P']);a.set_xlabel('From');a.set_ylabel('To')
        for x in range(3):
            for y in range(3):a.text(x,y,str(mat[y,x]),ha='center',va='center',fontsize=6,color='white' if mat[y,x]>40 else '#222')
    a=ax(f,[.29,.12,.50,.36],'d','Complete ordered three-definition paths')
    mat=np.zeros((9,3),int)
    for _,row in C.iterrows():mat[int(row[r.KEYS[0]+'_band'])*3+int(row[r.KEYS[1]+'_band']),int(row[r.KEYS[2]+'_band'])]+=1
    assert mat.sum()==151;a.imshow(mat,cmap='Blues',vmin=0,vmax=60,aspect='auto');a.set_yticks(range(9),[x+' → '+y for x in ['S','B','P'] for y in ['S','B','P']]);a.set_xticks(range(3),['S','B','P']);a.set_ylabel('Area → quality');a.set_xlabel('Capacity destination')
    for y in range(9):
        for x in range(3):a.text(x,y,str(mat[y,x]),ha='center',va='center',fontsize=6,color='white' if mat[y,x]>35 else '#222')
    save(f,'Supplementary_Fig9_ordered_joint_paths','Supplementary Fig. 9 | National-code counts behind population-weighted paths. a–c, Pairwise count matrices for area-to-quality, quality-to-capacity and area-to-capacity classification, all on the identical 151-code subset. Columns are starting states; rows are destinations. d, Complete 27-state ordered joint table. S, B and P denote surplus, balance and pressure at ±0.5 log2 units. Counts in each matrix and in d sum to 151. Pairwise margins cannot reconstruct the ordered joint paths. Main Fig. 2a uses population weights, whereas all panels here count national codes equally. Source Data are provided.')

def supp5():
    rows=[]
    for t in [.25,.5,.75,1]:
        cl=v.classify(v.M,t)
        for support,mask in [('Country domain',v.D),('Active domain',v.ACTIVE),('Common positive',v.COMMON)]:
            for code in [0,1,2]:
                for metric,w in [('population',v.P),('capacity',v.R[2])]:
                    rows.append(dict(threshold=t,support=support,display_class=code,metric=metric,percent=100*w[mask&(cl==code)].sum(dtype='float64')/w[mask].sum(dtype='float64')))
    weights=pd.DataFrame(rows);weights.to_csv(SD/'weighted_threshold_support_sensitivity.csv',index=False)
    f=fig(137);old=pd.read_csv(SD/'threshold_support_sensitivity.csv')
    for i,name in enumerate(v.CLABEL[:3]):
        a=ax(f,[.10+i*.30,.62,.23,.24],chr(97+i),name)
        for j,s in enumerate(old.support.unique()):
            d=old[(old.group==name)&(old.support==s)];a.plot(d.threshold,d.percent,c=[BLUE,RED,'#888'][j],marker=['o','s','^'][j],ms=3,lw=.8)
        a.set_xlabel('Threshold (log2)');a.set_ylabel('Cells (%)');a.set_ylim(0,75)
    legend(f,[Line2D([],[],c=c,marker=m,label=s) for c,m,s in zip([BLUE,RED,'#888'],['o','s','^'],old.support.unique())],(.5,.49),3)
    for j,metric in enumerate(['population','capacity']):
        a=ax(f,[.14+j*.49,.14,.31,.23],chr(100+j),f'{metric.capitalize()} exposure across thresholds')
        for code,col in [(1,RED),(2,BLUE)]:
            for support,ls in [('Active domain','-'),('Common positive','--')]:
                sub=weights[(weights.metric==metric)&(weights.display_class==code)&(weights.support==support)];a.plot(sub.threshold,sub.percent,c=col,ls=ls,marker='o' if code==1 else '^',ms=2.5,lw=.9)
        a.set_xlabel('Threshold (log2)');a.set_ylabel('Represented stock (%)');a.set_ylim(0,100)
    legend(f,[Line2D([],[],c=RED,label='All pressure'),Line2D([],[],c=BLUE,label='All surplus'),Line2D([],[],c='#777',ls='-',label='Active (= full stock shares)'),Line2D([],[],c='#777',ls='--',label='Common-positive subset')],(.5,.035),2)
    AUDIT['weighted_threshold_ranges']=weights.groupby(['support','metric','display_class']).percent.agg(['min','max']).reset_index().to_dict('records')
    save(f,'Supplementary_Fig5_threshold_sensitivity','Supplementary Fig. 5 | Threshold sensitivity distinguishes cell prevalence from weighted stock exposure. a–c, Equal-cell prevalence of all-axis balance, pressure and surplus across four thresholds and three reporting supports. d,e, Population- and capacity-weighted pressure/surplus exposure across those thresholds. Solid lines show active support; the full country domain gives identical weighted percentages because removed structural-zero cells carry no stock. Dashed lines show the more restrictive common-positive subset and use that subset’s own stock denominators. Red/blue denotes pressure/surplus. No population or resource value is rescaled. These deterministic sensitivity comparisons have no inferential error bars and do not resolve source-product uncertainty. Native, full-resolution values are used for every numerical summary. Source Data are provided.')

def supp6():
    f=fig(110)
    for j,(key,title) in enumerate([('energy_pressure','Relative energy weights'),('protein_pressure','Relative protein weights')]):
        a=ax(f,[.12+j*.48,.23,.33,.56],chr(97+j),title)
        x=C[r.KEYS[2]+'_pressure_log2'];y=C[key]
        a.axvspan(-.5,.5,color='#f0f0f0');a.axhspan(-.5,.5,color='#f0f0f0')
        a.scatter(x,y,s=9,color=BLUE if j==0 else PURPLE,alpha=.6)
        a.plot([-4,15],[-4,15],'--',c='#777',lw=.6);a.set_xlim(-4,15);a.set_ylim(-4,15)
        for iso,off in [('BRA',(12,-16)),('USA',(-25,6)),('CHN',(20,-3)),('IND',(12,17))]:
            row=C.set_index('iso3').loc[iso];a.annotate(iso,(row[r.KEYS[2]+'_pressure_log2'],row[key]),xytext=off,textcoords='offset points',fontsize=5.5,arrowprops=dict(arrowstyle='-',color='#555',lw=.4),bbox=dict(fc='white',ec='none',pad=.2,alpha=.8))
        changes=int(((y<-.5).astype(int)*0+np.where(y<-.5,0,np.where(y>.5,2,1))!=C[r.KEYS[2]+'_band']).sum())
        a.text(.04,.96,f'n = 151; {changes} class changes',transform=a.transAxes,va='top',fontsize=6)
        a.set_xlabel('Tonnes-based capacity pressure (log2)');a.set_ylabel('Composition-weighted pressure (log2)')
    save(f,'Supplementary_Fig6_crop_composition_sensitivity','Supplementary Fig. 6 | Relative crop-composition weights shift pressures without uniformly changing classes. a,b, Energy- and protein-weighted pressures compared with the tonnes baseline on the same 151-code subset and full-country-domain normalisation. Dashed lines denote equality; shaded bands denote ±0.5 log2 balance. Country labels show Brazil, the United States, China and India. Brazil and the United States have lower protein-weighted pressures but remain surplus; China changes from balance to pressure at the primary threshold. Weights are dimensionless ratios of commodity coefficients, not harmonised edible-energy or protein supplies. Dry matter, processing, moisture and food/feed use are not harmonised. Full-range national values remain in Source Data. No inferential tests are implied.')

def supp8():
    f=fig(103);d=pd.read_csv(SD/'historical_fixed_resource_land_loading.csv');past=d[d.kind=='historical'].sort_values('year')
    future=pd.read_csv(SD/'cropland_per_person.csv');future=future[future.period.astype(str)!='2020'].copy()
    assert len(future)==5
    future['ha_per_person_fixed_2019_cropland']=future.cropland_ha_per_person
    future['population_total']=past.fixed_cropland_ha.iloc[-1]/future.cropland_ha_per_person
    for j,(key,title,ylabel) in enumerate([('population_total','Historical counts and future endpoints','Retained population (billion persons)'),('ha_per_person_fixed_2019_cropland','Absolute loading against fixed cropland','Fixed cropland (ha per person)')]):
        a=ax(f,[.13+j*.48,.24,.32,.56],chr(97+j),title);scale=1e9 if j==0 else 1
        a.plot(past.year,past[key]/scale,c='#444',marker='o',ms=3,lw=1)
        for i,(_,row) in enumerate(future.iterrows()):
            col=[BLUE,GOLD,RED,PURPLE,'#668e88'][i]
            a.plot([2020,2050],[past[key].iloc[-1]/scale,row[key]/scale],c=col,ls='--',lw=.7)
            a.scatter(2050,row[key]/scale,c=col,s=15,label=str(row.period).split('_')[0])
        a.set_xticks([2000,2020,2050]);a.set_xlabel('Year and alternative 2050 endpoints');a.set_ylabel(ylabel);a.set_xlim(1997,2055)
    legend(f,[Line2D([],[],c=c,marker='o',ls='--',label=f'SSP{i+1}') for i,c in enumerate([BLUE,GOLD,RED,PURPLE,'#668e88'])],(.52,.06),5)
    save(f,'Supplementary_Fig8_historical_and_future_loading','Supplementary Fig. 8 | Historical counts and absolute loading against fixed cropland. a, Retained WorldPop population in 2000, 2005, 2010, 2015 and 2020 and five allocated SSP population endpoints in 2050. b, The same fixed 2019 physical-cropland stock divided by each retained population. All panels use the full country domain, unlike the matched 201-code support in main Fig. 5c. Dashed segments connect endpoints only; they are not interpolated annual forecasts. Historical and future source generations differ, and agricultural stocks and within-country allocation weights remain fixed. The national SSP2 share-pressure map has moved to main Fig. 5a to avoid duplication. Source Data are provided.')

def supplementary_clean_layouts():
    """Redraw inherited panels from the same arrays, keeping all source tables intact."""
    name='Supplementary_Fig1_population_coverage';f=fig(140)
    a=ax(f,[.035,.43,.94,.54],'a','');a.texts[0].set_visible(False);f.text(.012,.975,'a',fontsize=8,weight='bold',va='bottom');im=world(a,np.log10(np.maximum(v.P,1)),v.D&(v.P>0),plt.get_cmap('YlOrRd'),0,6)
    cb=f.add_axes([.27,.40,.46,.012]);f.colorbar(im,cax=cb,orientation='horizontal',ticks=[0,2,4,6]).set_label('Population count (log10 persons)',fontsize=6)
    a=ax(f,[.15,.09,.75,.21],'b','');h=v.H[v.H.kind=='historical'];x=np.arange(len(h))
    a.bar(x-.17,h.raw_worldpop_total/1e9,.34,color=BLUE,label='Full grid');a.bar(x+.17,h.population_total_country_domain/1e9,.34,color=GOLD,label='Country domain')
    a.set_xticks(x,h.period);a.set_ylabel('Population (billion persons)');a.set_ylim(0,9.1);a.legend(ncol=2,loc='upper left',fontsize=6);save(f,name,CAP[name])
    name='Supplementary_Fig2_full_resource_maps';f=fig(155)
    for i in range(3):
        y=.72-i*.30
        a=ax(f,[.045,y,.425,.23],chr(97+2*i),'');im=world(a,v.M[i],v.ACTIVE,DIFF,-8,8)
        cb=f.add_axes([.13,y-.025,.25,.01]);f.colorbar(im,cax=cb,orientation='horizontal',extend='both',ticks=[-8,0,8]).set_label('Pressure (log2)',fontsize=6)
        a=ax(f,[.54,y,.425,.23],chr(98+2*i),'');limit=[5,5,6][i]
        im=world(a,np.log10(np.maximum(v.R[i],1)),v.D&(v.R[i]>0),plt.get_cmap(['YlGnBu','Purples','YlOrBr'][i]),0,limit)
        cb=f.add_axes([.63,y-.025,.25,.01]);f.colorbar(im,cax=cb,orientation='horizontal',ticks=[0,limit]).set_label(['Area (log10 ha)','Equivalent area (log10 ha)','Capacity index (log10 t)'][i],fontsize=6)
    if 'Rows show physical area' not in CAP[name]:
        CAP[name]=CAP[name].replace('The broad-domain pressure maps','Rows show physical area (a,b), quality-equivalent area (c,d) and capacity (e,f). The broad-domain pressure maps')
    save(f,name,CAP[name])
    name='Supplementary_Fig3_future_provenance';f=fig(140)
    n=v.A['native'];al=v.A['allocated'];mask=v.D&np.isfinite(n)&(al>0);delta=v.press(n,v.R[2],mask)-v.press(al,v.R[2],mask)
    a=ax(f,[.035,.43,.94,.54],'a','');a.texts[0].set_visible(False);f.text(.012,.975,'a',fontsize=8,weight='bold',va='bottom');im=world(a,delta,mask,DIFF,-2,2)
    cb=f.add_axes([.27,.40,.46,.012]);f.colorbar(im,cax=cb,orientation='horizontal',ticks=[-2,0,2]).set_label('Native − allocated share pressure (log2)',fontsize=6)
    a=ax(f,[.27,.09,.48,.21],'b','');ok=(v.C.native_population_2050>0)&(v.C.allocated_population_2050>0)
    a.scatter(v.C.loc[ok,'allocated_population_2050']/1e6,v.C.loc[ok,'native_population_2050']/1e6,s=10,c=BLUE,alpha=.65);a.plot([.01,3000],[.01,3000],'--',c='#777',lw=.6)
    a.set_xscale('log');a.set_yscale('log');a.set_xlim(.01,3000);a.set_ylim(.01,3000);a.set_xlabel('Allocated population (million persons)');a.set_ylabel('Native FuturePop (million persons)');a.text(.03,.92,f'n = {ok.sum()} national codes',transform=a.transAxes,fontsize=6);save(f,name,CAP[name])
    name='Supplementary_Fig4_production_pressure_zoom_and_full_range';f=fig(105)
    z=pd.read_csv(SD/'production_scatter_display_audit.csv');x=z[v.KEYS[2]+'_pressure_log2'];y=z.production_pressure_log2;inside=x.between(-4,8)&y.between(-4,8)
    a=ax(f,[.12,.20,.54,.65],'a','');a.axvspan(-.5,.5,color='#f0f0f0');a.axhspan(-.5,.5,color='#f0f0f0');a.scatter(x[inside],y[inside],c=BLUE,s=15,alpha=.7)
    a.plot([-4,8],[-4,8],'--',c='#666',lw=.7);a.set_xlim(-4,8);a.set_ylim(-4,8);a.set_xlabel('Capacity pressure (log2)');a.set_ylabel('Production pressure (log2)');a.text(.03,.95,f'{inside.sum()}/{len(z)} codes in zoom; {(~inside).sum()} outside',transform=a.transAxes,va='top',fontsize=6)
    for iso in ['SLE','IRQ','USA','CHN','IND']:
        row=z[z.iso3==iso].iloc[0];a.annotate(iso,(row[v.KEYS[2]+'_pressure_log2'],row.production_pressure_log2),xytext=(3,3),textcoords='offset points',fontsize=6)
    a=ax(f,[.78,.47,.19,.34],'b','');a.scatter(x,y,c=BLUE,s=7,alpha=.6);lim=[min(x.min(),y.min())-.3,max(x.max(),y.max())+.3]
    a.plot(lim,lim,'--',c='#777',lw=.5);a.set_xlim(lim);a.set_ylim(lim);a.add_patch(Rectangle((-4,-4),12,12,fill=False,edgecolor=RED,lw=.8));save(f,name,CAP[name])
    name='Supplementary_Fig7_resource_concentration';f=fig(94);a=ax(f,[.10,.19,.39,.63],'a','');values=[]
    for key,col,label in zip(v.KEYS,[BLUE,PURPLE,GOLD],['Cropland area','Quality-equivalent','Capacity']):
        x=np.sort(v.C[key+'_total'].values);y=np.r_[0,np.cumsum(x)/x.sum()];a.plot(np.linspace(0,1,len(y)),y,c=col,lw=1,label=label)
        values.append(2*np.dot(np.arange(1,len(x)+1),x)/(len(x)*x.sum())-(len(x)+1)/len(x))
    a.plot([0,1],[0,1],'--',lw=.6,c='#777');a.set_xlabel('Cumulative fraction of countries');a.set_ylabel('Cumulative fraction of resource');a.legend(loc='upper left',fontsize=5.5)
    a=ax(f,[.69,.19,.27,.63],'b','');a.bar(range(3),values,color=[BLUE,PURPLE,GOLD],width=.65);a.set_xticks(range(3),['Area','Quality-eq.','Capacity'],rotation=35,ha='right');a.set_ylim(0,1);a.set_ylabel('Gini coefficient')
    for i,value in enumerate(values):a.text(i,value+.02,f'{value:.3f}',ha='center',fontsize=6)
    save(f,name,CAP[name])

def run():
    prepare()
    import sys
    jobs={str(i):fn for i,fn in enumerate([fig1,fig2,fig3,fig4,fig5,supp5,supp9,supp6,supp8,supplementary_clean_layouts],1)}
    for key in (sys.argv[1:] or jobs):jobs[key]()
    old=json.loads((OUT/'figure_legends.json').read_text(encoding='utf-8')) if (OUT/'figure_legends.json').exists() else {}
    old.update(CAP);(OUT/'figure_legends.json').write_text(json.dumps(old,indent=2),encoding='utf-8')
    old=json.loads((OUT/'scientific_checks.json').read_text(encoding='utf-8')) if (OUT/'scientific_checks.json').exists() else {}
    old.update(AUDIT);(OUT/'scientific_checks.json').write_text(json.dumps(old,indent=2),encoding='utf-8')
    print('COMPLETE',OUT,flush=True)

if __name__=='__main__':run()
