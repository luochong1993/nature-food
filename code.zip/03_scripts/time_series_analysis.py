"""Build the historical and SSP population-pressure time series.

The demographic surface changes through time, whereas the cropland, quality
and attainable-capacity surfaces are deliberately held at the common
2019-2020 resource baseline.  This makes the temporal extension an explicit
counterfactual: it measures changing demographic pressure on a fixed resource
map, rather than silently mixing maps from different definitions or years.
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
import yaml
from rasterio.warp import Resampling

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from pipeline_core import (  # noqa: E402
    band_codes,
    build_country_raster,
    calibrate_population_to_country_totals,
    class_lookup,
    gini,
    load_un_wpp_population_totals,
    lorenz_curve,
    make_grid,
    read_grid_raster,
    reproject_to_grid,
    resource_share,
    setup_logger,
    write_raster,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=None, help="Project root; defaults to config.yaml parent")
    parser.add_argument("--config", default=None, help="YAML configuration path")
    parser.add_argument(
        "--include-future",
        action="store_true",
        help="Include any processed FuturePop SSP rasters that are available",
    )
    return parser.parse_args()


def read_config(config_path: Path) -> dict:
    with config_path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    return root / path


def read_or_build_country_grid(cfg: dict, root: Path, logger: logging.Logger):
    grid = make_grid(cfg)
    country_raster_path = root / "02_data_processed" / "grid_country_id.tif"
    lookup_path = root / "04_results" / "country" / "country_lookup.csv"
    if country_raster_path.exists() and lookup_path.exists():
        with rasterio.open(country_raster_path) as src:
            country_id = src.read(1).astype("int16", copy=False)
        lookup = pd.read_csv(lookup_path)
        return grid, country_id, lookup
    boundary_spec = cfg.get("sources", {}).get("natural_earth_admin0", {})
    boundary_path = resolve_path(
        root / "01_data_raw", boundary_spec.get("target", "boundaries/ne_10m_admin_0_map_units.zip")
    )
    return (grid, *build_country_raster(boundary_path, root, grid, logger))


def load_population_surface(path: Path, grid) -> np.ndarray:
    """Read a Global1 1-km or legacy 5-arc-min raster and sum to the grid."""
    if not path.exists():
        raise FileNotFoundError(path)
    with rasterio.open(path) as src:
        source_resolution = max(abs(float(src.transform.a)), abs(float(src.transform.e)))
    if source_resolution > grid.resolution * 1.01:
        raise ValueError(f"population source is coarser than target grid: {path} ({source_resolution})")
    data = reproject_to_grid(path, grid, resampling=Resampling.sum, dtype="float64")
    data = np.asarray(data, dtype="float64")
    data[~np.isfinite(data)] = 0.0
    data[data < 0] = 0.0
    return data


def historical_population(
    year: int,
    cfg: dict,
    root: Path,
    grid,
    country_id: np.ndarray,
    lookup: pd.DataFrame,
    logger: logging.Logger,
) -> tuple[np.ndarray, dict, pd.DataFrame]:
    raw_dir = root / "01_data_raw" / "population"
    candidates = [
        raw_dir / f"worldpop_{year}_1km.tif",
        raw_dir / f"worldpop_{year}_5arcmin_sum_native_slice.tif",
        raw_dir / f"worldpop_{year}_5arcmin_sum.tif",
    ]
    source = next((path for path in candidates if path.exists()), None)
    if source is None:
        raise FileNotFoundError(f"no WorldPop Global1 input for {year}: {candidates}")
    raw = load_population_surface(source, grid)
    # Preserve the complete harmonised-grid sum before applying the country
    # polygon mask.  The mask defines the country-comparison domain; it must
    # not silently redefine the published raster total or trigger rescaling.
    full_grid_total = float(np.nansum(raw, dtype=np.float64))
    with rasterio.open(source) as source_dataset:
        source_tags = source_dataset.tags()
    land_mask = country_id > 0
    country_domain_total = float(np.nansum(raw[land_mask], dtype=np.float64))
    excluded_by_country_mask = max(0.0, full_grid_total - country_domain_total)
    raw[~land_mask] = 0.0

    analysis = cfg.get("analysis", {})
    ref_path = root / "01_data_raw" / "population" / "WPP2024_GEN_F01_DEMOGRAPHIC_INDICATORS_COMPACT.xlsx"
    population = raw.copy()
    calibration = pd.DataFrame()
    adjustment = "none"
    reference_total = float("nan")
    if ref_path.exists() and analysis.get("population_adjustment") == "un_wpp2024_country_totals":
        targets = load_un_wpp_population_totals(ref_path, year)
        population, calibration = calibrate_population_to_country_totals(
            raw,
            country_id,
            lookup,
            targets,
            aliases=analysis.get("population_iso_aliases", {}),
            groups=analysis.get("population_reference_groups", {}),
        )
        reference_total = float(calibration["reference_total"].sum(skipna=True))
        adjustment = "un_wpp2024_country_totals_within_country"
        calibration.insert(0, "period", str(year))
        calibration.to_csv(
            root / "04_results" / "tables" / f"population_calibration_{year}.csv",
            index=False,
            encoding="utf-8-sig",
        )
    population[~land_mask] = 0.0
    current_total = float(population.sum())
    closure_factor = reference_total / current_total if np.isfinite(reference_total) and current_total > 0 else 1.0
    if np.isfinite(reference_total) and current_total > 0 and not np.isclose(closure_factor, 1.0, atol=1e-12):
        population *= closure_factor
    metadata = {
        "period": str(year),
        "kind": "historical",
        "source": str(source.relative_to(root)).replace("\\", "/"),
        "source_year_surface": int(source_tags.get("source_year", year)),
        "provenance_type": source_tags.get("provenance_type", "observation"),
        "temporal_proxy_warning": source_tags.get("warning", ""),
        # Legacy field retained for downstream consumers, now explicitly the
        # full harmonised grid before the Natural Earth analysis-domain mask.
        "raw_worldpop_total": full_grid_total,
        "population_total_country_domain": country_domain_total,
        "population_excluded_country_mask": excluded_by_country_mask,
        "country_domain_coverage_fraction": (
            country_domain_total / full_grid_total if full_grid_total > 0 else float("nan")
        ),
        "reference_total": reference_total,
        "population_total": float(population.sum()),
        "adjustment": adjustment,
        "global_closure_factor": closure_factor,
    }
    logger.info(
        "population %s: source=%s full_grid=%.0f country_domain=%.0f adjustment=%s",
        year,
        source.name,
        full_grid_total,
        country_domain_total,
        adjustment,
    )
    return population, metadata, calibration


def future_population(
    scenario: str,
    year: int,
    cfg: dict,
    root: Path,
    grid,
    country_id: np.ndarray,
) -> tuple[np.ndarray, dict] | None:
    path = root / "02_data_processed" / f"grid_population_{scenario}_{year}.tif"
    if not path.exists():
        return None
    with rasterio.open(path) as src:
        population = src.read(1).astype("float64", copy=False)
        if src.nodata is not None:
            population[population == src.nodata] = np.nan
    population[~np.isfinite(population)] = 0.0
    population[population < 0] = 0.0
    population[country_id <= 0] = 0.0
    fallback_metadata_path = root / "02_data_processed" / "future_population_fallback_processing.json"
    fallback_match = False
    if fallback_metadata_path.exists():
        try:
            fallback_metadata = json.loads(fallback_metadata_path.read_text(encoding="utf-8"))
            fallback_match = any(
                str(item.get("scenario", "")).upper() == str(scenario).upper()
                and int(item.get("year", -1)) == int(year)
                and item.get("status") == "processed_fallback"
                for item in fallback_metadata.get("outputs", [])
            )
        except (OSError, ValueError, TypeError):
            fallback_match = False
    adjustment = (
        "modelled_spatial_allocation_iiasa_country_totals"
        if fallback_match
        else "none_futurepop_ssp_v0_2"
    )
    source_type = "IIASA country totals, modelled spatial allocation" if fallback_match else "WorldPop FuturePop v0.2"
    return population, {
        "period": f"{scenario}_{year}",
        "kind": "future",
        "scenario": scenario,
        "year": year,
        "source": str(path.relative_to(root)).replace("\\", "/"),
        "raw_population_total": float(population.sum()),
        "reference_total": float("nan"),
        "population_total": float(population.sum()),
        "adjustment": adjustment,
        "source_type": source_type,
        "global_closure_factor": 1.0,
        "resource_baseline_period": cfg.get("analysis", {}).get("resource_baseline_period", "2019-2020"),
    }


def country_rows(
    population: np.ndarray,
    resources: dict[str, np.ndarray],
    country_id: np.ndarray,
    lookup: pd.DataFrame,
    period: str,
) -> list[dict]:
    totals = {name: float(np.nansum(values)) for name, values in resources.items()}
    totals["population"] = float(np.nansum(population))
    rows: list[dict] = []
    for _, country in lookup.iterrows():
        cid = int(country["country_id"])
        mask = country_id == cid
        if not np.any(mask):
            continue
        row = {
            "period": period,
            "country_id": cid,
            "iso3": str(country["iso3"]),
            "country": str(country["country"]),
            "continent": str(country.get("continent", "")),
            "n_grid_cells": int(mask.sum()),
        }
        row["population_total"] = float(np.nansum(population[mask]))
        row["population_global_share"] = row["population_total"] / totals["population"] if totals["population"] > 0 else np.nan
        for name, values in resources.items():
            value = float(np.nansum(values[mask]))
            row[f"{name}_total"] = value
            row[f"{name}_global_share"] = value / totals[name] if totals[name] > 0 else np.nan
            pop_share = row["population_global_share"]
            resource_share_value = row[f"{name}_global_share"]
            row[f"{name}_mismatch_share"] = pop_share - resource_share_value if np.isfinite(resource_share_value) else np.nan
            row[f"{name}_pressure_log2"] = (
                math.log2((pop_share + 1e-12) / (resource_share_value + 1e-12))
                if np.isfinite(resource_share_value)
                else np.nan
            )
        rows.append(row)
    return rows


def write_period_outputs(
    period: str,
    population: np.ndarray,
    resources: dict[str, np.ndarray],
    country_id: np.ndarray,
    lookup: pd.DataFrame,
    grid,
    cfg: dict,
    root: Path,
) -> tuple[dict, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    eps = float(cfg.get("analysis", {}).get("zero_share_epsilon", 1e-12))
    threshold = float(cfg.get("analysis", {}).get("pressure_log2_threshold", 0.5))
    pop_share, pop_total = resource_share(population)
    metric_arrays: dict[str, np.ndarray] = {"population": population}
    global_rows: list[dict] = []
    lorenz_frames: list[pd.DataFrame] = []
    triple_bands: dict[str, np.ndarray] = {}
    for name, resource in resources.items():
        share, total = resource_share(resource)
        mismatch = pop_share - share
        pressure = np.full(population.shape, np.nan, dtype="float32")
        valid = np.isfinite(pop_share) & np.isfinite(share)
        pressure[valid] = np.log2((pop_share[valid] + eps) / (share[valid] + eps)).astype("float32")
        metric_arrays[name] = resource
        metric_arrays[f"{name}_mismatch_share"] = mismatch.astype("float32")
        metric_arrays[f"{name}_pressure_log2"] = pressure
        triple_bands[name] = band_codes(pressure, threshold)
        finite = pressure[np.isfinite(pressure)]
        global_rows.extend(
            [
                {
                    "period": period,
                    "metric": "population" if name == "cropland_area_ha" else name,
                    "resource": name,
                    "population_total": pop_total,
                    "resource_total": total,
                    "pressure_mean_log2": float(np.nanmean(finite)) if finite.size else np.nan,
                    "pressure_median_log2": float(np.nanmedian(finite)) if finite.size else np.nan,
                    "pressure_p90_log2": float(np.nanpercentile(finite, 90)) if finite.size else np.nan,
                    "pressure_positive_share_cells": float(np.mean(finite > 0)) if finite.size else np.nan,
                    "pressure_gt_threshold_share_cells": float(np.mean(finite > threshold)) if finite.size else np.nan,
                    "resource_gini_cells": gini(resource),
                    "population_gini_cells": gini(population),
                }
            ]
        )
        for curve_name, values in [("population", population), (name, resource)]:
            curve = lorenz_curve(values)
            curve.insert(0, "metric", curve_name)
            curve.insert(0, "period", period)
            lorenz_frames.append(curve)

    triple = np.full(population.shape, -9999, dtype="int16")
    if len(triple_bands) == 3:
        names = ["cropland_area_ha", "quality_equivalent_cropland_ha", "potential_capacity_mt"]
        valid = np.ones(population.shape, dtype=bool)
        for name in names:
            valid &= triple_bands[name] >= 0
        triple[valid] = (
            triple_bands[names[0]][valid].astype("int16") * 9
            + triple_bands[names[1]][valid].astype("int16") * 3
            + triple_bands[names[2]][valid].astype("int16")
        )
    metric_arrays["triple_mismatch_code"] = triple.astype("float32")

    raster_dir = root / "04_results" / "rasters" / "time_series"
    safe_period = period.replace("/", "_")
    write_raster(
        raster_dir / f"{safe_period}_population.tif",
        population,
        grid,
        nodata=-9999,
        dtype="float32",
        tags={"metric": "population_count", "period": period},
    )
    for name in ["cropland_area_ha", "quality_equivalent_cropland_ha", "potential_capacity_mt"]:
        write_raster(
            raster_dir / f"{safe_period}_{name}.tif",
            metric_arrays[f"{name}_pressure_log2"],
            grid,
            nodata=-9999,
            dtype="float32",
            tags={"metric": f"{name}_pressure_log2", "period": period, "units": "log2 share ratio"},
        )
    write_raster(
        raster_dir / f"{safe_period}_triple_mismatch_code.tif",
        triple,
        grid,
        nodata=-9999,
        dtype="int16",
        tags={"metric": "triple_mismatch_code", "period": period, "threshold_log2": threshold},
    )
    countries = pd.DataFrame(country_rows(population, resources, country_id, lookup, period))
    triple_counts = pd.Series(triple[triple >= 0]).value_counts().sort_index()
    triple_rows = pd.DataFrame(
        {
            "period": period,
            "triple_code": triple_counts.index.astype(int),
            "n_cells": triple_counts.values.astype(int),
            "cell_share": triple_counts.values / triple_counts.values.sum() if triple_counts.sum() else np.nan,
        }
    )
    return {
        "period": period,
        "population_total": pop_total,
        "resource_totals": {name: float(np.nansum(value)) for name, value in resources.items()},
        "triple_valid_cells": int(np.count_nonzero(triple >= 0)),
    }, countries, pd.DataFrame(global_rows), pd.concat(lorenz_frames, ignore_index=True), triple_rows


def main() -> int:
    args = parse_args()
    root = Path(args.root) if args.root else Path(__file__).resolve().parents[1]
    config_path = Path(args.config) if args.config else root / "config.yaml"
    cfg = read_config(config_path)
    log_path = root / "06_logs" / f"time_series_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    logger = setup_logger(log_path)
    grid, country_id, lookup = read_or_build_country_grid(cfg, root, logger)
    land_mask = country_id > 0

    processed = root / "02_data_processed"
    resources = {
        "cropland_area_ha": read_grid_raster(processed / "grid_cropland_area_ha_2019.tif").astype("float64"),
        "quality_equivalent_cropland_ha": read_grid_raster(processed / "grid_quality_equivalent_cropland_ha.tif").astype("float64"),
        "potential_capacity_mt": read_grid_raster(processed / "grid_potential_capacity_mt.tif").astype("float64"),
    }
    for array in resources.values():
        array[~land_mask] = np.nan
        array[array < 0] = np.nan

    all_metadata: list[dict] = []
    country_frames: list[pd.DataFrame] = []
    global_frames: list[pd.DataFrame] = []
    lorenz_frames: list[pd.DataFrame] = []
    triple_frames: list[pd.DataFrame] = []

    years = [int(year) for year in cfg.get("analysis", {}).get("population_historical_years", [2000, 2010, 2020])]
    for year in years:
        try:
            population, metadata, _ = historical_population(year, cfg, root, grid, country_id, lookup, logger)
            metadata["resource_baseline_period"] = cfg.get("analysis", {}).get("resource_baseline_period", "2019-2020")
            summary, country, global_summary, lorenz, triple = write_period_outputs(
                str(year), population, resources, country_id, lookup, grid, cfg, root
            )
            metadata.update(summary)
            all_metadata.append(metadata)
            country_frames.append(country)
            global_frames.append(global_summary)
            lorenz_frames.append(lorenz)
            triple_frames.append(triple)
        except Exception as exc:  # noqa: BLE001 - leave a clear row for missing downloads
            logger.error("historical period %s failed: %s", year, exc)

    if args.include_future:
        future_scenarios = cfg.get("analysis", {}).get("future_scenarios", [])
        future_years = cfg.get("analysis", {}).get("future_years", [2050])
        for scenario in future_scenarios:
            for year in future_years:
                item = future_population(str(scenario).upper(), int(year), cfg, root, grid, country_id)
                if item is None:
                    logger.warning("future raster not available: %s %s", scenario, year)
                    continue
                population, metadata = item
                period = f"{str(scenario).upper()}_{int(year)}"
                summary, country, global_summary, lorenz, triple = write_period_outputs(
                    period, population, resources, country_id, lookup, grid, cfg, root
                )
                metadata.update(summary)
                all_metadata.append(metadata)
                country_frames.append(country)
                global_frames.append(global_summary)
                lorenz_frames.append(lorenz)
                triple_frames.append(triple)

    tables = root / "04_results" / "tables"
    tables.mkdir(parents=True, exist_ok=True)
    if country_frames:
        pd.concat(country_frames, ignore_index=True).to_csv(tables / "population_time_series_country.csv", index=False, encoding="utf-8-sig")
    if global_frames:
        pd.concat(global_frames, ignore_index=True).to_csv(tables / "population_time_series_global.csv", index=False, encoding="utf-8-sig")
    if lorenz_frames:
        pd.concat(lorenz_frames, ignore_index=True).to_csv(tables / "population_time_series_lorenz.csv", index=False, encoding="utf-8-sig")
    if triple_frames:
        triple_table = pd.concat(triple_frames, ignore_index=True)
        lookup_table = class_lookup()
        triple_table = triple_table.merge(lookup_table, on="triple_code", how="left")
        triple_table.to_csv(tables / "population_time_series_triple.csv", index=False, encoding="utf-8-sig")
    metadata_path = tables / "population_time_series_metadata.json"
    metadata_path.write_text(
        json.dumps(
            {
                "created_at": datetime.now(timezone.utc).isoformat(),
                "resource_baseline_period": cfg.get("analysis", {}).get("resource_baseline_period", "2019-2020"),
                "grid": {
                    "crs": grid.crs,
                    "resolution": grid.resolution,
                    "width": grid.width,
                    "height": grid.height,
                },
                "periods": all_metadata,
            },
            indent=2,
            ensure_ascii=False,
            allow_nan=True,
        ),
        encoding="utf-8",
    )
    logger.info("time-series outputs written for %s periods", len(all_metadata))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
