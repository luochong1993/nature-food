"""Full-resolution exposure, crop-weight and demographic sensitivity audit.

No source counts are calibrated. Nutrient coefficients define dimensionless
composition-weight scenarios, NOT edible caloric/protein capacity conversions.
"""
from pathlib import Path
import json, zipfile, shutil
import numpy as np
import pandas as pd
import rasterio
from scipy.stats import spearmanr
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.cm import ScalarMappable
import revise_nc_figures as v
from pipeline_core import GridSpec, read_spam_member, parse_spam_member

ROOT=v.ROOT
OUT=ROOT/'07_manuscript/packages/nature_sustainability/revision_20261020_exposure'
SD=OUT/'source_data'; FIG=OUT/'figures'
for p in (SD,FIG): p.mkdir(parents=True,exist_ok=True)
v.FIG=FIG
CAP={}; STATS={}

def read(name):
    with rasterio.open(ROOT/'02_data_processed'/name) as ds:
        return ds.read(1,masked=True).astype('float64').filled(np.nan)

def export(f,name,caption):
    v.save(f,name); CAP[name]=caption

def band(x): return np.where(np.asarray(x)<-.5,0,np.where(np.asarray(x)>.5,2,1))

def exposure():
    cls=v.classify(v.M)
    p=np.nan_to_num(read('grid_population_2020.tif'),nan=0)
    capacity=np.nan_to_num(read('grid_potential_capacity_mt.tif'),nan=0)
    crop=np.nan_to_num(read('grid_cropland_area_ha_2019.tif'),nan=0)
    grid=GridSpec(-180,180,-90,90,1/12,4320,2160)
    area=grid.cell_area_km2()
    full_pop=float(p[v.D].sum()); whole_pop=float(v.H.loc[v.H.period.astype(str)=='2020','raw_worldpop_total'].iloc[0])
    rows=[]
    for label,mask in [('country_domain',v.D),('active_domain',v.ACTIVE),('common_positive',v.COMMON)]:
        totals=[mask.sum(),area[mask].sum(),p[mask].sum(),capacity[mask].sum(),crop[mask].sum()]
        for k,name in enumerate(v.CLABEL):
            m=mask&(cls==k)
            vals=[m.sum(),area[m].sum(),p[m].sum(),capacity[m].sum(),crop[m].sum()]
            row=dict(support=label,display_class=k,label=name,cells=int(vals[0]),spherical_cell_area_km2=vals[1],population=vals[2],capacity_t=vals[3],cropland_ha=vals[4])
            for key,x,total in zip(['cells','area','population','capacity','cropland'],vals,totals): row[key+'_percent']=100*x/total
            row['population_percent_full_source_grid']=100*vals[2]/whole_pop
            rows.append(row)
    df=pd.DataFrame(rows);df.to_csv(SD/'Supplementary_Table4_weighted_exposure.csv',index=False)
    for support,x in df.groupby('support'):
        for key in ['cells','area','population','capacity','cropland']:
            assert np.isclose(x[key+'_percent'].sum(),100,atol=1e-9),(support,key)
    d=df[df.support=='country_domain'].sort_values('display_class')
    a=df[df.support=='active_domain'].sort_values('display_class')
    assert np.allclose(d.population_percent,a.population_percent,atol=1e-10)
    assert np.isclose(p[v.D&~v.ACTIVE].sum(),0)
    STATS['exposure']=dict(country_population=full_pop,full_source_population=whole_pop,
        excluded_population=whole_pop-full_pop,coverage_percent=100*full_pop/whole_pop,
        active_area_km2=float(area[v.ACTIVE].sum()),country_cell_area_km2=float(area[v.D].sum()),
        pressure=a[a.display_class==1].iloc[0].to_dict(),surplus=a[a.display_class==2].iloc[0].to_dict(),
        balance=a[a.display_class==0].iloc[0].to_dict())
    paint_exposure(df)
    print('EXPOSURE',json.dumps(STATS['exposure']),flush=True)

def paint_exposure(df):
    cls=v.classify(v.M)
    a=df[df.support=='active_domain'].sort_values('display_class')
    f=v.fig(178)
    ax=v.ax(f,[.08,.65,.90,.27],'a','Three-axis concordance: active reporting domain')
    from matplotlib.colors import ListedColormap
    v.mapplot(ax,cls,cmap=ListedColormap(v.CC),vmin=-.5,vmax=6.5,mask=v.ACTIVE)
    handles=[Line2D([0],[0],marker='s',color='none',markerfacecolor=col,markeredgecolor='none',markersize=4,label=label) for col,label in zip(v.CC,v.CLABEL)]
    f.legend(handles=handles,ncol=2,loc='center',bbox_to_anchor=(.54,.565),frameon=False,fontsize=5.5)
    ax=v.ax(f,[.31,.10,.64,.32],'b','Population and capacity concentrate in different classes')
    columns=['cells_percent','area_percent','population_percent','capacity_percent']
    marks=['o','s','D','^'];colors=['#888888',v.COL[0],v.RED,v.COL[2]]
    for j,col in enumerate(columns):
        yy=np.arange(7)+(j-1.5)*.15
        ax.scatter(a[col],yy,s=16,marker=marks[j],color=colors[j],label=['Active cells','Active cell area','Retained population','Capacity index'][j])
    ax.set_yticks(range(7),v.CLABEL,fontsize=6);ax.invert_yaxis();ax.set_xlim(-1,100)
    ax.set_xlabel('Share within the stated denominator (%)');ax.grid(axis='x',color='#eeeeee',lw=.5)
    ax.legend(ncol=2,loc='upper center',bbox_to_anchor=(.50,1.29),fontsize=6,frameon=False)
    export(f,'Fig3_population_area_and_capacity_exposure',
        'Fig. 3 | Population and resource exposure are not cell-count prevalence. a, Seven display classes on the active domain. b, Shares of active cells, their spherical whole-cell area, retained country-domain population and represented capacity, calculated at full resolution. All supports use the original full-country-domain share normalisation. Removing structural-zero cells changes cell/area denominators but leaves population and capacity shares unchanged. Population shares sum to 100% of retained population, not the full source grid; the source-data table also reports full-source population shares and excluded population. Whole-cell area is the area of the rasterised country domain, not a fractional-land-area product. Neither pressure classes nor population exposure measure food access or food insecurity. Raster map display is subsampled by two; summaries are not. Source data: Supplementary_Table4_weighted_exposure.csv.')

def crop_audit():
    if (SD/'national_crop_components.csv').exists() and (SD/'crop_composition_scenario_weights.csv').exists():
        r=pd.read_csv(SD/'national_crop_components.csv')
        factors=pd.read_csv(SD/'crop_composition_scenario_weights.csv')
        totals=r.groupby('iso3').capacity_t.sum()
        baseline=v.C.set_index('iso3')[v.KEYS[2]+'_total']
        relative=float((totals.reindex(baseline.index,fill_value=0)-baseline).abs().sum()/baseline.sum())
        assert relative<1e-6,relative
        return finish_crop_audit(r,factors,relative)
    grid=GridSpec(-180,180,-90,90,1/12,4320,2160)
    cropmap={'MZE':'MAIZ','RCD':'RICE','SOY':'SOYB','WHE':'WHEA'}
    coeff={'MZE':(3560,95),'RCD':(2800,60),'SOY':(3350,380),'WHE':(3340,122)}
    # Values are FAO kcal/kg and g protein/kg of as-purchased commodity.
    # Ratios to wheat are used ONLY as dimensionless crop-mixture weights.
    coeffrows=[]; records=[]
    cid=v.CID[v.D].astype(int); maxid=int(v.CID.max())+1
    def sums(x): return np.bincount(cid,weights=x[v.D],minlength=maxid)
    hp=np.zeros(v.D.shape,dtype='float64'); cp=np.zeros_like(hp)
    with zipfile.ZipFile(ROOT/'01_data_raw/spam2020/spam2020V2r2_global_harvested_area.geotiff.zip') as z:
        inv=[parse_spam_member(n) for n in z.namelist() if n.lower().endswith('.tif')]
        for code,spam in cropmap.items():
            member=[r['member'] for r in inv if r['variable_code']=='H' and r['crop_code']==spam and r['system_code']=='A']
            assert len(member)==1,(code,member)
            h=read_spam_member(z,member[0],grid).astype('float64')
            y=read('grid_gaez_'+code.lower()+'_attainable_yield_t_ha.tif')
            valid=v.D&np.isfinite(h)&(h>0)&np.isfinite(y)
            hh=np.where(valid,h,0);cc=np.where(valid,h*y,0)
            assert (cc>=0).all()
            hp+=hh;cp+=cc
            hs,cs=sums(hh),sums(cc)
            for ident in np.unique(cid): records.append(dict(country_id=int(ident),crop=code,matched_harvested_area_ha=float(hs[ident]),capacity_t=float(cs[ident])))
            kcal,protein=coeff[code]
            coeffrows.append(dict(crop=code,spam_crop=spam,kcal_per_kg_as_purchased=kcal,protein_g_per_kg_as_purchased=protein,energy_relative_weight=kcal/3340,protein_relative_weight=protein/122,source='https://www.fao.org/4/X9892E/X9892e05.htm',interpretation='dimensionless composition weights; no dry-matter-to-commodity conversion'))
            print('Reconstructed crop',code,float(cc.sum()),flush=True)
    baseline=np.nan_to_num(read('grid_potential_capacity_mt.tif'),nan=0)
    absolute=float(np.abs(cp[v.D]-baseline[v.D]).sum())
    relative=absolute/baseline[v.D].sum()
    assert relative<1e-6,relative
    mapping=v.U[['country_id','iso3']].drop_duplicates('country_id').copy()
    mapping.iso3=mapping.iso3.replace({'PSX':'PSE','KOS':'XKX'})
    r=pd.DataFrame(records).merge(mapping,on='country_id',validate='many_to_one')
    r=r.groupby(['iso3','crop'],as_index=False)[['matched_harvested_area_ha','capacity_t']].sum()
    r.to_csv(SD/'national_crop_components.csv',index=False)
    factors=pd.DataFrame(coeffrows);factors.to_csv(SD/'crop_composition_scenario_weights.csv',index=False)
    finish_crop_audit(r,factors,relative)

def finish_crop_audit(r,factors,relative):
    full_countries=pd.read_csv(v.SD/'country_audit.csv')
    domain_a=float(full_countries[v.KEYS[0]+'_total'].sum())
    domain_h=float(r.matched_harvested_area_ha.sum())
    domain_c=float(r.capacity_t.sum())
    c=v.C.copy()
    totals=r.groupby('iso3')[['matched_harvested_area_ha','capacity_t']].sum()
    c=c.merge(totals,left_on='iso3',right_index=True,how='left').fillna({'matched_harvested_area_ha':0,'capacity_t':0})
    sensitivity=[]
    for metric,weight in [('energy','energy_relative_weight'),('protein','protein_relative_weight')]:
        rr=r.merge(factors[['crop',weight]],on='crop');rr['weighted']=rr.capacity_t*rr[weight]
        national=rr.groupby('iso3').weighted.sum()
        c[metric+'_weighted_capacity']=c.iso3.map(national).fillna(0)
        c[metric+'_pressure']=np.log2((c.population_global_share+1e-12)/(c[metric+'_weighted_capacity']/national.sum()+1e-12))
        for label,m in [('positive_capacity',c.capacity_t>0),('robust_151',(c.population_total>=1e6)&np.logical_and.reduce([c[k+'_total']>0 for k in v.KEYS]))]:
            x=c.loc[m];base=x[v.KEYS[2]+'_pressure_log2'];alt=x[metric+'_pressure']
            sensitivity.append(dict(scenario=metric,sample=label,n=len(x),spearman=float(spearmanr(base,alt).statistic),class_changes_vs_tonnes=int((band(base)!=band(alt)).sum()),class_changes_vs_area=int((band(x[v.KEYS[0]+'_pressure_log2'])!=band(alt)).sum()),max_abs_pressure_shift=float(np.abs(base-alt).max())))
    pd.DataFrame(sensitivity).to_csv(SD/'composition_weight_sensitivity_summary.csv',index=False)
    a=c[v.KEYS[0]+'_total'];h=c.matched_harvested_area_ha;cap=c.capacity_t
    positive=(a>0)&(h>0)&(cap>0)
    c['harvested_to_physical_ratio']=h/a
    c['weighted_attainable_yield_t_ha']=cap/h
    c['harvest_component']=-np.log2(c.harvested_to_physical_ratio/(domain_h/domain_a))
    c['yield_component']=-np.log2(c.weighted_attainable_yield_t_ha/(domain_c/domain_h))
    c['delta_capacity_area']=c[v.KEYS[2]+'_pressure_log2']-c[v.KEYS[0]+'_pressure_log2']
    c['decomposition_sum']=c.harvest_component+c.yield_component
    exact_unregularised=-np.log2((cap/domain_c)/(a/domain_a))
    err=np.abs(c.loc[positive,'decomposition_sum']-exact_unregularised[positive]).max()
    assert err<1e-10,err
    c['regularisation_and_rounding_residual']=c.delta_capacity_area-c.decomposition_sum
    c.loc[~positive,['harvested_to_physical_ratio','weighted_attainable_yield_t_ha','harvest_component','yield_component','decomposition_sum','regularisation_and_rounding_residual']]=np.nan
    robust=(c.population_total>=1e6)&np.logical_and.reduce([c[k+'_total']>0 for k in v.KEYS])
    c['robust_151']=robust
    c['accounting_type']=pd.Series(np.where(c.harvest_component<=0,'High harvest/physical','Low harvest/physical'),index=c.index)+'; '+pd.Series(np.where(c.yield_component<=0,'high yield','low yield'),index=c.index)
    c.loc[~positive,'accounting_type']='Undefined non-positive support'
    grouped=[]
    for typ,x in c[robust].groupby('accounting_type'):
        grouped.append(dict(accounting_type=typ,n=len(x),median_delta=float(x.delta_capacity_area.median()),capacity_pressure_lower=int((x.delta_capacity_area<0).sum()),capacity_pressure_higher=int((x.delta_capacity_area>0).sum()),class_changes=int((band(x[v.KEYS[0]+'_pressure_log2'])!=band(x[v.KEYS[2]+'_pressure_log2'])).sum())))
    pd.DataFrame(grouped).to_csv(SD/'country_accounting_typology.csv',index=False)
    c.to_csv(SD/'national_crop_weight_and_decomposition.csv',index=False)
    STATS['composition_sensitivity']=sensitivity
    STATS['decomposition']=dict(reconstruction_relative_L1_error=relative,identity_max_error=float(err),harvested_area_ha=domain_h,reference_harvest_physical_ratio=domain_h/domain_a,reference_yield_t_ha=domain_c/domain_h,robust_n=int(robust.sum()),max_robust_floor_rounding_residual=float(np.abs(c.loc[robust,'regularisation_and_rounding_residual']).max()))
    print('CROP SENSITIVITY',json.dumps(sensitivity),flush=True)
    f=v.fig(132)
    ax=v.ax(f,[.12,.20,.46,.66],'a','Two accounting components of the pressure change')
    x=c[robust];col=np.where(x.delta_capacity_area<0,v.BLUE,v.RED)
    ax.scatter(x.harvest_component,x.yield_component,c=col,s=15,alpha=.75)
    lim=max(np.abs(x.harvest_component).max(),np.abs(x.yield_component).max())+.3
    ax.plot([-lim,lim],[lim,-lim],c='#555',ls='--',lw=.7)
    ax.axhline(0,c='#bbb',lw=.5);ax.axvline(0,c='#bbb',lw=.5)
    ax.set_xlim(-lim,lim);ax.set_ylim(-lim,lim)
    ax.set_xlabel(r'Harvest/physical-area component (log$_2$)');ax.set_ylabel(r'Attainable-yield component (log$_2$)')
    offsets={'SLE':(-8,15),'IRQ':(12,18),'NPL':(-40,30),'CHN':(25,15),'USA':(20,-23),'BRA':(-35,-28)}
    for iso,offset in offsets.items():
        row=x[x.iso3==iso].iloc[0];ax.annotate(iso,(row.harvest_component,row.yield_component),xytext=offset,textcoords='offset points',fontsize=6,arrowprops={'arrowstyle':'-','lw':.4,'color':'#666'})
    ax.text(.02,.03,'Blue: lower capacity pressure\nRed: higher capacity pressure',transform=ax.transAxes,fontsize=6)
    ax=v.ax(f,[.72,.20,.25,.66],'b','Composition-weight sensitivity')
    for j,(metric,color) in enumerate([('energy',v.COL[0]),('protein',v.COL[1])]):
        ax.scatter(x[v.KEYS[2]+'_pressure_log2'],x[metric+'_pressure'],s=10,color=color,alpha=.6,label=metric.capitalize()+' weights',marker=['o','^'][j])
    lims=[min(x[v.KEYS[2]+'_pressure_log2'].min(),x.energy_pressure.min(),x.protein_pressure.min())-.3,max(x[v.KEYS[2]+'_pressure_log2'].max(),x.energy_pressure.max(),x.protein_pressure.max())+.3]
    ax.plot(lims,lims,'--',c='#555',lw=.7);ax.set_xlim(lims);ax.set_ylim(lims)
    ax.set_xlabel('Tonnes-based pressure');ax.set_ylabel('Composition-weighted pressure');ax.legend(loc='upper left',fontsize=5.5,frameon=False)
    export(f,'Supplementary_Fig6_accounting_and_composition_sensitivity',
        'Supplementary Fig. 6 | Accounting decomposition and crop-mixture sensitivity. a, National capacity-minus-area pressure is decomposed into the negative logarithms of relative matched four-crop harvested area per physical cropland and relative harvested-area-weighted attainable yield. Thresholds use ratios of country-domain totals, not unweighted country means. The dashed line denotes zero net change in the unregularised identity. Blue/red indicate lower/higher capacity-based pressure. All 151 countries with at least one million inhabitants and positive area, quality and capacity stocks are included. This is an accounting identity, not causal attribution; the harvest/physical ratio combines crop coverage, harvest frequency and differences between source products. b, Energy- and protein-composition weights, relative to wheat, applied to crop-specific configured capacity. These are dimensionless sensitivity scenarios, not edible-calorie/protein production: FAO factors are as-purchased whereas GAEZ yields use dry matter, and moisture, processing and utilisation have not been harmonised. Source data and actual rank/classification changes are provided in the accompanying tables. No independent replicates, inferential tests or causal mechanism are implied.')

def historical():
    h=v.H[v.H.kind=='historical'].copy();h['year']=h.period.astype(int)
    a=float(pd.read_csv(v.SD/'country_audit.csv')[v.KEYS[0]+'_total'].sum())
    h['fixed_cropland_ha']=a;h['ha_per_person_fixed_2019_cropland']=a/h.population_total_country_domain
    h.to_csv(SD/'historical_fixed_resource_land_loading.csv',index=False)
    time=pd.read_csv(ROOT/'04_results/figdata/population_time_series_country.csv')
    time.iso3=time.iso3.replace({'PSX':'PSE','KOS':'XKX'})
    time['period']=time.period.astype(str)
    pp=time.groupby(['iso3','period']).population_total.sum().unstack()
    cols=['2000','2020','SSP2_2050']; common=(pp[cols]>0).all(axis=1)
    m=pp.loc[common,cols].copy()
    shares=m/m.sum(axis=0)
    m['historical_delta_log2']=np.log2(shares['2020']/shares['2000'])
    m['future_delta_log2']=np.log2(shares['SSP2_2050']/shares['2020'])
    m['historical_log2_per_decade']=m.historical_delta_log2/2
    m['future_log2_per_decade']=m.future_delta_log2/3
    m.to_csv(SD/'matched_national_redistribution_rates.csv')
    rates={}
    for name,a0,a1,decades in [('historical','2000','2020',2),('future_SSP2','2020','SSP2_2050',3)]:
        d=np.log2(shares[a1]/shares[a0])/decades
        rates[name]=dict(n=int(common.sum()),median_absolute_log2_per_decade=float(np.abs(d).median()),mean_absolute_log2_per_decade=float(np.abs(d).mean()),population_2020_weighted_absolute_log2_per_decade=float(np.sum(np.abs(d)*shares['2020'])),total_variation_share_change_per_decade=float(.5*np.abs(shares[a1]-shares[a0]).sum()/decades))
    STATS['history']=dict(ha_per_person_2000=float(h.iloc[0].ha_per_person_fixed_2019_cropland),ha_per_person_2020=float(h.iloc[-1].ha_per_person_fixed_2019_cropland),decline_2000_2020_percent=float(100*(1-h.iloc[-1].ha_per_person_fixed_2019_cropland/h.iloc[0].ha_per_person_fixed_2019_cropland)),rates=rates,matched_population_totals=m[cols].sum().to_dict())
    f=v.fig(170)
    ax=v.ax(f,[.08,.56,.90,.35],'a','SSP2 relative redistribution: fixed national resource shares')
    joined=v.G.merge(v.C[['iso3','delta_share_pressure_2050']],on='iso3',how='left')
    joined.plot(ax=ax,column='delta_share_pressure_2050',cmap='RdBu_r',vmin=-1,vmax=1,linewidth=.12,edgecolor='#777',missing_kwds={'color':'#efefef','edgecolor':'#888','hatch':'////','label':'No represented allocation'},rasterized=True)
    ax.set_xlim(-180,180);ax.set_ylim(-60,85);ax.set_xticks([-120,0,120],['120°W','0°','120°E']);ax.set_yticks([-30,30,60],['30°S','30°N','60°N'])
    ax.legend(handles=[__import__('matplotlib').patches.Patch(facecolor='#efefef',hatch='////',edgecolor='#888',label='No represented allocation')],loc='lower left',fontsize=5.5,frameon=False)
    v.bar(f,ScalarMappable(norm=plt.Normalize(-1,1),cmap='RdBu_r'),[.29,.515,.45,.012],r'2050 − 2020 share pressure (log$_2$)',[-1,0,1])
    fut=v.H[v.H.kind=='future']; colors=[v.COL[0],v.COL[2],v.RED,v.COL[1],'#68757e']
    ax=v.ax(f,[.11,.14,.34,.25],'b','Population: historical and SSP endpoints')
    ax.plot(h.year,h.population_total_country_domain/1e9,'o-',c='#444',ms=3,lw=1)
    for i,row in enumerate(fut.itertuples()):
        ax.plot([2020,2050],[h.iloc[-1].population_total_country_domain/1e9,row.population_total/1e9],ls='--',lw=.8,c=colors[i])
        ax.scatter(2050,row.population_total/1e9,s=18,c=colors[i])
    ax.set_xticks([2000,2020,2050]);ax.set_ylabel('Retained population (billion)')
    ax=v.ax(f,[.62,.14,.33,.25],'c','Fixed-cropland land loading')
    ax.plot(h.year,h.ha_per_person_fixed_2019_cropland,'o-',c='#444',ms=3,lw=1)
    for i,row in enumerate(fut.itertuples()):
        value=a/row.population_total
        ax.plot([2020,2050],[a/h.iloc[-1].population_total_country_domain,value],ls='--',lw=.8,c=colors[i])
        ax.scatter(2050,value,s=18,c=colors[i])
    ax.set_xticks([2000,2020,2050]);ax.set_ylabel('Fixed cropland (ha per person)')
    handles=[Line2D([0],[0],color=colors[i],marker='o',ms=3,lw=.8,ls='--',label='SSP'+str(i+1)) for i in range(5)]
    f.legend(handles=handles,ncol=5,loc='lower center',bbox_to_anchor=(.53,.015),frameon=False,fontsize=6)
    export(f,'Fig4_historical_and_future_fixed_resource_loading',
        'Fig. 4 | Relative redistribution and absolute loading against a fixed cropland baseline. a, National SSP2 2050-minus-2020 share pressure; hatched areas have no represented allocation. b,c, Historical retained population and fixed-2019-cropland hectares per person for 2000, 2005, 2010, 2015 and 2020, with five 2050 SSP endpoints. Dashed lines connect endpoints only and do not represent annual projections or uncertainty intervals. Historical trajectories use one WorldPop product family; future national stocks use a distinct scenario product and 2020 within-country weights. Cropland, yields and crop allocation are fixed in every year. Thus c is a demographic counterfactual, not observed historical cropland change. The source table separately reports population coverage; all plotted population totals refer to the country domain. Matched-country rate comparisons renormalise population over the same positive-country set in both intervals and report changes per decade. These rates do not isolate migration.')
    print('HISTORY',json.dumps(STATS['history']),flush=True)

def contrasts():
    f=v.fig(187);clip=[]
    for i,(z,title,limit) in enumerate([(v.M[0],'Physical-cropland pressure',8),(v.M[1]-v.M[0],'Quality-equivalent minus physical-area pressure',3),(v.M[2]-v.M[0],'Capacity minus physical-area pressure',3)]):
        ax=v.ax(f,[.08,.735-i*.30,.90,.205],chr(97+i),title)
        im=v.mapplot(ax,z,vmin=-limit,vmax=limit,mask=v.COMMON)
        vals=z[v.COMMON]
        extend='both' if (vals < -limit).any() and (vals>limit).any() else ('max' if (vals>limit).any() else 'neither')
        cb=f.colorbar(im,cax=f.add_axes([.29,.700-i*.30,.46,.010]),orientation='horizontal',ticks=[-limit,0,limit],extend=extend)
        cb.set_label(r'Pressure (log$_2$)' if i==0 else r'Pressure difference (log$_2$)',labelpad=2)
        cb.ax.tick_params(labelsize=6,length=2,pad=1);cb.outline.set_linewidth(.5)
        clip.append(dict(panel=chr(97+i),limit=limit,n=len(vals),below=int((vals < -limit).sum()),above=int((vals>limit).sum()),min=float(vals.min()),max=float(vals.max())))
    pd.DataFrame(clip).to_csv(SD/'map_display_range_audit.csv',index=False)
    export(f,'Fig1_area_pressure_and_resource_definition_differences',
        'Fig. 1 | How resource definitions change local pressure. a, Physical-cropland pressure. b,c, Quality-equivalent-minus-area and capacity-minus-area pressure. Every panel uses the same 569,780 common-positive cells and the same full-country-domain normalisation. White excludes unsupported cells; it is not a zero contrast. Warm/cool colours indicate higher/lower pressure for the alternative resource definition. Difference limits are ±3 log2 units; pressure limits are ±8. Values outside display limits saturate without altering source data; counts and full ranges are recorded in map_display_range_audit.csv. Raster display samples every second row/column, while numerical analysis uses full resolution. Complete active-domain stock/pressure maps remain supplementary. Source arrays are unchanged from the preceding audited release.')

def transitions_and_scatter():
    f=v.fig(145);rows=[]
    c=v.C[(v.C.population_total>=1e6)&np.logical_and.reduce([v.C[k+'_total']>0 for k in v.KEYS])]
    for i,(j,k,title) in enumerate([(0,1,'Area → quality'),(1,2,'Quality → capacity'),(0,2,'Area → capacity')]):
        ax=v.ax(f,[.11+i*.30,.52,.22,.33],chr(97+i),title)
        matrix=pd.crosstab(c[v.KEYS[k]+'_band'],c[v.KEYS[j]+'_band']).reindex(index=[0,1,2],columns=[0,1,2],fill_value=0).fillna(0).to_numpy(int)
        ax.imshow(matrix,cmap='Blues',vmin=0,vmax=100,aspect='auto')
        ax.set_xticks(range(3),['S','B','P']);ax.set_yticks(range(3),['S','B','P']);ax.set_xlabel('From');ax.set_ylabel('To')
        for rr in range(3):
            for cc in range(3):
                ax.text(cc,rr,str(matrix[rr,cc]),ha='center',va='center',color='white' if matrix[rr,cc]>60 else '#222',fontsize=8)
                rows.append(dict(transition=title,from_class=cc,to_class=rr,n=int(matrix[rr,cc])))
        ax.text(.5,-.31,f'{151-np.trace(matrix)} / 151 change class',transform=ax.transAxes,ha='center',fontsize=6)
    ax=v.ax(f,[.14,.14,.80,.20],'d','Three-step national classification paths')
    path=c.groupby([k+'_band' for k in v.KEYS]).size().reset_index(name='n').sort_values('n',ascending=False)
    path.to_csv(SD/'three_step_national_classification_paths.csv',index=False)
    path['path']=path.apply(lambda r:' → '.join(['S','B','P'][int(r[k+'_band'])] for k in v.KEYS),axis=1)
    # Display all observed paths, not a selected subset.
    ax.bar(np.arange(len(path)),path.n,color=v.BLUE,width=.7)
    ax.set_xticks(np.arange(len(path)),path.path,rotation=55,ha='right',fontsize=5.5);ax.set_ylabel('Countries')
    pd.DataFrame(rows).to_csv(SD/'three_definition_transition_counts_151.csv',index=False)
    export(f,'Fig2_three_definition_national_transitions',
        'Fig. 2 | National transitions across all three resource definitions. a–c, Pairwise transition matrices for the same 151 populated national codes with at least one million inhabitants and positive stocks under all three definitions. Columns are the starting class and rows the destination class; S, B and P denote surplus, balance and pressure at ±0.5 log2 thresholds. A common colour scale is used. d, Counts for every observed ordered area → quality → capacity path. These paths preserve joint information that pairwise matrices alone do not capture. All-240-code transitions and illustrative national profiles remain available in the preceding source release. Source data are supplied for every matrix and path; no inferential tests are implied.')
    f=v.fig(112)
    ax=v.ax(f,[.13,.20,.55,.65],'a','Capacity versus realised-production pressure')
    z=v.C[(v.C[v.KEYS[2]+'_total']>0)&(v.C.production_total>0)].copy()
    x=z[v.KEYS[2]+'_pressure_log2'];y=z.production_pressure_log2
    inside=x.between(-4,8)&y.between(-4,8)
    ax.axvspan(-.5,.5,color='#f0f0f0',zorder=-3);ax.axhspan(-.5,.5,color='#f0f0f0',zorder=-3)
    ax.scatter(x[inside],y[inside],c=v.BLUE,s=15,alpha=.7)
    ax.plot([-4,8],[-4,8],'--',c='#666',lw=.7);ax.set_xlim(-4,8);ax.set_ylim(-4,8)
    ax.set_xlabel('Capacity pressure (log2)');ax.set_ylabel('Production pressure (log2)')
    ax.text(.03,.95,f'{inside.sum()}/{len(z)} codes in zoom; {(~inside).sum()} outside',transform=ax.transAxes,va='top',fontsize=6)
    for iso in ['SLE','IRQ','USA','CHN','IND']:
        xx=z[z.iso3==iso].iloc[0]
        ax.annotate(iso,(xx[v.KEYS[2]+'_pressure_log2'],xx.production_pressure_log2),xytext=(3,3),textcoords='offset points',fontsize=6)
    inset=v.ax(f,[.78,.47,.19,.34],'b','Full range')
    inset.scatter(x,y,c=v.BLUE,s=7,alpha=.6);lim=[min(x.min(),y.min())-.3,max(x.max(),y.max())+.3]
    inset.plot(lim,lim,'--',c='#777',lw=.5);inset.set_xlim(lim);inset.set_ylim(lim)
    from matplotlib.patches import Rectangle
    inset.add_patch(Rectangle((-4,-4),12,12,fill=False,edgecolor=v.RED,lw=.8))
    z['inside_zoom']=inside;z.to_csv(SD/'production_scatter_display_audit.csv',index=False)
    STATS['production_scatter']=dict(n=len(z),inside=int(inside.sum()),outside=int((~inside).sum()),full_min=float(lim[0]),full_max=float(lim[1]))
    export(f,'Supplementary_Fig4_production_pressure_zoom_and_full_range',
        'Supplementary Fig. 4 | Capacity and realised-production pressure without concealing extremes. a, A −4 to +8 log2 zoom for populated national codes with positive capacity and commodity-production stocks; the number inside/outside the zoom is stated. b, All positive-stock cases on their full range, with the zoom rectangle outlined. Zero stocks are excluded from both panels; very small positive stocks can still produce large pressure. The shaded bands denote ±0.5 balance for each axis, not agreement between indices. This is a diagnostic comparison, not a dry-matter-to-commodity yield gap. The source table records every point and whether it lies inside the zoom.')

def report():
    e=STATS['exposure'];p=e['pressure'];s=e['surplus'];h=STATS['history'];sen=STATS['composition_sensitivity']
    draft=f'''# Evidence-backed additions for Nature Sustainability

## Results: population and resource exposure

Three-axis pressure covered {p['cells_percent']:.2f}% of active cells and {p['area_percent']:.2f}% of their spherical whole-cell area, but contained {p['population_percent']:.2f}% of retained country-domain population ({p['population']/1e9:.3f} billion people). Three-axis surplus covered {s['cells_percent']:.2f}% of active cells and contributed {s['capacity_percent']:.2f}% of represented four-crop attainable capacity. These population shares refer to the {e['country_population']/1e9:.3f} billion people retained by the country mask, rather than the {e['full_source_population']/1e9:.3f} billion full-grid source total. The source table gives both denominators. Excluding structural-zero cells changed cell-count and area prevalence but did not change population or capacity shares, because those cells contained neither represented population nor resources.

## Results: demographic loading through time

Against the same fixed 2019 cropland baseline, country-domain hectares per person decreased from {h['ha_per_person_2000']:.4f} in 2000 to {h['ha_per_person_2020']:.4f} in 2020 ({h['decline_2000_2020_percent']:.1f}%). This trajectory isolates demographic loading and does not measure historical cropland loss. On the matched positive-country support, the median absolute change in national population share was {h['rates']['historical']['median_absolute_log2_per_decade']:.4f} log2 units per decade during 2000–2020, compared with {h['rates']['future_SSP2']['median_absolute_log2_per_decade']:.4f} under SSP2 during 2020–2050 (n = {h['rates']['historical']['n']}). The source table also reports population-weighted rates and total-variation change; these are descriptive redistribution diagnostics, not estimates of migration.

## Supplementary Methods: weighted prevalence

For class g and reporting support S, weighted prevalence was calculated as F(g;w,S) = sum over i in S of [w_i I(class_i=g)] / sum over i in S of w_i. We evaluated w_i = 1, spherical whole-cell area, population, configured capacity and physical cropland. Pressure shares were always normalised over the original country domain; changing reporting support did not renormalise the pressure surfaces. Population exposure is conditional on retained source population. The alternative full-source exposure denominator leaves the excluded population unclassified rather than redistributing it. Spherical whole-cell area uses radius 6371.0088 km and latitude-edge integration; it must not be described as exact fractional land area.

## Supplementary Methods: accounting typology

For national code k, let H_k be four-crop harvested area on the same valid area–yield support used to construct capacity, A_k physical cropland and C_k the sum of crop-specific H times attainable yield. The unregularised identity is:

ΔM(C−A)_k = −log2[(H_k/A_k)/(H_D/A_D)] − log2[(C_k/H_k)/(C_D/H_D)].

The two terms define four accounting types relative to ratios of country-domain totals. The identity is exact for positive stocks before numerical stabilisation; the source table reports the regularisation/rounding residual against published pressures. It does not identify climate, irrigation, fallow or multiple cropping as causal drivers. In particular, H/A combines the four-crop share, harvest frequency and differences between MapSPAM and GLAD coverage. No climate or income classification was inferred from country names.

## Supplementary Results: composition-weight sensitivity

'''
    for r in sen:
        draft+=f"For {r['scenario']}-composition weights in the {r['sample']} sample (n = {r['n']}), Spearman rank correlation with tonnes-based capacity pressure was {r['spearman']:.5f}; {r['class_changes_vs_tonnes']} countries changed class relative to the tonnes baseline, and {r['class_changes_vs_area']} differed from area-based classification. The maximum absolute pressure shift was {r['max_abs_pressure_shift']:.4f} log2 units.\n\n"
    draft+='''These scenarios use dimensionless crop weights obtained by dividing FAO commodity energy/protein coefficients by the corresponding wheat coefficient. They test sensitivity to crop composition only. They do not quantify edible-calorie or protein capacity because GAEZ dry-matter yields and FAO as-purchased coefficients have not been harmonised for moisture, processing, edible fractions or allocation to food/feed. Accordingly, no nutritional self-sufficiency claim is made. A definitive nutritional-capacity analysis remains contingent on that harmonisation.

Sources verified: [FAO Food Balance Sheets handbook, Annex I](https://www.fao.org/4/X9892E/X9892e05.htm); [FAO commodity-basis explanation](https://www.fao.org/4/X9892E/X9892e02.htm); [official GAEZ v5 biomass/yield documentation](https://github.com/un-fao/gaezv5/wiki/04.-Module-II-(Biomass-and-yield-calculation)). Accessed 20 October 2026.

## Scope and terminology

Canonical terms: physical cropland (A); quality-equivalent cropland (Q); four-crop attainable-capacity index (C); retained country-domain population; active domain; common-positive support. The legacy filename potential_capacity_mt stores metric tonnes, not megatonnes. New files use capacity_t. These additions and replacement figure candidates are separate from the preceding Word manuscript; figure numbers/cross-references must be integrated together before submission. No whole-manuscript rewrite or replacement of the original Word file was performed.
'''
    (OUT/'Results_and_Supplementary_additions.md').write_text(draft,encoding='utf-8')
    (OUT/'figure_legends.md').write_text('\n\n'.join(CAP.values())+'\n',encoding='utf-8')
    (OUT/'verification.json').write_text(json.dumps(STATS,indent=2,ensure_ascii=False),encoding='utf-8')
    cn=f'''# 本轮实算结论与采用建议

1. 三轴压力：活跃网格占 {p['cells_percent']:.2f}%，活跃域球面整像元面积占 {p['area_percent']:.2f}%，承载保留域人口 {p['population_percent']:.2f}%（{p['population']/1e8:.2f} 亿）。不能写成未经限定的全球人口比例。
2. 三轴盈余：活跃网格占 {s['cells_percent']:.2f}%，贡献已表示四作物产能 {s['capacity_percent']:.2f}%。采用真实值，不采用示例预期。
3. 国家类型学已经改为可验证的收获面积/物理耕地与单产两项分解，未将相关性写成气候或复种机制。
4. 历史曲线已加入，2000–2020 固定资源人均耕地下降 {h['decline_2000_2020_percent']:.1f}%；不是实际历史耕地面积变化。
5. FAO 权重敏感性已计算，详见表；不是完成了干物质与商品基准一致的营养产能计算。真正的热量/蛋白供给分析仍需水分和加工口径统一。
6. 新图1改为面积压力与两个差值；新图2保留三阶段转移的联合路径；新图3突出人口、面积和产能暴露；新图4连接历史与情景端点并标记缺失分配；支撑图4用主图放大加完整范围展示，不隐藏极值；支撑图6新增分解和权重敏感性。
7. 2020 掩膜剔除 {e['excluded_population']/1e8:.2f} 亿人口（不是0.19亿），原因不能全部归为海岸线。

交付为新增分析、可替换图件与针对性英文段落；原 Word 正文与旧文件未覆盖。完整包包含4幅主图候选与6幅支撑图，其中6幅本轮重绘、4幅支撑图沿用前版。全部提供 PDF/SVG/PNG/600 dpi TIFF，沿用图的来源记录见导出核验表。
'''
    (OUT/'实算结果与修改说明.md').write_text(cn,encoding='utf-8')
    (OUT/'figure_contract.md').write_text('''# Figure contract

Backend: Python/matplotlib only. Quantitative geographic composites; 183 mm width, editable Arial PDF/SVG, 300 dpi PNG preview and 600 dpi RGB TIFF. Full-resolution data for summaries, 2x subsampling for map display. No synthetic data or inferential sampling errors. Old inputs preserved.

Fig1: identify changes due to definitions; baseline pressure and two common-positive difference maps. Risks: numerical floors, display saturation and omitted non-cropland populations; audit saturation explicitly.
Fig2: quantify three-definition national class transitions; three matrices plus every joint path. Risk: restricted 151-country coverage, state it; preserve all-country data separately.
Fig3: quantify exposure beyond equal cell counts; active map plus population/area/capacity shares. Risks: country-mask coverage and whole-cell-versus-land-area terminology.
Fig4: separate fixed-resource demographic loading from relative redistribution; missing-allocation hatch and observed-source dates joined only by endpoint scenario segments. Risk: no claim of homogeneous historic/future population source or observed historical cropland change.
SI4: preserve all positive-stock outliers with zoom and full view. SI6: accounting identity and composition weights, not causality or nutritional output. No unsupported climate/income explanations.
''',encoding='utf-8')
    shutil.copy2(Path(__file__),OUT/Path(__file__).name)

if __name__=='__main__':
    import sys
    if '--resume' in sys.argv:
        frame=pd.read_csv(SD/'Supplementary_Table4_weighted_exposure.csv')
        a=frame[frame.support=='active_domain']
        full_pop=float(frame[frame.support=='country_domain'].population.sum())
        whole=float(v.H.loc[v.H.period.astype(str)=='2020','raw_worldpop_total'].iloc[0])
        STATS['exposure']=dict(country_population=full_pop,full_source_population=whole,excluded_population=whole-full_pop,coverage_percent=100*full_pop/whole,active_area_km2=float(a.spherical_cell_area_km2.sum()),country_cell_area_km2=float(frame[frame.support=='country_domain'].spherical_cell_area_km2.sum()),pressure=a[a.display_class==1].iloc[0].to_dict(),surplus=a[a.display_class==2].iloc[0].to_dict(),balance=a[a.display_class==0].iloc[0].to_dict())
        CAP['Fig3_population_area_and_capacity_exposure']='Fig. 3 | Population and resource exposure differ from cell-count prevalence. a, Seven display classes on the active domain. b, Shares of active cells, their spherical whole-cell area, retained country-domain population and represented capacity, calculated at full resolution. All pressure surfaces retain full-country-domain share normalisation. Removing structural-zero cells changes cell/area denominators but leaves population and capacity shares unchanged. Population shares refer to retained population, not the full source grid; whole-cell area is not fractional land area. Map display is subsampled by two. Source data: Supplementary_Table4_weighted_exposure.csv. These indices do not measure food access or food insecurity.'
    else:exposure()
    crop_audit();historical();contrasts();transitions_and_scatter();report()
    print('Analysis and figure candidates complete:',OUT,flush=True)
