"""Source-backed, Python-only figure prioritisation for the sustainability narrative."""
from pathlib import Path
import shutil, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import ListedColormap
from matplotlib.cm import ScalarMappable
import revise_nc_figures as v

OUT=v.ROOT/'07_manuscript/packages/nature_sustainability/revision_20261020'
FIG=OUT/'figures';FIG.mkdir(parents=True,exist_ok=True)
SD=OUT/'source_data';SD.mkdir(exist_ok=True)
v.FIG=FIG
CAP={}

def finish(f,name,caption):
    v.save(f,name);CAP[name]=caption

def main1():
    f=v.fig(166)
    a=v.ax(f,[.08,.54,.89,.38],'a','Changing area to capacity: difference in pressure')
    delta=v.M[2]-v.M[0]
    im=v.mapplot(a,delta,vmin=-4,vmax=4,mask=v.COMMON)
    v.bar(f,im,[.27,.495,.52,.012],r'Capacity pressure − area pressure (log$_2$)',[-4,-2,0,2,4])
    for i,j in enumerate([0,2]):
        a=v.ax(f,[.08+.5*i,.13,.40,.25],chr(98+i),['Area-based pressure','Capacity-based pressure'][i])
        im=v.mapplot(a,v.M[j],mask=v.COMMON)
    v.bar(f,im,[.30,.085,.45,.012],r'Population share / resource share (log$_2$)',[-8,-4,0,4,8])
    finish(f,'Fig1_resource_definition_contrast',
      'Fig. 1 | Resource definitions and the geography of estimated pressure. a, Capacity-minus-area pressure on the common-positive support, where population, physical cropland, quality-equivalent cropland and attainable capacity are all positive (569,780 cells). Positive values indicate higher estimated pressure under capacity. b,c, Area- and capacity-based pressures on that identical support. All shares retain the full country-domain normalisation; the support is not used to renormalise stocks. This restriction prevents absent-stock numerical floors from dominating the contrast, but omits populated non-cropland cells. Complete broad-domain maps remain in Supplementary Fig. 2. Display limits are ±4 for differences and ±8 for pressures; numerical source values are not clipped. Raster display uses every second row and column; numerical summaries use full resolution. Source data are provided in the source-data package.')

def main2():
    f=v.fig(171)
    large=v.C[(v.C.population_total>=1e6)&np.logical_and.reduce([v.C[k+'_total']>0 for k in v.KEYS])]
    rows=[]
    for i,(df,title) in enumerate([(v.C,'All populated codes (n = 240)'),(large,'Large, positive-resource countries (n = 151)')]):
        a=v.ax(f,[.10+.51*i,.59,.33,.29],chr(97+i),title)
        matrix=pd.crosstab(df[v.KEYS[2]+'_band'],df[v.KEYS[0]+'_band']).reindex(index=[0,1,2],columns=[0,1,2],fill_value=0).fillna(0).to_numpy(dtype=int)
        a.imshow(matrix,cmap='Blues',vmin=0,vmax=150,aspect='auto')
        a.set_xticks(range(3),['Surplus','Balance','Pressure']);a.set_yticks(range(3),['Surplus','Balance','Pressure'])
        a.set_xlabel('Area-based class');a.set_ylabel('Capacity-based class')
        for r in range(3):
            for c in range(3):
                a.text(c,r,str(matrix[r,c]),ha='center',va='center',fontsize=8,color='white' if matrix[r,c]>85 else '#222')
                rows.append(dict(set=title,area_class=c,capacity_class=r,count=int(matrix[r,c])))
        changes=np.sum(matrix)-np.trace(matrix)
        a.text(.5,-.29,f'{changes}/{len(df)} change class ({100*changes/len(df):.1f}%)',transform=a.transAxes,ha='center',fontsize=7)
    pd.DataFrame(rows).to_csv(SD/'national_transition_counts.csv',index=False)
    a=v.ax(f,[.20,.11,.75,.29],'c','Illustrative national pressure profiles')
    ex=v.C.set_index('iso3').loc[['SLE','NIC','NPL','IRQ','CHN','IND','BRA','USA']]
    a.axvspan(-.5,.5,color='#e6e6e6',zorder=-2);a.axvline(0,c='#aaa',lw=.5)
    for j,k in enumerate(v.KEYS):a.scatter(ex[k+'_pressure_log2'],np.arange(8)+(j-1)*.19,c=v.COL[j],s=18,label=v.NAMES[j])
    a.set_yticks(range(8),ex.country.str.replace('United States of America','United States',regex=False));a.invert_yaxis()
    a.set_xlim(-3,6);a.set_xlabel(r'Pressure (log$_2$ population share / resource share)')
    f.legend(*a.get_legend_handles_labels(),loc='center',bbox_to_anchor=(.58,.46),ncol=3,frameon=False,fontsize=6)
    finish(f,'Fig2_national_classification_transitions',
      'Fig. 2 | National classification changes under alternative resource definitions. a,b, Transition counts from area-based columns to capacity-based rows at thresholds −0.5 and +0.5, for all 240 populated national codes and the restricted 151-country set, respectively. The restricted set requires at least one million baseline inhabitants and positive stocks under all three resource definitions. Diagonal cells retain the same class; off-diagonal cells change class. A common colour scale is used in both matrices. There are 60 and 51 off-diagonal cases, respectively. c, Three-denominator profiles for eight illustrative examples, not a representative sample or an independently selected validation set. Grey shading denotes the balanced band. National quantities were summed across map units before recalculating shares and pressures. No inferential tests or error intervals are implied. Source data are provided in the source-data package.')

def main3():
    f=v.fig(183);cls=v.classify(v.M)
    a=v.ax(f,[.08,.61,.90,.30],'a','Three-axis concordance on the active domain')
    v.mapplot(a,cls,cmap=ListedColormap(v.CC),vmin=-.5,vmax=6.5,mask=v.ACTIVE)
    handles=[Line2D([0],[0],marker='s',color='none',markerfacecolor=c,markeredgecolor='none',markersize=5,label=l) for c,l in zip(v.CC,v.CLABEL)]
    f.legend(handles=handles,loc='center',bbox_to_anchor=(.54,.545),ncol=2,frameon=False,fontsize=6)
    a=v.ax(f,[.26,.12,.29,.31],'b','Class prevalence by reporting support')
    df=pd.read_csv(v.SD/'display_class_prevalence.csv')
    for j,support in enumerate(['country_domain','active_domain']):
        vals=df[df.support==support].sort_values('display_class').percent
        a.barh(np.arange(7)+(j-.5)*.30,vals,height=.27,color=v.CC,alpha=.43 if j==0 else 1,edgecolor='#555' if j==0 else 'none',linewidth=.3)
    a.set_yticks(range(7),v.CLABEL,fontsize=5.5);a.invert_yaxis();a.set_xlim(0,75);a.set_xlabel('Geographic cells (%)')
    a.text(.98,.01,'Pale: full domain\nSolid: active domain',transform=a.transAxes,fontsize=5.5,ha='right')
    a=v.ax(f,[.72,.12,.25,.31],'c','Apparent balance and threshold')
    threshold=pd.read_csv(v.SD/'threshold_support_sensitivity.csv')
    for j,support in enumerate(['Country domain','Active domain','Common positive']):
        x=threshold[(threshold.group=='All axes balanced')&(threshold.support==support)]
        a.plot(x.threshold,x.percent,marker=['o','s','^'][j],ms=3,lw=1,c=[v.BLUE,v.RED,'#777'][j],label=support)
    a.set_xticks([.25,.5,.75,1]);a.set_ylim(0,45);a.set_xlabel(r'Threshold (log$_2$)');a.set_ylabel('All-axis balanced cells (%)')
    a.legend(loc='upper left',bbox_to_anchor=(0,.84),frameon=False,fontsize=5.5)
    finish(f,'Fig3_spatial_concordance_and_support',
      'Fig. 3 | Spatial concordance and reporting support. a, Seven display groups derived from the 27 three-axis states on the 1,892,767 active cells. Active cells have positive represented population or at least one positive represented resource; white cells lie outside this support. b, Full-domain and active-domain class fractions, using 3,085,707 and 1,892,767 cells as denominators. The balanced fraction is 39.98% and 2.15%, respectively; 1,192,940 structural-zero cells explain most of this difference. c, Balanced fractions across thresholds for the full, active and 569,780-cell common-positive supports. All supports retain identical resource/population normalisation; only the reporting cells change. Percentages count geographic cells equally and are not physical-area or population-exposure shares. Complete pressure/surplus threshold curves are in Supplementary Fig. 5. Source data are provided in the source-data package.')

def main4():
    f=v.fig(152);a=v.ax(f,[.08,.53,.90,.38],'a','Relative demographic redistribution under SSP2 in 2050')
    joined=v.G.merge(v.C[['iso3','delta_share_pressure_2050']],on='iso3',how='left')
    joined.plot(ax=a,column='delta_share_pressure_2050',cmap='RdBu_r',vmin=-1,vmax=1,linewidth=.15,edgecolor='#777',missing_kwds={'color':'#e9e9e9'},rasterized=True)
    a.set_xlim(-180,180);a.set_ylim(-60,85);a.set_xticks([-120,0,120],['120°W','0°','120°E']);a.set_yticks([-30,30,60],['30°S','30°N','60°N'])
    v.bar(f,ScalarMappable(norm=plt.Normalize(-1,1),cmap='RdBu_r'),[.27,.485,.50,.012],r'Change in share pressure (log$_2$; all fixed resources)',[-1,-.5,0,.5,1])
    a=v.ax(f,[.18,.12,.73,.24],'b','Absolute land availability under fixed cropland')
    x=pd.read_csv(v.SD/'cropland_per_person.csv');baseline=x.iloc[0].cropland_ha_per_person
    colors=[v.COL[0],v.COL[2],v.RED,v.COL[1],'#68757e']
    for i,r in enumerate(x.iloc[1:].itertuples()):
        value=r.cropland_ha_per_person;a.plot([value,baseline],[i,i],c='#aaa',lw=1)
        a.scatter(baseline,i,c='#999',marker='|',s=60);a.scatter(value,i,c=colors[i],s=24)
        a.text(value-.0015,i,f'{value:.4f}',va='center',ha='right',fontsize=6)
        a.text(.166,i,f'−{100*(1-value/baseline):.1f}%',ha='left',va='center',fontsize=6,color=colors[i])
    a.plot([baseline,baseline],[-.1,4.15],c='#999',ls='--',lw=.65)
    a.set_yticks(range(5),['SSP1','SSP2','SSP3','SSP4','SSP5']);a.invert_yaxis();a.set_xlim(.105,.183);a.set_xticks([.11,.13,.15,.17]);a.set_ylim(4.5,-1)
    a.text(baseline,-.65,'2020 baseline\n0.1557 ha per person',ha='center',va='center',fontsize=6)
    a.set_xlabel('Physical cropland (ha per person)')
    finish(f,'Fig4_relative_change_absolute_land_loading',
      'Fig. 4 | Relative redistribution and absolute land loading. a, SSP2 2050 minus 2020 national share pressure for the 201 populated codes with a represented allocation. Grey indicates missing allocation, not population collapse. Under fixed resource shares, temporal pressure differences are the same across denominators away from the numerical floor. b, Global country-domain physical cropland per person under the five 2050 scenarios, compared with the fixed 2020 baseline. Labels report hectares per person and reductions of 15.3–22.6%. Future national stocks are distributed using the unadjusted 2020 WorldPop within-country weights; cropland, yields and crop allocation remain fixed. Relative improvement in a location must not be read as global easing of absolute land constraints. These are demographic counterfactuals, not forecasts of food availability. Source data are provided in the source-data package.')

def supplementary():
    f=v.fig(132);a=v.ax(f,[.08,.51,.90,.40],'a','Population distribution and geographic support')
    im=v.mapplot(a,np.log10(np.maximum(v.P,1)),cmap='YlOrRd',vmin=0,vmax=6,mask=v.D&(v.P>0))
    v.bar(f,im,[.25,.465,.55,.014],r'Population count (log$_{10}$ persons)',[0,2,4,6])
    a=v.ax(f,[.15,.12,.75,.24],'b','Historical source totals and country-domain coverage')
    h=v.H[v.H.kind=='historical'];x=np.arange(len(h));a.bar(x-.17,h.raw_worldpop_total/1e9,.34,color=v.BLUE,label='Full grid');a.bar(x+.17,h.population_total_country_domain/1e9,.34,color='#cba676',label='Country domain')
    a.set_xticks(x,h.period);a.set_ylabel('Population (billion persons)');a.set_ylim(0,9.1);a.legend(ncol=2,frameon=False,loc='upper left')
    finish(f,'Supplementary_Fig1_population_coverage',
      'Supplementary Fig. 1 | Population support and historical coverage. a, WorldPop 2020 cell counts in the country domain, not density. b, Full-grid and retained totals for the five historical dates from the same population-product family. In 2020 the totals are 7.970 and 7.783 billion, with 0.187 billion excluded by country masking and coverage of 97.66%. Excluded population was not redistributed or calibrated. The source table retains unrounded totals and coverage fractions for all dates. Source data are provided in the source-data package.')
    for ext in ['pdf','svg','png','tiff']:
        shutil.copy2(v.OUT/'figures'/('Fig2_denominator_geographies.'+ext),FIG/('Supplementary_Fig2_full_resource_maps.'+ext))
    CAP['Supplementary_Fig2_full_resource_maps']='Supplementary Fig. 2 | Complete resource and pressure maps. The broad-domain pressure maps for physical area, quality-equivalent cropland and capacity are shown beside the corresponding positive resource-stock maps. Pressure maps show active cells, with identical ±8 display limits; stock maps use their stated logarithmic units. All totals and shares use the same country mask. Unlike the common-positive view in main Fig. 1, these maps retain populated cells without represented crop resources. Large pressures near absent stocks are numerical-floor-sensitive and do not rank food insecurity. Source data are provided in the source-data package.'
    n=v.A['native'];al=v.A['allocated'];mask=v.D&np.isfinite(n)&(al>0)
    delta=v.press(n,v.R[2],mask)-v.press(al,v.R[2],mask)
    f=v.fig(140);a=v.ax(f,[.08,.53,.90,.39],'a','Native versus allocated SSP2 on matched cells')
    im=v.mapplot(a,delta,vmin=-2,vmax=2,mask=mask);v.bar(f,im,[.26,.485,.54,.012],r'Native − allocated share pressure (log$_2$)',[-2,0,2])
    a=v.ax(f,[.29,.13,.46,.25],'b','National population totals')
    ok=(v.C.native_population_2050>0)&(v.C.allocated_population_2050>0)
    a.scatter(v.C.loc[ok,'allocated_population_2050']/1e6,v.C.loc[ok,'native_population_2050']/1e6,s=10,c=v.BLUE,alpha=.65);a.plot([.01,3000],[.01,3000],'--',c='#777',lw=.6)
    a.set_xscale('log');a.set_yscale('log');a.set_xlim(.01,3000);a.set_ylim(.01,3000);a.set_xlabel('Allocated population (million persons)');a.set_ylabel('Native FuturePop (million persons)')
    a.text(.03,.92,f'n = {ok.sum()} national codes',transform=a.transAxes,fontsize=6)
    finish(f,'Supplementary_Fig3_future_provenance',
      'Supplementary Fig. 3 | Future population provenance sensitivity. a, Native FuturePop minus fixed-pattern allocation pressure on the identical matched support, with each product separately normalised over that support. b, National population totals where both products are positive. Native full-grid and country-domain totals are 9.633 and 9.427 billion; the allocated country-domain total is 9.591 billion. Native and allocated matched-cell totals are 9.415 and 9.555 billion across 1,220,097 cells. Native FuturePop and the national-stock allocation differ in source generation as well as spatial allocation, so this comparison does not isolate an urbanisation mechanism or provide independent forecast validation. Source data are provided in the source-data package.')
    prod=v.A['production'];mp=v.press(v.P,prod);pmask=v.D&(v.P>0)&np.isfinite(prod)&(prod>0)
    f=v.fig(140);a=v.ax(f,[.08,.53,.90,.39],'a','Pressure relative to realised four-crop production')
    im=v.mapplot(a,mp,mask=pmask);v.bar(f,im,[.26,.485,.54,.012],r'Production pressure (log$_2$)',[-8,0,8])
    a=v.ax(f,[.29,.12,.46,.26],'b','Capacity and realised-production pressure: positive stocks')
    ok=(v.C[v.KEYS[2]+'_total']>0)&(v.C.production_total>0)
    z=v.C[ok];xx=z[v.KEYS[2]+'_pressure_log2'];yy=z.production_pressure_log2
    a.scatter(xx,yy,c=v.BLUE,s=13,alpha=.65);lo=min(xx.min(),yy.min())-.3;hi=max(xx.max(),yy.max())+.3;a.plot([lo,hi],[lo,hi],'--',lw=.6,c='#777');a.set_xlim(lo,hi);a.set_ylim(lo,hi)
    a.set_xlabel(r'Capacity pressure (log$_2$)');a.set_ylabel(r'Production pressure (log$_2$)');a.text(.03,.92,f'n = {ok.sum()} national codes',transform=a.transAxes,fontsize=6)
    z.to_csv(SD/'production_positive_stock_comparison.csv',index=False)
    finish(f,'Supplementary_Fig4_realised_production',
      'Supplementary Fig. 4 | Realised production as a separate diagnostic. a, Production pressure only where both represented population and realised four-crop production are positive. Shares retain full country-domain normalisation. b, Capacity-versus-production pressure for populated national codes with positive stocks under both definitions; the plotted sample size is labelled. Excluding absent-stock cases avoids apparent agreement induced by the shared stabilisation floor. The four-crop production total on the country domain remains 3.051 billion commodity tonnes. Commodity production and configured GAEZ yield output have different conventions; their difference is not a yield gap, and neither index measures food access. Source data are provided in the source-data package.')
    for ext in ['pdf','svg','png','tiff']:
        shutil.copy2(v.OUT/'figures'/('Supplementary_Fig3_support_sensitivity.'+ext),FIG/('Supplementary_Fig5_threshold_sensitivity.'+ext))
    CAP['Supplementary_Fig5_threshold_sensitivity']='Supplementary Fig. 5 | Classification sensitivity to threshold and reporting support. Fractions of all-axis balance, pressure and surplus are shown at thresholds 0.25, 0.50, 0.75 and 1.00 for the full, active and common-positive supports. All curves use the same population/resource arrays and full-domain normalisation. Differences are descriptive sensitivity results, not independent replicates or inferential error bars. Source data are provided in the source-data package.'

if __name__=='__main__':
    for job in [main1,main2,main3,main4,supplementary]:job()
    (OUT/'figure_legends.md').write_text('\n\n'.join(CAP.values())+'\n',encoding='utf-8')
    for name in ['country_audit.csv','map_unit_audit.csv','cropland_per_person.csv','threshold_support_sensitivity.csv','display_class_prevalence.csv','triple_class_support_audit.csv','future_support_totals.csv','figure_arrays.npz']:
        shutil.copy2(v.SD/name,SD/name)
    shutil.copy2(v.ROOT/'04_results/figdata/fig1_population_coverage_source.csv',SD/'population_coverage.csv')
    shutil.copy2(v.ROOT/'04_results/figdata/triple_class_lookup.csv',SD/'triple_class_lookup.csv')
    print('NS figure set exported; original figures preserved.',flush=True)
