"""Download public inputs for the global cropland mismatch project.

The downloader is deliberately small and resumable. It writes to ``.part``
files, retries transient HTTP failures, records SHA-256 checksums, and updates
the project data manifest after each item. GAEZ crop layers are optional:
the v5 object is attempted first and the configured v4 object is attempted
only when v5 is unavailable.
"""

from __future__ import annotations

import csv
import concurrent.futures
import hashlib
import json
import logging
import math
import re
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import requests
from tqdm import tqdm


USER_AGENT = "Global-Cropland-Population-Mismatch/0.1 (research data pipeline)"
RETRYABLE = {408, 425, 429, 500, 502, 503, 504}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def setup_logger(log_path: Path) -> logging.Logger:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("data_download")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def _request(url: str, start: int = 0, timeout: tuple[int, int] = (30, 180)):
    headers = {"User-Agent": USER_AGENT}
    if start:
        headers["Range"] = f"bytes={start}-"
    response = requests.get(url, headers=headers, stream=True, timeout=timeout)
    return response


def _parallel_resume(
    url: str,
    part: Path,
    target: Path,
    logger: logging.Logger,
    workers: int = 8,
) -> dict | None:
    """Resume a large partial file with independent HTTP byte ranges.

    Returns ``None`` when the endpoint does not advertise a usable length or
    range support, allowing the caller to fall back to the normal stream.
    Segment files are kept until the final merge so an interrupted run can
    reuse completed ranges.
    """
    head = requests.head(
        url,
        headers={"User-Agent": USER_AGENT},
        allow_redirects=True,
        timeout=(30, 60),
    )
    if head.status_code >= 400:
        return None
    length_text = head.headers.get("Content-Length")
    if length_text and length_text.isdigit():
        total = int(length_text)
    else:
        # Dropbox often omits Content-Length on HEAD while still supporting
        # byte ranges.  A one-byte probe exposes the total in Content-Range.
        probe = requests.get(
            url,
            headers={"User-Agent": USER_AGENT, "Range": "bytes=0-0"},
            stream=True,
            timeout=(30, 60),
        )
        content_range = probe.headers.get("Content-Range", "")
        probe.close()
        match = re.search(r"bytes\s+\d+-\d+/(\d+)", content_range)
        if probe.status_code != 206 or not match:
            return None
        total = int(match.group(1))
    existing = part.stat().st_size if part.exists() else 0
    if existing >= total:
        part.replace(target)
        return {
            "status": "downloaded",
            "url": url,
            "bytes": target.stat().st_size,
            "sha256": sha256_file(target),
            "downloaded_at": utc_now(),
        }
    if total < 32 * 1024 * 1024:
        return None

    probe_end = min(existing + 1024 * 1024 - 1, total - 1)
    probe = requests.get(
        url,
        headers={"User-Agent": USER_AGENT, "Range": f"bytes={existing}-{probe_end}"},
        stream=True,
        timeout=(30, 120),
    )
    supports_range = probe.status_code == 206
    probe.close()
    if not supports_range:
        return None

    segment_dir = part.with_name(part.name + ".segments")
    segment_dir.mkdir(parents=True, exist_ok=True)
    remaining = total - existing
    segment_size = max(8 * 1024 * 1024, math.ceil(remaining / workers))
    ranges = []
    start = existing
    index = 0
    while start < total:
        end = min(total - 1, start + segment_size - 1)
        ranges.append((index, start, end))
        start = end + 1
        index += 1

    def fetch_segment(spec: tuple[int, int, int]) -> tuple[int, int]:
        seg_index, seg_start, seg_end = spec
        seg_path = segment_dir / f"segment_{seg_index:04d}_{seg_start}_{seg_end}.part"
        expected = seg_end - seg_start + 1
        if seg_path.exists() and seg_path.stat().st_size == expected:
            return seg_index, expected
        seg_path.unlink(missing_ok=True)
        last_error: Exception | None = None
        for attempt in range(1, 5):
            response = None
            try:
                response = requests.get(
                    url,
                    headers={
                        "User-Agent": USER_AGENT,
                        "Range": f"bytes={seg_start}-{seg_end}",
                    },
                    stream=True,
                    timeout=(30, 180),
                )
                if response.status_code != 206:
                    raise requests.HTTPError(f"range request returned HTTP {response.status_code}")
                with seg_path.open("wb") as handle:
                    for block in response.iter_content(chunk_size=1024 * 1024):
                        if block:
                            handle.write(block)
                response.close()
                if seg_path.stat().st_size != expected:
                    raise IOError(
                        f"short range segment {seg_path.stat().st_size}/{expected} bytes"
                    )
                return seg_index, expected
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                if response is not None:
                    response.close()
                seg_path.unlink(missing_ok=True)
                if attempt < 4:
                    time.sleep(min(3 * attempt, 15))
        raise RuntimeError(f"segment {seg_index} failed: {last_error}")

    logger.info(
        "resuming %s with %s HTTP ranges (%s -> %s bytes)",
        target.name,
        len(ranges),
        existing,
        total,
    )
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(fetch_segment, spec) for spec in ranges]
        completed = 0
        for future in concurrent.futures.as_completed(futures):
            _, bytes_done = future.result()
            completed += bytes_done
            logger.info("range progress %s/%s bytes for %s", completed, remaining, target.name)

    with part.open("ab") as destination:
        for seg_index, seg_start, seg_end in ranges:
            seg_path = segment_dir / f"segment_{seg_index:04d}_{seg_start}_{seg_end}.part"
            with seg_path.open("rb") as source:
                shutil.copyfileobj(source, destination, length=1024 * 1024)
    if part.stat().st_size != total:
        raise IOError(f"merged file has {part.stat().st_size} bytes; expected {total}")
    part.replace(target)
    for segment in segment_dir.glob("*.part"):
        segment.unlink(missing_ok=True)
    segment_dir.rmdir()
    size = target.stat().st_size
    digest = sha256_file(target)
    logger.info("downloaded: %s (%s bytes, sha256=%s)", target, size, digest)
    return {
        "status": "downloaded",
        "url": url,
        "bytes": size,
        "sha256": digest,
        "downloaded_at": utc_now(),
    }


def download_one(
    urls: Iterable[str],
    target: Path,
    logger: logging.Logger,
    force: bool = False,
    attempts: int = 4,
) -> dict:
    """Download one file from the first working URL and return a status record."""

    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_name(target.name + ".part")
    if target.exists() and target.stat().st_size > 0 and not force:
        logger.info("exists: %s (%s bytes)", target, target.stat().st_size)
        return {
            "status": "existing",
            "url": "",
            "bytes": target.stat().st_size,
            "sha256": sha256_file(target),
            "downloaded_at": utc_now(),
        }

    if part.exists() and part.stat().st_size > 0 and not force:
        for url in [u for u in urls if u]:
            try:
                parallel_result = _parallel_resume(url, part, target, logger)
                if parallel_result is not None:
                    return parallel_result
            except Exception as exc:  # noqa: BLE001 - try normal resumable stream next
                logger.warning("parallel resume failed for %s: %s", url, exc)

    # Large WorldPop/ FuturePop archives support byte ranges even on a fresh
    # download.  Starting the range downloader here avoids a single slow
    # stream while retaining the normal-stream fallback for small or unusual
    # endpoints.
    if not force and not part.exists():
        for url in [u for u in urls if u]:
            try:
                parallel_result = _parallel_resume(url, part, target, logger)
                if parallel_result is not None:
                    return parallel_result
            except Exception as exc:  # noqa: BLE001 - try normal stream next
                logger.warning("parallel fresh download failed for %s: %s", url, exc)

    last_error: Exception | None = None
    for url in [u for u in urls if u]:
        for attempt in range(1, attempts + 1):
            response = None
            try:
                start = part.stat().st_size if part.exists() and not force else 0
                if force and part.exists():
                    part.unlink()
                response = _request(url, start=start)
                if response.status_code == 416 and start:
                    logger.info("range rejected; restarting download: %s", url)
                    part.unlink(missing_ok=True)
                    response.close()
                    response = _request(url, start=0)
                    start = 0
                if response.status_code >= 400:
                    if response.status_code in RETRYABLE:
                        raise requests.HTTPError(
                            f"retryable HTTP {response.status_code} for {url}"
                        )
                    raise requests.HTTPError(
                        f"HTTP {response.status_code} for {url}", response=response
                    )

                append = start > 0 and response.status_code == 206
                if start and not append:
                    logger.warning(
                        "server did not honor Range; preserving %s-byte checkpoint for %s",
                        start,
                        target.name,
                    )
                    response.close()
                    raise IOError(f"server did not honor Range; partial checkpoint preserved: {part}")

                content_length = response.headers.get("Content-Length")
                content_range = response.headers.get("Content-Range", "")
                range_match = re.fullmatch(r"bytes\s+(\d+)-(\d+)/(\d+|\*)", content_range.strip())
                if response.status_code == 206:
                    if not range_match or int(range_match.group(1)) != start:
                        raise IOError(f"invalid Content-Range for {url}: {content_range!r}")
                    expected_size = None if range_match.group(3) == "*" else int(range_match.group(3))
                else:
                    expected_size = int(content_length) if content_length and content_length.isdigit() else None
                total = expected_size
                mode = "ab" if append else "wb"
                with part.open(mode) as handle:
                    progress = tqdm(
                        total=total,
                        initial=start,
                        unit="B",
                        unit_scale=True,
                        unit_divisor=1024,
                        desc=target.name[:45],
                        leave=True,
                    )
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            handle.write(chunk)
                            progress.update(len(chunk))
                    progress.close()
                response.close()
                if part.stat().st_size == 0:
                    raise IOError(f"empty response for {url}")
                actual_size = part.stat().st_size
                if expected_size is not None and actual_size != expected_size:
                    raise IOError(
                        f"incomplete response for {url}: got {actual_size} bytes, "
                        f"expected {expected_size}; checkpoint preserved at {part}"
                    )
                part.replace(target)
                size = target.stat().st_size
                digest = sha256_file(target)
                logger.info("downloaded: %s (%s bytes, sha256=%s)", target, size, digest)
                return {
                    "status": "downloaded",
                    "url": url,
                    "bytes": size,
                    "sha256": digest,
                    "downloaded_at": utc_now(),
                }
            except Exception as exc:  # noqa: BLE001 - log and try next endpoint
                last_error = exc
                if response is not None:
                    response.close()
                logger.warning(
                    "attempt %s/%s failed for %s: %s", attempt, attempts, url, exc
                )
                if attempt < attempts:
                    time.sleep(min(3 * attempt, 15))
        logger.warning("endpoint exhausted: %s", url)

    raise RuntimeError(f"all download endpoints failed for {target}: {last_error}")


def read_manifest(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    # Older hand-edited CSV rows may contain unquoted commas in the notes
    # field. Preserve overflow text in notes rather than carrying a `None`
    # key into the next manifest write.
    for row in rows:
        overflow = row.pop(None, None)
        if overflow:
            recovered = " | ".join(str(value) for value in overflow if value not in (None, ""))
            existing = str(row.get("notes", "") or "").strip()
            row["notes"] = "; ".join(part for part in (existing, recovered) if part)
    return rows


def write_manifest(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = [
        "dataset_id", "provider", "version", "role", "source_url", "fallback_url",
        "target_path", "expected_semantics", "optional", "status", "bytes", "sha256",
        "downloaded_at", "notes",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows({field: row.get(field, "") for field in fields} for row in rows)


def update_manifest(
    manifest_path: Path,
    dataset_id: str,
    result: dict,
    note: str = "",
) -> None:
    rows = read_manifest(manifest_path)
    for row in rows:
        if row.get("dataset_id") == dataset_id:
            row["status"] = result.get("status", "unknown")
            row["bytes"] = str(result.get("bytes", ""))
            row["sha256"] = result.get("sha256", "")
            row["downloaded_at"] = result.get("downloaded_at", utc_now())
            if result.get("url"):
                row["source_url"] = result["url"]
            if result.get("target_path"):
                row["target_path"] = result["target_path"]
            if note:
                row["notes"] = note
            break
    write_manifest(manifest_path, rows)


def resolve_path(root: Path, relative: str) -> Path:
    path = Path(relative)
    if path.parts and path.parts[0].lower() == "01_data_raw":
        return root / path
    return root / "01_data_raw" / path


def download_from_config(
    cfg: dict,
    root: Path,
    manifest_path: Path,
    logger: logging.Logger,
    force: bool = False,
    include_future: bool = False,
    skip_production: bool = False,
) -> dict:
    sources = cfg.get("sources", {})
    summary: dict[str, str] = {}

    population_spec = sources.get("worldpop_2020", {})
    population_years = cfg.get("analysis", {}).get(
        "population_historical_years", [2000, 2010, 2020]
    )
    for year in population_years:
        year = int(year)
        dataset_id = f"worldpop_{year}"
        target_template = population_spec.get(
            "target_template", "population/worldpop_{year}_1km.tif"
        )
        target = resolve_path(root, str(target_template).format(year=year))
        try:
            if population_spec.get("preferred_method") == "arcgis_native_1km_tile_sum":
                from worldpop_arcgis_native import process_year

                existing_target = resolve_path(
                    root,
                    (
                        f"population/worldpop_{year}_5arcmin_sum_native_slice.tif"
                        if year == 2020
                        else f"population/worldpop_{year}_5arcmin_sum.tif"
                    ),
                )
                if existing_target.exists() and not force:
                    try:
                        import rasterio

                        with rasterio.open(existing_target) as existing:
                            tags = existing.tags()
                            valid_existing = (
                                existing.shape == (2160, 4320)
                                and str(existing.crs) == "EPSG:4326"
                                and str(tags.get("source_year")) == str(year)
                                and "10x10" in str(tags.get("aggregation", ""))
                            )
                    except Exception:  # noqa: BLE001 - invalid existing output will be regenerated
                        valid_existing = False
                    if valid_existing:
                        summary[dataset_id] = "present and validated (native slice/local sum)"
                        continue

                result = process_year(root, year, workers=6, force=force, logger=logger)
                # The native short-request route returns a complete 5 arc-min
                # population-count raster after the local 10 x 10 sum.  It is
                # intentionally distinct from a raw 1-km archive target.
                target = Path(result["target"])
                result.update(
                    {
                        "status": "downloaded",
                        "url": population_spec.get("arcgis_export_url", ""),
                        "sha256": sha256_file(target),
                        "downloaded_at": utc_now(),
                        "target_path": str(target.relative_to(root)).replace("\\", "/"),
                    }
                )
                update_manifest(
                    manifest_path,
                    dataset_id,
                    result,
                    note=(
                        "WorldPop Global1 ImageServer native 1-km slice retrieved in "
                        "short 20-degree tiles and locally summed over non-overlapping "
                        f"10x10 cells for historical year {year}."
                    ),
                )
                summary[dataset_id] = result["status"] + " (native tile/local sum)"
                continue
            if population_spec.get("preferred_method") == "direct_global_1km":
                url_template = population_spec.get("url_template", "")
                fallback_template = population_spec.get("fallback_url_template", "")
                urls = [
                    url_template.format(year=year) if url_template else "",
                    fallback_template.format(year=year) if fallback_template else "",
                    population_spec.get("mirror_url_template", "").format(year=year)
                    if population_spec.get("mirror_url_template")
                    else "",
                ]
                result = download_one(urls, target, logger, force=force)
                result["target_path"] = str(target.relative_to(root)).replace("\\", "/")
                update_manifest(
                    manifest_path,
                    dataset_id,
                    result,
                    note=(
                        "WorldPop Global1 archived global 1-km mosaic; all historical "
                        f"years use the same product family and are locally aggregated "
                        f"to 5 arc-min with population-count-preserving sum resampling ({year})."
                    ),
                )
                summary[dataset_id] = result["status"] + " (Global1 1-km source)"
                continue
            if population_spec.get("preferred_method") == "arcgis_aggregate":
                from worldpop_arcgis import download_worldpop_arcgis

                grid = cfg.get("grid", {})
                result = download_worldpop_arcgis(
                    root,
                    year=year,
                    resolution=float(grid.get("resolution", 0.08333333333333333)),
                    width=int(grid.get("width", 4320)),
                    height=int(grid.get("height", 2160)),
                    force=force,
                    logger=logger,
                )
                result["sha256"] = sha256_file(target)
                result["target_path"] = str(target.relative_to(root)).replace("\\", "/")
                update_manifest(
                    manifest_path,
                    dataset_id,
                    result,
                    note=(
                        "WorldPop Global1 1-km ImageServer exported with server-side "
                        "10-cell Sum to 5 arc-min; same service and aggregation for "
                        f"historical year {year}."
                    ),
                )
                summary[dataset_id] = result["status"] + " (ArcGIS 5 arc-min Sum)"
                continue
            raise RuntimeError("WorldPop historical source is not configured for direct download")
        except Exception as exc:  # noqa: BLE001 - preserve direct fallback behavior
            summary[dataset_id] = f"failed: {exc}"
            update_manifest(
                manifest_path,
                dataset_id,
                {"status": "failed", "downloaded_at": utc_now()},
                note=str(exc),
            )
            if not population_spec.get("optional", False):
                logger.error("required historical population input failed: %s", dataset_id)
                raise
            logger.warning("optional historical population input failed: %s", dataset_id)

    simple_ids = [
        "un_wpp_2024",
        "glad_cropland_2019",
        "spam2020_harvested_area",
        "natural_earth_admin0",
    ]
    if not skip_production:
        simple_ids.insert(3, "spam2020_production")
    for dataset_id in simple_ids:
        spec = sources.get(dataset_id)
        if not spec:
            continue
        target = resolve_path(root, spec["target"])
        urls = [spec.get("url"), spec.get("fallback_url")]
        try:
            result = download_one(urls, target, logger, force=force)
            update_manifest(manifest_path, dataset_id, result)
            summary[dataset_id] = result["status"]
        except Exception as exc:  # noqa: BLE001 - optional inputs must not stop baseline
            summary[dataset_id] = f"failed: {exc}"
            update_manifest(
                manifest_path,
                dataset_id,
                {"status": "failed", "downloaded_at": utc_now()},
                note=str(exc),
            )
            if not spec.get("optional", False):
                logger.error("required input failed: %s", dataset_id)
                raise
            logger.warning("optional input failed: %s", dataset_id)

    gaez = sources.get("gaez_v5", {})
    analysis = cfg.get("analysis", {})
    crop_codes = analysis.get("gaez_crops", [])
    for crop in crop_codes:
        dataset_id = f"gaez_v5_{crop.lower()}"
        target_name = (
            f"GAEZ-V5.RES05-YXX.{analysis.get('gaez_time_period', 'HP0120')}."
            f"{analysis.get('gaez_climate_model', 'AGERA5')}."
            f"{analysis.get('gaez_scenario', 'HIST')}.{crop}."
            f"{analysis.get('gaez_water_management', 'HRLM')}.tif"
        )
        target = root / "01_data_raw" / "gaez" / target_name
        v5_url = gaez.get("url_template", "").format(
            time_period=analysis.get("gaez_time_period", "HP0120"),
            climate_model=analysis.get("gaez_climate_model", "AGERA5"),
            scenario=analysis.get("gaez_scenario", "HIST"),
            crop=crop,
        )
        crop_lower = crop.lower()
        v4_url = gaez.get("v4_fallback_template", "").format(crop_lower=crop_lower)
        try:
            result = download_one([v5_url, v4_url], target, logger, force=force)
            existing_source = next(
                (
                    row.get("source_url", "")
                    for row in read_manifest(manifest_path)
                    if row.get("dataset_id") == dataset_id
                ),
                "",
            )
            is_v5 = result.get("url") == v5_url or existing_source == v5_url
            note = "GAEZ v5" if is_v5 else "GAEZ v4 fallback"
            update_manifest(manifest_path, dataset_id, result, note=note)
            summary[dataset_id] = f"{result['status']} ({note})"
        except Exception as exc:  # noqa: BLE001
            summary[dataset_id] = f"failed: {exc}"
            update_manifest(
                manifest_path,
                dataset_id,
                {"status": "failed", "downloaded_at": utc_now()},
                note=str(exc),
            )
            if not gaez.get("optional", True):
                raise
            logger.warning("optional GAEZ layer failed for %s: %s", crop, exc)

    future = sources.get("future_population", {})
    if include_future or future.get("download_default", False):
        scenarios = future.get("download_scenarios") or list(future.get("scenarios", {}))
        for scenario in scenarios:
            scenario = str(scenario).upper()
            url = future.get("scenarios", {}).get(scenario)
            if not url:
                logger.warning("future population URL missing for %s", scenario)
                continue
            mirror_url = (future.get("mirror_scenarios", {}) or {}).get(scenario, "")
            dataset_id = f"future_population_{scenario}"
            target = root / "01_data_raw" / "future_population" / Path(url).name
            try:
                result = download_one([url, mirror_url], target, logger, force=force)
                update_manifest(manifest_path, dataset_id, result, note="WorldPop FuturePop v0.2; global 30 arc-second projections consistent with SSP national scenarios; official Southampton mirror used when primary host is unavailable.")
                summary[dataset_id] = result["status"]
            except Exception as exc:  # noqa: BLE001
                summary[dataset_id] = f"failed: {exc}"
                update_manifest(
                    manifest_path,
                    dataset_id,
                    {"status": "failed", "downloaded_at": utc_now()},
                    note=str(exc),
                )
                logger.warning("future population download failed for %s: %s", scenario, exc)
    else:
        logger.info("FuturePop archives are not downloaded; use --include-future when needed")

    status_path = root / "06_logs" / "download_status.json"
    status_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary
