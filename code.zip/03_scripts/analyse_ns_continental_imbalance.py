"""Continental stock accounting on a fixed, matched country support."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'07_manuscript/packages/nature_sustainability/manuscript_five_figures_20261020'
OUT=BASE.parent/'regional_imbalance_20261020'
SD=OUT/'source_data'
KEYS={'area':'cropland_area_ha_total','quality':'quality_equivalent_cropland_ha_total','capacity':'potential_capacity_mt_total'}

def analyse():
    SD.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(BASE/'source_data/country_audit.csv')
    m=pd.read_csv(BASE/'source_data/matched_national_redistribution_rates.csv')
    d=d.merge(m[['iso3','2020','SSP2_2050']],on='iso3',validate='one_to_one')
    assert len(d)==201
    for s in range(1,6):
        f=pd.read_csv(ROOT/f'04_results/tables/future_fallback_country_SSP{s}_2050.csv')
        f.iso3=f.iso3.replace({'PSX':'PSE','KOS':'XXK'})
        f=f.groupby('iso3',as_index=False).allocated_population.sum()
        values=d.iso3.map(f.set_index('iso3').allocated_population)
        assert values.notna().all() and (values>0).all(),(s,d.loc[values.isna(),'iso3'].tolist())
        if s==2:assert np.allclose(values,d.SSP2_2050,rtol=1e-12)
        d[f'SSP{s}_2050']=values
    d['region']=d.continent.replace({'Seven seas (open ocean)':'Other island territories'})
    cols=['2020']+[f'SSP{s}_2050' for s in range(1,6)]+list(KEYS.values())
    g=d.groupby('region',sort=True)[cols].sum()
    counts=d.groupby('region').size()
    p0=g['2020']/g['2020'].sum()
    rows=[];tv=[]
    for s in range(1,6):
        p1=g[f'SSP{s}_2050']/g[f'SSP{s}_2050'].sum()
        change=np.log2(p1/p0)
        for r in g.index:
            rec=dict(region=r,scenario=f'SSP{s}',codes=int(counts[r]),population_2020=g.loc[r,'2020'],population_2050=g.loc[r,f'SSP{s}_2050'],population_share_2020_percent=100*p0[r],population_share_2050_percent=100*p1[r],delta_pressure_log2=change[r],population_share_ratio=p1[r]/p0[r])
            for label,k in KEYS.items():
                stock=g[k]/g[k].sum()
                rec[f'{label}_share_percent']=100*stock[r]
                rec[f'{label}_pressure_2020_log2']=np.log2((p0[r]+1e-12)/(stock[r]+1e-12))
                rec[f'{label}_pressure_2050_log2']=np.log2((p1[r]+1e-12)/(stock[r]+1e-12))
                assert abs(rec[f'{label}_pressure_2050_log2']-rec[f'{label}_pressure_2020_log2']-change[r])<1e-6
            rows.append(rec)
        for label,k in KEYS.items():
            stock=g[k]/g[k].sum()
            tv.append(dict(scenario=f'SSP{s}',resource=label,tv_2020=.5*np.abs(p0-stock).sum(),tv_2050=.5*np.abs(p1-stock).sum()))
    r=pd.DataFrame(rows);v=pd.DataFrame(tv)
    d.to_csv(SD/'matched_country_continental_inputs.csv',index=False)
    r.to_csv(SD/'continental_pressure_all_ssps.csv',index=False)
    v.to_csv(SD/'continental_population_resource_total_variation.csv',index=False)
    excluded=pd.read_csv(BASE/'source_data/country_audit.csv')
    excluded=excluded.loc[~excluded.iso3.isin(d.iso3),['iso3','country','continent','population_total']]
    excluded.to_csv(SD/'continental_analysis_excluded_codes.csv',index=False)
    stats=dict(matched_codes=201,regions=len(g),normalisation='same 201 codes at both dates; stocks summed before shares and pressures; no averaging of national log ratios',grouping='Natural Earth continent metadata; Seven seas (open ocean) retained as Other island territories; no income or development classification',population_2020=d['2020'].sum(),population_2050={f'SSP{s}':float(d[f'SSP{s}_2050'].sum()) for s in range(1,6)},ssp2=r[r.scenario=='SSP2'].to_dict('records'),total_variation=v.to_dict('records'))
    (OUT/'regional_verification.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
    print(r[r.scenario=='SSP2'][['region','population_share_2020_percent','population_share_2050_percent','capacity_share_percent','capacity_pressure_2020_log2','capacity_pressure_2050_log2','delta_pressure_log2']].to_string(index=False),flush=True)
    print(v.to_string(index=False),flush=True)

if __name__=='__main__':analyse()
