"""Fetch WorldPop historical years through the public ArcGIS ImageServer.

The service is a lossless 1-km WorldPop image service. Its Aggregate raster
function performs a server-side 10-cell Sum, so the downloaded result is
already on the project's 5 arc-min grid. This avoids a slow single HTTP stream
for the original 1-km mosaic while preserving the required population-count
semantics.
"""

from __future__ import annotations

import concurrent.futures
import json
import logging
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import rasterio
import requests
from rasterio.io import MemoryFile
from rasterio.transform import from_origin


SERVICE_URL = "https://worldpop.arcgis.com/arcgis/rest/services/WorldPop_Total_Population_1km/ImageServer/exportImage"
USER_AGENT = "Global-Cropland-Population-Mismatch/0.1 (research data pipeline)"


def _year_millis(year: int) -> int:
    return int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)


def _fetch_tile(
    tile: tuple[int, float, float, float, float, int, int],
    year: int,
    work_dir: Path,
    logger: logging.Logger,
    force: bool = False,
) -> tuple[int, np.ndarray]:
    index, xmin, ymin, xmax, ymax, width, height = tile
    tile_path = work_dir / f"tile_{index:02d}.tif"
    if tile_path.exists() and not force:
        with rasterio.open(tile_path) as src:
            return index, src.read(1).astype("float32", copy=False)

    rule = {
        "rasterFunction": "Aggregate",
        "rasterFunctionArguments": {
            "Raster": "$$",
            "CellFactor": 10,
            "AggregationTechnique": "Sum",
            "ExtentHandling": "Expand",
            "IgnoreNoData": True,
        },
        "outputPixelType": "F32",
    }
    # The ImageServer is a multidimensional mosaic.  The plain `time`
    # parameter is accepted by the endpoint but does not select a slice for
    # this service; the explicit dimensional mosaic rule is required to avoid
    # returning the same default slice for every requested year.
    mosaic_rule = {
        "mosaicMethod": "esriMosaicNone",
        "mosaicOperation": "MT_FIRST",
        "multidimensionalDefinition": [
            {
                "variableName": "Total Population",
                "dimensionName": "StdTime",
                "values": [_year_millis(year)],
                "isSlice": True,
            }
        ],
    }
    params = {
        "bbox": f"{xmin},{ymin},{xmax},{ymax}",
        "bboxSR": "4326",
        "size": f"{width},{height}",
        "imageSR": "4326",
        "format": "tiff",
        "pixelType": "F32",
        "interpolation": "RSP_NearestNeighbor",
        "time": str(_year_millis(year)),
        # The service exposes one ordered slice per year (0 = 2000, 20 =
        # 2020).  Supplying sliceId as well as the dimensional mosaic rule is
        # intentionally redundant but makes the selection robust across
        # ArcGIS Server versions.
        "sliceId": int(year - 2000),
        "mosaicRule": json.dumps(mosaic_rule, separators=(",", ":")),
        "renderingRule": json.dumps(rule, separators=(",", ":")),
        "f": "image",
    }
    last_error: Exception | None = None
    for attempt in range(1, 5):
        response = None
        try:
            response = requests.get(
                SERVICE_URL,
                params=params,
                headers={"User-Agent": USER_AGENT},
                timeout=(30, 300),
            )
            response.raise_for_status()
            with MemoryFile(response.content) as memory:
                with memory.open() as src:
                    array = src.read(1).astype("float32", copy=False)
                    if array.shape != (height, width):
                        raise ValueError(f"tile {index} shape {array.shape}, expected {(height, width)}")
                    transform = src.transform
                    expected = from_origin(xmin, ymax, (xmax - xmin) / width, (ymax - ymin) / height)
                    if not np.allclose(
                        [transform.a, transform.e, transform.c, transform.f],
                        [expected.a, expected.e, expected.c, expected.f],
                        atol=2e-6,
                    ):
                        raise ValueError(f"tile {index} transform mismatch: {transform}")
            # ArcGIS uses the maximum float32 as a NoData sentinel in this service.
            array[~np.isfinite(array)] = 0
            array[array >= 3.3e38] = 0
            array[array < 0] = 0
            profile = {
                "driver": "GTiff",
                "height": height,
                "width": width,
                "count": 1,
                "dtype": "float32",
                "crs": "EPSG:4326",
                "transform": from_origin(xmin, ymax, (xmax - xmin) / width, (ymax - ymin) / height),
                "nodata": 0.0,
                "compress": "DEFLATE",
                "predictor": 2,
                "tiled": True,
                "blockxsize": 256,
                "blockysize": 256,
            }
            with rasterio.open(tile_path, "w", **profile) as dst:
                dst.write(array, 1)
                dst.update_tags(
                    source=SERVICE_URL,
                    source_year=year,
                    aggregation="Aggregate CellFactor=10 AggregationTechnique=Sum",
                )
            logger.info("WorldPop ArcGIS tile %s saved (%s bytes)", index, len(response.content))
            return index, array
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            if response is not None:
                response.close()
            logger.warning("WorldPop ArcGIS tile %s attempt %s failed: %s", index, attempt, exc)
    raise RuntimeError(f"WorldPop ArcGIS tile {index} failed: {last_error}")


def download_worldpop_arcgis(
    root: Path,
    *,
    year: int = 2020,
    resolution: float = 0.08333333333333333,
    width: int = 4320,
    height: int = 2160,
    force: bool = False,
    logger: logging.Logger | None = None,
) -> dict:
    logger = logger or logging.getLogger("worldpop_arcgis")
    target = root / "01_data_raw" / "population" / f"worldpop_{year}_5arcmin_sum.tif"
    # Keep tile caches separate by year.  Reusing a 2020 tile for another time
    # slice would silently create a valid-looking but incorrect time series.
    work_dir = root / "work" / f"worldpop_arcgis_tiles_{year}"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.stat().st_size > 0 and not force:
        return {
            "status": "existing",
            "url": SERVICE_URL,
            "bytes": target.stat().st_size,
            "sha256": "",
            "downloaded_at": datetime.now(timezone.utc).isoformat(),
            "target": str(target),
        }
    work_dir.mkdir(parents=True, exist_ok=True)
    split_col = width // 2
    tiles = [
        (0, -180.0, -90.0, -180.0 + split_col * resolution, 90.0, split_col, height),
        (1, -180.0 + split_col * resolution, -90.0, 180.0, 90.0, width - split_col, height),
    ]
    arrays = [None, None]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(_fetch_tile, tile, year, work_dir, logger, force) for tile in tiles]
        for future in concurrent.futures.as_completed(futures):
            index, array = future.result()
            arrays[index] = array
    if arrays[0] is None or arrays[1] is None:
        raise RuntimeError("WorldPop ArcGIS returned incomplete tiles")
    data = np.concatenate([arrays[0], arrays[1]], axis=1).astype("float32", copy=False)
    if data.shape != (height, width):
        raise ValueError(f"assembled WorldPop shape {data.shape}, expected {(height, width)}")
    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:4326",
        "transform": from_origin(-180.0, 90.0, resolution, resolution),
        "nodata": 0.0,
        "compress": "DEFLATE",
        "predictor": 2,
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "BIGTIFF": "IF_SAFER",
    }
    with rasterio.open(target, "w", **profile) as dst:
        dst.write(data, 1)
        dst.update_tags(
            source=SERVICE_URL,
            source_product="WorldPop_Total_Population_1km",
            source_year=year,
            aggregation="server-side Aggregate CellFactor=10 AggregationTechnique=Sum",
            semantics="population count per 5 arc-min cell",
        )
    return {
        "status": "downloaded",
        "url": SERVICE_URL,
        "bytes": target.stat().st_size,
        "sha256": "",
        "downloaded_at": datetime.now(timezone.utc).isoformat(),
        "target": str(target),
    }
