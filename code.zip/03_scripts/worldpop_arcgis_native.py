"""Fetch WorldPop Global1 slices as short native-resolution tile requests.

The public ImageServer has a maximum export size of about 4,100 pixels and
does not reliably apply a spatial Aggregate function before selecting a
multidimensional slice.  This worker therefore requests 20-degree native
1-km tiles, selects the year with ``sliceId``, and performs the 10 x 10 sum
locally.  Each HTTP request is short and independently resumable at the tile
level, which avoids corrupting an entire global download after a long-stream
timeout.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import rasterio
import requests
from rasterio.io import MemoryFile
from rasterio.transform import from_origin

SERVICE_URL = "https://worldpop.arcgis.com/arcgis/rest/services/WorldPop_Total_Population_1km/ImageServer/exportImage"
MIRROR_SERVICE_URL = "https://worldpop.arcgis.com/arcgis/rest/services/WorldPop_Total_Population_1km/ImageServer/exportImage"
USER_AGENT = "Global-Cropland-Population-Mismatch/0.1 (research data pipeline)"
TILE_DEGREES = 20.0
NATIVE_RESOLUTION = 1.0 / 120.0
TILE_NATIVE_PIXELS = 2400
TARGET_PIXELS = 240
SERVICE_YMIN = -72.0
SERVICE_YMAX = 84.0


def year_millis(year: int) -> int:
    return int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)


def tile_specs() -> list[tuple[int, int, float, float, float, float]]:
    specs = []
    for lat_index in range(int(180 / TILE_DEGREES)):
        ymin = -90.0 + TILE_DEGREES * lat_index
        ymax = ymin + TILE_DEGREES
        for lon_index in range(int(360 / TILE_DEGREES)):
            xmin = -180.0 + TILE_DEGREES * lon_index
            xmax = xmin + TILE_DEGREES
            specs.append((lat_index, lon_index, xmin, ymin, xmax, ymax))
    return specs


def fetch_tile(
    spec: tuple[int, int, float, float, float, float],
    year: int,
    cache_dir: Path,
    logger: logging.Logger,
    force: bool = False,
) -> tuple[int, int, np.ndarray]:
    lat_index, lon_index, xmin, ymin, xmax, ymax = spec
    cache_dir.mkdir(parents=True, exist_ok=True)
    tile_path = cache_dir / f"tile_lat{lat_index:02d}_lon{lon_index:02d}.tif"
    if tile_path.exists() and tile_path.stat().st_size > 1000 and not force:
        with rasterio.open(tile_path) as src:
            data = src.read(1).astype("float32", copy=False)
        if data.shape == (TILE_NATIVE_PIXELS, TILE_NATIVE_PIXELS):
            return lat_index, lon_index, data
        tile_path.unlink(missing_ok=True)

    # The ImageServer has no data poleward of approximately -72 to 84 degrees
    # and returns HTTP 500 for a request wholly outside that extent.  Clip the
    # request to the advertised footprint, then insert the returned rows into
    # a full 20-degree tile padded with zeros.
    request_ymin = max(ymin, SERVICE_YMIN)
    request_ymax = min(ymax, SERVICE_YMAX)
    native = np.zeros((TILE_NATIVE_PIXELS, TILE_NATIVE_PIXELS), dtype="float32")
    if request_ymin >= request_ymax:
        profile = {
            "driver": "GTiff", "height": TILE_NATIVE_PIXELS, "width": TILE_NATIVE_PIXELS,
            "count": 1, "dtype": "float32", "crs": "EPSG:4326",
            "transform": from_origin(xmin, ymax, TILE_DEGREES / TILE_NATIVE_PIXELS, TILE_DEGREES / TILE_NATIVE_PIXELS),
            "nodata": 0.0, "compress": "DEFLATE", "predictor": 2,
            "tiled": True, "blockxsize": 256, "blockysize": 256,
        }
        with rasterio.open(tile_path, "w", **profile) as dst:
            dst.write(native, 1)
            dst.update_tags(source=SERVICE_URL, source_year=year, slice_id=year - 2000, native_resolution=NATIVE_RESOLUTION, note="tile outside WorldPop service footprint")
        return lat_index, lon_index, native
    request_height = int(round((request_ymax - request_ymin) / NATIVE_RESOLUTION))
    request_height = max(1, min(TILE_NATIVE_PIXELS, request_height))
    params = {
        "bbox": f"{xmin},{request_ymin},{xmax},{request_ymax}",
        "bboxSR": "4326",
        "size": f"{TILE_NATIVE_PIXELS},{request_height}",
        "imageSR": "4326",
        "format": "tiff",
        "pixelType": "F32",
        "interpolation": "RSP_NearestNeighbor",
        "time": str(year_millis(year)),
        "sliceId": str(year - 2000),
        "f": "image",
    }
    last_error: Exception | None = None
    for attempt in range(1, 5):
        response = None
        try:
            response = requests.get(
                SERVICE_URL,
                params=params,
                headers={"User-Agent": USER_AGENT, "Accept-Encoding": "identity"},
                timeout=(30, 180),
            )
            response.raise_for_status()
            with MemoryFile(response.content) as memory:
                with memory.open() as src:
                    data = src.read(1).astype("float32", copy=False)
                    if data.shape != (request_height, TILE_NATIVE_PIXELS):
                        raise ValueError(f"unexpected tile shape {data.shape}, expected {(request_height, TILE_NATIVE_PIXELS)}")
            data[~np.isfinite(data)] = 0.0
            data[data >= 3.3e38] = 0.0
            data[data < 0] = 0.0
            row_offset = int(round((ymax - request_ymax) / NATIVE_RESOLUTION))
            row_end = row_offset + request_height
            if row_offset < 0 or row_end > TILE_NATIVE_PIXELS:
                raise ValueError(f"clipped tile row placement out of bounds: {row_offset}:{row_end}")
            native[row_offset:row_end, :] = data
            profile = {
                "driver": "GTiff",
                "height": TILE_NATIVE_PIXELS,
                "width": TILE_NATIVE_PIXELS,
                "count": 1,
                "dtype": "float32",
                "crs": "EPSG:4326",
                "transform": from_origin(xmin, ymax, TILE_DEGREES / TILE_NATIVE_PIXELS, TILE_DEGREES / TILE_NATIVE_PIXELS),
                "nodata": 0.0,
                "compress": "DEFLATE",
                "predictor": 2,
                "tiled": True,
                "blockxsize": 256,
                "blockysize": 256,
            }
            with rasterio.open(tile_path, "w", **profile) as dst:
                dst.write(native, 1)
                dst.update_tags(source=SERVICE_URL, source_year=year, slice_id=year - 2000, native_resolution=NATIVE_RESOLUTION)
            return lat_index, lon_index, native
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            if response is not None:
                response.close()
            logger.warning("WorldPop native tile (%s,%s) attempt %s failed: %s", lat_index, lon_index, attempt, exc)
    raise RuntimeError(f"native tile ({lat_index},{lon_index}) failed: {last_error}")


def process_year(root: Path, year: int, workers: int, force: bool, logger: logging.Logger) -> dict:
    cache_dir = root / "work" / f"worldpop_native_tiles_{year}"
    cache_dir.mkdir(parents=True, exist_ok=True)
    data = np.zeros((2160, 4320), dtype="float32")
    specs = tile_specs()
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(fetch_tile, spec, year, cache_dir, logger, force) for spec in specs]
        completed = 0
        for future in concurrent.futures.as_completed(futures):
            lat_index, lon_index, native = future.result()
            coarse = native.reshape(TARGET_PIXELS, 10, TARGET_PIXELS, 10).sum(axis=(1, 3), dtype="float64").astype("float32")
            # Array row zero is the northern edge of the global grid, whereas
            # tile specs are enumerated from the southern edge.
            row_start = (int(180 / TILE_DEGREES) - 1 - lat_index) * TARGET_PIXELS
            col_start = lon_index * TARGET_PIXELS
            data[row_start : row_start + TARGET_PIXELS, col_start : col_start + TARGET_PIXELS] = coarse
            completed += 1
            if completed % 6 == 0 or completed == len(specs):
                logger.info("WorldPop %s native tiles: %s/%s", year, completed, len(specs))
    target_name = (
        f"worldpop_{year}_5arcmin_sum_native_slice.tif"
        if year == 2020
        else f"worldpop_{year}_5arcmin_sum.tif"
    )
    target = root / "01_data_raw" / "population" / target_name
    profile = {
        "driver": "GTiff",
        "height": 2160,
        "width": 4320,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:4326",
        "transform": from_origin(-180.0, 90.0, 1.0 / 12.0, 1.0 / 12.0),
        "nodata": 0.0,
        "compress": "DEFLATE",
        "predictor": 2,
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "BIGTIFF": "IF_SAFER",
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(target, "w", **profile) as dst:
        dst.write(data, 1)
        dst.update_tags(
            source=SERVICE_URL,
            source_product="WorldPop_Total_Population_1km",
            source_year=year,
            slice_id=year - 2000,
            aggregation="local non-overlapping 10x10 native-pixel sum",
            semantics="population count per 5 arc-min cell",
        )
    return {"year": year, "target": str(target), "bytes": target.stat().st_size, "global_sum_before_country_mask": float(data.sum()), "tile_count": len(specs), "aggregation": "10x10 native WorldPop pixels summed locally"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=None)
    parser.add_argument("--years", nargs="+", type=int, default=[2000, 2005, 2010, 2015, 2020])
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    root = Path(args.root) if args.root else Path(__file__).resolve().parents[1]
    log_path = root / "06_logs" / f"worldpop_native_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    logger = logging.getLogger("worldpop_native")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    for handler in (logging.StreamHandler(), logging.FileHandler(log_path, encoding="utf-8")):
        handler.setFormatter(formatter); logger.addHandler(handler)
    results = []
    for year in args.years:
        results.append(process_year(root, year, max(1, int(args.workers)), args.force, logger))
    out = root / "01_data_raw" / "population" / "worldpop_native_download_status.json"
    out.write_text(json.dumps({"created_at": datetime.now(timezone.utc).isoformat(), "results": results}, indent=2), encoding="utf-8")
    print(json.dumps({"years": [row["year"] for row in results], "targets": [row["target"] for row in results]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
