"""Python-only, source-data-backed figures for the NC revision."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import tifffile
from PIL import Image
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.lines import Line2D
from scipy.stats import spearmanr

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'07_manuscript/packages/nature_communications/revision_20261015'
SD=OUT/'source_data'; FIG=OUT/'figures'; FIG.mkdir(exist_ok=True)
A=np.load(SD/'figure_arrays.npz')
print('Loading audited arrays',flush=True)
D=np.isfinite(A['country_id'])&(A['country_id']>0)
P=np.nan_to_num(A['population']); CID=np.nan_to_num(A['country_id'],nan=0).astype('int16')
KEYS=['cropland_area_ha','quality_equivalent_cropland_ha','potential_capacity_mt']
R=[np.nan_to_num(A[k],nan=0) for k in KEYS]
ACTIVE=D&((P>0)|np.logical_or.reduce([r>0 for r in R]))
COMMON=D&(P>0)&np.logical_and.reduce([r>0 for r in R])
C=pd.read_csv(SD/'country_audit.csv'); C=C[C.population_total>0].copy()
U=pd.read_csv(SD/'map_unit_audit.csv')
H=pd.read_csv(ROOT/'04_results/figdata/fig1_population_coverage_source.csv')
print('Loading map boundaries',flush=True)
G=gpd.read_file(ROOT/'work/natural_earth_ne_10m_admin_0_map_units/ne_10m_admin_0_map_units.shp')
G['iso3']=G.ADM0_A3.replace({'PSX':'PSE','KOS':'XKX'})
G.geometry=G.geometry.simplify(.07,preserve_topology=True)
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.titlesize':7,'axes.labelsize':7,
                     'xtick.labelsize':6,'ytick.labelsize':6,'legend.fontsize':6,
                     'axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False,
                     'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
COL=['#287d8e','#8562a8','#c6832e']; BLUE='#3d7093'; RED='#b85443'
NAMES=['Cropland area','Quality-equivalent cropland','Attainable-capacity index']
metrics={}

def press(p,r,mask=D):
    p=np.where(mask,np.nan_to_num(p,nan=0),0).astype('float32')
    r=np.where(mask,np.nan_to_num(r,nan=0),0).astype('float32')
    return np.log2((p/p.sum(dtype='float64')+1e-12)/(r/r.sum(dtype='float64')+1e-12)).astype('float32')

M=[press(P,r) for r in R]
print('Pressure surfaces ready',flush=True)

def fig(h=170): return plt.figure(figsize=(183/25.4,h/25.4))
def ax(f,rect,letter,title):
    a=f.add_axes(rect)
    a.text(-.075,1.04,letter,transform=a.transAxes,weight='bold',fontsize=8,va='bottom',ha='left')
    a.set_title(title,loc='left',pad=8,weight='normal')
    return a

def mapplot(a,z,cmap='RdBu_r',vmin=-8,vmax=8,mask=D):
    z=np.where(mask,z,np.nan)
    im=a.imshow(z[::2,::2],extent=(-180,180,-90,90),origin='upper',cmap=cmap,
                vmin=vmin,vmax=vmax,interpolation='nearest',rasterized=True)
    G.boundary.plot(ax=a,color='#737373',linewidth=.12)
    a.set_xlim(-180,180); a.set_ylim(-60,85)
    a.set_xticks([-120,0,120],['120°W','0°','120°E']); a.set_yticks([-30,30,60],['30°S','30°N','60°N'])
    a.tick_params(length=2,pad=2); a.spines[['top','right']].set_visible(True)
    return im

def bar(f,im,rect,label,ticks=None):
    ca=f.add_axes(rect); c=f.colorbar(im,cax=ca,orientation='horizontal',ticks=ticks)
    c.set_label(label,labelpad=2); c.ax.tick_params(labelsize=6,length=2,pad=1)
    c.outline.set_linewidth(.5)

def save(f,name):
    for ext in ['pdf','svg','png']:
        f.savefig(FIG/(name+'.'+ext),dpi=300)
    # Use the standalone TIFF encoder; the older environment's Pillow LZW
    # plugin crashes natively on multi-megapixel RGBA exports.
    buffer=io.BytesIO(); f.savefig(buffer,format='png',dpi=600); buffer.seek(0)
    pix=np.array(Image.open(buffer).convert('RGB'))
    tifffile.imwrite(str(FIG/(name+'.tiff')),pix,compression='zlib',resolution=(600,600),metadata=None)
    plt.close(f)
    print(name,flush=True)

def figure1():
    f=fig(150)
    a=ax(f,[.075,.53,.89,.39],'a','Population distribution in 2020')
    im=mapplot(a,np.log10(np.maximum(P,1)),cmap='YlOrRd',vmin=0,vmax=6,mask=D&(P>0))
    bar(f,im,[.25,.485,.55,.015],r'Population count (log$_{10}$ persons)',[0,2,4,6])
    a=ax(f,[.09,.12,.51,.25],'b','Source totals and country-domain coverage')
    h=H[H.kind=='historical']; x=np.arange(len(h)); w=.33
    a.bar(x-w/2,h.raw_worldpop_total/1e9,w,color=BLUE,label='Full grid')
    a.bar(x+w/2,h.population_total_country_domain/1e9,w,color='#cba676',label='Country domain')
    a.set_xticks(x,h.period); a.set_ylabel('Population (billion persons)'); a.set_ylim(0,8.7)
    a.legend(loc='upper left',frameon=False,ncol=2,bbox_to_anchor=(0,1.02))
    a=ax(f,[.73,.12,.22,.25],'c','2020 domain audit')
    val=[7.969633182,7.782776021,.186857162]; a.bar(range(3),val,color=[BLUE,'#cba676','#b9b9b9'],width=.65)
    a.set_xticks(range(3),['Full\ngrid','Country\ndomain','Mask\nexcluded']); a.set_ylabel('Billion persons'); a.set_ylim(0,9)
    for i,v in enumerate(val): a.text(i,v+.15,f'{v:.2f}',ha='center',fontsize=6)
    save(f,'Fig1_population_support')

def figure2():
    f=fig(189)
    for i,m in enumerate(M):
        row=i; a=ax(f,[.08,.735-row*.30,.40,.18],chr(97+2*i),NAMES[i]+' pressure')
        im=mapplot(a,m,mask=ACTIVE)
        bar(f,im,[.16,.706-row*.30,.24,.009],r'Pressure (log$_2$ share ratio)',[-8,0,8])
        a=ax(f,[.58,.735-row*.30,.40,.18],chr(98+2*i),NAMES[i])
        z=np.log10(np.maximum(R[i],1)); limits=[(0,5),(0,5),(0,6)][i]
        im=mapplot(a,z,cmap=['YlGnBu','Purples','YlOrBr'][i],vmin=limits[0],vmax=limits[1],mask=D&(R[i]>0))
        label=[r'Area (log$_{10}$ ha)',r'Equivalent area (log$_{10}$ ha)',r'Capacity index (log$_{10}$ t)'][i]
        bar(f,im,[.66,.706-row*.30,.24,.009],label,[0,limits[1]])
    save(f,'Fig2_denominator_geographies')

def shares(a,key,title):
    x=C[key+'_global_share']; y=C.population_global_share; ok=(x>0)&(y>0)
    a.scatter(x[ok],y[ok],s=9,c=BLUE,alpha=.62,edgecolors='white',linewidths=.25,rasterized=False)
    a.plot([1e-12,1],[1e-12,1],ls='--',lw=.7,c='#444')
    a.set_xscale('log'); a.set_yscale('log'); a.set_xlim(1e-12,1); a.set_ylim(1e-8,1)
    a.set_xticks([1e-12,1e-8,1e-4,1]); a.set_yticks([1e-8,1e-4,1])
    a.set_xlabel(title+' share'); a.set_ylabel('Population share')
    a.text(.04,.06,f'n = {ok.sum()}',transform=a.transAxes,fontsize=6)

def figure3():
    f=fig(172)
    for i,k in enumerate(KEYS):
        a=ax(f,[.09+.32*i,.61,.24,.29],chr(97+i),['Area','Quality-equivalent','Capacity'][i])
        shares(a,k,['Area','Quality-equivalent','Capacity'][i])
    a=ax(f,[.19,.11,.76,.34],'d','National pressure profiles after merging map units')
    ex=C.set_index('iso3').loc[['SLE','NIC','NPL','IRQ','CHN','IND','BRA','USA']]
    y=np.arange(len(ex)); a.axvspan(-.5,.5,color='#e5e5e5',zorder=-2); a.axvline(0,c='#aaa',lw=.5)
    for j,k in enumerate(KEYS): a.scatter(ex[k+'_pressure_log2'],y+(j-1)*.19,c=COL[j],s=18,label=NAMES[j],zorder=3)
    a.set_yticks(y,ex.country.str.replace('United States of America','United States',regex=False)); a.invert_yaxis()
    a.set_xlabel(r'Pressure (log$_2$ population share / resource share)'); a.set_xlim(-3,6)
    f.legend(*a.get_legend_handles_labels(),frameon=False,ncol=3,loc='center',bbox_to_anchor=(.58,.51),fontsize=6)
    save(f,'Fig3_country_denominator_shifts')

def figure4():
    f=fig(166)
    a=ax(f,[.08,.54,.90,.38],'a','Relative demographic change under SSP2 in 2050')
    joined=G.merge(C[['iso3','delta_share_pressure_2050']],on='iso3',how='left')
    joined.plot(ax=a,column='delta_share_pressure_2050',cmap='RdBu_r',vmin=-1,vmax=1,
                linewidth=.15,edgecolor='#777',missing_kwds={'color':'#e9e9e9'},rasterized=True)
    a.set_xlim(-180,180); a.set_ylim(-60,85); a.set_xticks([-120,0,120],['120°W','0°','120°E']); a.set_yticks([-30,30,60],['30°S','30°N','60°N'])
    from matplotlib.cm import ScalarMappable
    im=ScalarMappable(norm=plt.Normalize(-1,1),cmap='RdBu_r')
    bar(f,im,[.27,.495,.50,.014],r'Change in share pressure (log$_2$; all three denominators)',[-1,-.5,0,.5,1])
    a=ax(f,[.09,.12,.39,.25],'b','Historical and scenario population')
    hist=H[H.kind=='historical']; fut=H[H.kind=='future']
    a.plot(hist.period.astype(int),hist.population_total/1e9,'o-',c=BLUE,lw=1,ms=3)
    label_y=[8.80,9.45,10.40,9.96,8.40]
    for i,(_,r) in enumerate(fut.iterrows()):
        a.scatter(2050,r.population_total/1e9,s=18,c=[COL[0],COL[2],RED,COL[1],'#68757e'][i])
        a.annotate(r.period.split('_')[0],(2050,r.population_total/1e9),xytext=(2058,label_y[i]),textcoords='data',fontsize=6,va='center',arrowprops={'arrowstyle':'-','lw':.45,'color':'#777'})
    a.set_xlim(1997,2068); a.set_ylim(5.4,10.6); a.set_xticks([2000,2020,2050]); a.set_ylabel('Billion persons')
    a=ax(f,[.65,.12,.31,.25],'c','Fixed cropland area per person')
    vals=[R[0][D].sum()/P[D].sum()]+[R[0][D].sum()/v for v in fut.population_total]
    a.bar(range(6),vals,color=['#999']+[COL[0],COL[2],RED,COL[1],'#68757e'],width=.65)
    a.set_xticks(range(6),['2020','SSP1','SSP2','SSP3','SSP4','SSP5'],rotation=45,ha='right')
    a.set_ylabel('Cropland (ha per person)'); a.set_ylim(0,.185)
    for i,v in enumerate(vals): a.text(i,v+.004,f'{v:.3f}',ha='center',fontsize=5.5)
    pd.DataFrame({'period':['2020']+fut.period.tolist(),'cropland_ha_per_person':vals}).to_csv(SD/'cropland_per_person.csv',index=False)
    save(f,'Fig4_fixed_resource_demography')

CLABEL=['All axes balanced','All axes pressure','All axes surplus','Area pressure; capacity balance','Area balance; capacity pressure','Area–capacity opposite signs','Other combinations']
CC=['#dedbd3','#bd5b46','#347b8c','#9479b4','#d3a146','#495b89','#a8b3ba']

def classify(m,threshold=.5):
    b=[np.where(x<-threshold,0,np.where(x>threshold,2,1)) for x in m]
    q,l,c=b; cls=np.full(q.shape,6,dtype='int8')
    cls[(q==2)&(c==1)]=3; cls[(q==1)&(c==2)]=4
    cls[((q==0)&(c==2))|((q==2)&(c==0))]=5
    cls[(q==0)&(l==0)&(c==0)]=2; cls[(q==2)&(l==2)&(c==2)]=1; cls[(q==1)&(l==1)&(c==1)]=0
    return cls

def figure5():
    f=fig(184); cls=classify(M); cmap=ListedColormap(CC)
    a=ax(f,[.08,.56,.90,.36],'a','Concordance and divergence on the active analysis domain')
    im=mapplot(a,cls,cmap=cmap,vmin=-.5,vmax=6.5,mask=ACTIVE)
    handles=[Line2D([0],[0],marker='s',color='none',markerfacecolor=c,markeredgecolor='none',markersize=5,label=l) for c,l in zip(CC,CLABEL)]
    f.legend(handles=handles,loc='center',bbox_to_anchor=(.53,.50),ncol=2,frameon=False,columnspacing=2)
    a=ax(f,[.24,.11,.30,.29],'b','Class prevalence by support')
    vals=[]
    for j,mask in enumerate([D,ACTIVE]):
        counts=np.bincount(cls[mask],minlength=7)/mask.sum()*100
        a.barh(np.arange(7)+(j-.5)*.30,counts,height=.27,color=CC,alpha=.48 if j==0 else 1,edgecolor='#555' if j==0 else 'none',linewidth=.3)
        vals.extend([dict(support=['country_domain','active_domain'][j],display_class=i,label=CLABEL[i],percent=v) for i,v in enumerate(counts)])
    a.set_yticks(np.arange(7),CLABEL); a.invert_yaxis(); a.set_xlabel('Cells (%)'); a.set_xlim(0,75)
    a.text(.98,.01,'Pale: full domain\nSolid: active domain',transform=a.transAxes,ha='right',va='bottom',fontsize=5.5)
    a=ax(f,[.68,.11,.29,.29],'c','National area and capacity pressure')
    a.axvspan(-.5,.5,color='#eee',zorder=-2); a.axhspan(-.5,.5,color='#eee',zorder=-2)
    a.scatter(C[KEYS[0]+'_pressure_log2'],C[KEYS[2]+'_pressure_log2'],s=9,color=BLUE,alpha=.6,edgecolors='none')
    a.plot([-7,32],[-7,32],'--',c='#777',lw=.6); a.set_xlim(-7,32); a.set_ylim(-7,32)
    a.set_xlabel(r'Area pressure (log$_2$)'); a.set_ylabel(r'Capacity pressure (log$_2$)')
    for iso,offset in [('SLE',(5,3)),('IRQ',(5,3)),('USA',(-17,-10))]:
        r=C.set_index('iso3').loc[iso]; a.annotate(iso,(r[KEYS[0]+'_pressure_log2'],r[KEYS[2]+'_pressure_log2']),xytext=offset,textcoords='offset points',fontsize=6)
    pd.DataFrame(vals).to_csv(SD/'display_class_prevalence.csv',index=False)
    save(f,'Fig5_concordance_and_support')

def supp1():
    prod=A['production'].astype(float); m=press(P,prod)
    f=fig(152); a=ax(f,[.08,.56,.90,.36],'a','Population share relative to realised four-crop production')
    im=mapplot(a,m,mask=ACTIVE); bar(f,im,[.25,.515,.56,.013],r'Production pressure (log$_2$ share ratio)',[-8,0,8])
    a=ax(f,[.10,.13,.36,.27],'b','National production shares'); shares(a,'production','Production')
    a=ax(f,[.62,.13,.35,.27],'c','Attainable capacity and realised production')
    a.scatter(C[KEYS[2]+'_pressure_log2'],C.production_pressure_log2,s=10,c=BLUE,alpha=.6)
    a.plot([-7,32],[-7,32],'--',c='#777',lw=.6); a.set_xlim(-7,32); a.set_ylim(-7,32)
    a.set_xlabel(r'Capacity pressure (log$_2$)'); a.set_ylabel(r'Production pressure (log$_2$)')
    for iso,off in [('IRQ',(5,3)),('CHN',(4,-8)),('USA',(-20,-8))]:
        r=C.set_index('iso3').loc[iso]; a.annotate(iso,(r[KEYS[2]+'_pressure_log2'],r.production_pressure_log2),xytext=off,textcoords='offset points',fontsize=6)
    save(f,'Supplementary_Fig1_realised_production')

def supp2():
    n=A['native'].astype(float); al=A['allocated'].astype(float)
    mask=D&np.isfinite(n)&(al>0)
    delta=press(n,R[2],mask)-press(al,R[2],mask)
    f=fig(155); a=ax(f,[.08,.55,.90,.38],'a','Native FuturePop minus fixed-pattern allocation on matched cells')
    im=mapplot(a,delta,vmin=-2,vmax=2,mask=mask); bar(f,im,[.25,.51,.56,.012],r'Difference in share pressure (log$_2$)',[-2,-1,0,1,2])
    a=ax(f,[.10,.13,.37,.26],'b','National totals on the country domain')
    ok=(C.native_population_2050>0)&(C.allocated_population_2050>0)
    a.scatter(C.loc[ok,'allocated_population_2050']/1e6,C.loc[ok,'native_population_2050']/1e6,s=10,color=BLUE,alpha=.65)
    a.plot([.01,3000],[.01,3000],'--',c='#777',lw=.6); a.set_xscale('log'); a.set_yscale('log')
    a.set_xlim(.01,3000); a.set_ylim(.01,3000); a.set_xlabel('Allocated population (million persons)'); a.set_ylabel('Native FuturePop (million persons)')
    a=ax(f,[.65,.13,.30,.26],'c','Totals by source and spatial support')
    vals=[np.nansum(n),np.nansum(n[D]),np.nansum(al[D]),np.nansum(n[mask]),np.nansum(al[mask])]
    labs=['Native\nfull','Native\ndomain','Allocated\ndomain','Native\nmatched','Allocated\nmatched']
    a.bar(range(5),np.array(vals)/1e9,color=[COL[0],BLUE,COL[2],BLUE,COL[2]],width=.65)
    a.set_ylim(0,11); a.set_xticks(range(5),labs,rotation=45,ha='right'); a.set_ylabel('Billion persons')
    for i,v in enumerate(vals): a.text(i,v/1e9+.13,f'{v/1e9:.2f}',ha='center',fontsize=6)
    pd.DataFrame({'scope':labs,'persons':vals}).to_csv(SD/'future_support_totals.csv',index=False)
    metrics['future_matched_population']={'native':vals[3],'allocated':vals[4],'cells':int(mask.sum())}
    save(f,'Supplementary_Fig2_future_provenance')

def supp3():
    rows=[]
    for t in [.25,.5,.75,1]:
        cls=classify(M,t)
        for support,mask in [('Country domain',D),('Active domain',ACTIVE),('Common positive',COMMON)]:
            for code in [0,1,2]: rows.append(dict(threshold=t,support=support,group=CLABEL[code],percent=100*np.mean(cls[mask]==code)))
    df=pd.DataFrame(rows); df.to_csv(SD/'threshold_support_sensitivity.csv',index=False)
    f=fig(76)
    for i,name in enumerate(CLABEL[:3]):
        a=ax(f,[.10+i*.31,.23,.23,.57],chr(97+i),name)
        for j,support in enumerate(df.support.unique()):
            z=df[(df.group==name)&(df.support==support)]; a.plot(z.threshold,z.percent,marker=['o','s','^'][j],lw=1,ms=3,color=[BLUE,RED,'#777'][j],label=support)
        a.set_xticks([.25,.5,.75,1]); a.set_xlabel(r'Threshold (log$_2$)'); a.set_ylabel('Cells (%)')
    f.legend(*a.get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.52,.02),ncol=3,frameon=False)
    save(f,'Supplementary_Fig3_support_sensitivity')

def supp4():
    f=fig(94)
    a=ax(f,[.10,.19,.39,.63],'a','National resource concentration')
    summaries=[]
    for k,c,l in zip(KEYS,COL,NAMES):
        x=np.sort(C[k+'_total'].values); y=np.r_[0,np.cumsum(x)/x.sum()]; xx=np.linspace(0,1,len(y))
        a.plot(xx,y,c=c,lw=1,label=l)
        summaries.extend([dict(resource=k,fraction_countries=xxi,cumulative_resource_fraction=yi) for xxi,yi in zip(xx,y)])
    a.plot([0,1],[0,1],'--',lw=.6,c='#777'); a.set_xlabel('Cumulative fraction of countries'); a.set_ylabel('Cumulative fraction of resource')
    a.legend(frameon=False,loc='upper left',fontsize=5.5)
    a=ax(f,[.69,.19,.27,.63],'b','Gini across national totals')
    vals=[]
    for k in KEYS:
        x=np.sort(C[k+'_total'].values); vals.append(2*np.dot(np.arange(1,len(x)+1),x)/(len(x)*x.sum())-(len(x)+1)/len(x))
    a.bar(range(3),vals,color=COL,width=.65); a.set_xticks(range(3),['Area','Quality-eq.','Capacity'],rotation=35,ha='right'); a.set_ylim(0,1); a.set_ylabel('Gini coefficient')
    for i,v in enumerate(vals): a.text(i,v+.02,f'{v:.3f}',ha='center',fontsize=6)
    pd.DataFrame(summaries).to_csv(SD/'country_lorenz.csv',index=False)
    metrics['country_gini_populated']={k:v for k,v in zip(KEYS,vals)}
    save(f,'Supplementary_Fig4_resource_concentration')

if __name__=='__main__':
    import sys
    jobs=[figure1,figure2,figure3,figure4,figure5,supp1,supp2,supp3,supp4]
    if len(sys.argv)>1: jobs=[jobs[int(n)-1] for n in sys.argv[1:]]
    for job in jobs: job()
    metrics['rank_correlations']={a+'__'+b:float(spearmanr(C[a+'_pressure_log2'],C[b+'_pressure_log2']).statistic) for a,b in [(KEYS[0],KEYS[1]),(KEYS[0],KEYS[2]),(KEYS[1],KEYS[2])]}
    metrics['n_populated_countries']=len(C)
    large=C[(C.population_total>=1e6)&np.logical_and.reduce([C[k+'_total']>0 for k in KEYS])]
    metrics['country_sensitivity']={'n_pop_at_least_1million_positive_all_resources':len(large),'band_changes':int(large.area_capacity_band_changed.sum()),'sign_changes':int(large.area_capacity_sign_changed.sum())}
    (SD/'figure_statistics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
