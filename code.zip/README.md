# Global cropland–population mismatch analysis code

Code associated with the manuscript "Accounting for crop geography reveals extreme spatial decoupling of global population and agricultural capacity".

Authors: Chong Luo, Xiangtian Meng, Wenqi Zhang and Huanjun Liu.

## Scope and current reproducibility

This archive contains retained Python processing, auditing and figure-generation scripts, configuration and dependency specifications. It does not contain third-party raw data, the authors' processed rasters, predecessor release packages or figure source-data tables. Several scripts expect the original project directory structure and outputs from prior analysis stages. A complete clean-environment, end-to-end reproduction has not yet been verified; use the archive for code inspection rather than assuming it is standalone.

The archived scripts parse as Python, but this syntax check does not validate numerical results or environment compatibility. File paths and input dataset availability must be checked by the user. The accompanying manuscript and source-data files document grids, denominators, support masks, figure inputs and methods.

## Data sources and future population

External inputs include WorldPop Global1 historical population, 2019 GLAD/Potapov cropland, MapSPAM 2020 v2.2, GAEZ v5 attainable yields and Natural Earth boundaries. Future analysis uses 2025-rebased national SSP populations distributed using fixed 2020 within-country WorldPop weights. The native FuturePop SSP2 raster is used for sensitivity, not as the primary future allocation. Some inherited configuration labels describe the national source as a fallback; the manuscript describes the actual final analysis.

Input products have independent licence and attribution requirements. No third-party raw datasets are redistributed in this archive. Code ownership and reuse licence must be selected and verified by the authors before any public release. For privacy and portability, one local manuscript-template path has been replaced by an `inputs/Manuscript_template.docx` placeholder and the configured project root has been made relative; the original project files are unchanged.

## Structure

- `03_scripts/` — data acquisition, spatial accounting, diagnostics and figure scripts.
- `run_pipeline.py` (if provided), `config.yaml`, `environment.yml`, `requirements.txt` — project entry point, configuration and dependency definitions.
- `FILE_MANIFEST.json` — file list and SHA-256 digests for this snapshot.

The exported figure scripts may refer to original predecessor package paths. Please consult the manuscript and the original project, check path references and validate numerical outputs before reusing or redistributing this archive.
